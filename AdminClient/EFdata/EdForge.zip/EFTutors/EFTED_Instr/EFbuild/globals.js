var EFTut_Suppl;
(function (EFTut_Suppl) {
    var $GLOBAL;
    (function ($GLOBAL) {
        class CONST {
        }
        CONST.TUTORCONTAINER = "STutorContainer";
        CONST.NEXTSCENE = "nextbutton";
        CONST.PREVSCENE = "prevbutton";
        CONST.MOUSE_MOVE = "mousemove";
        CONST.MOUSE_DOWN = "mousedown";
        CONST.MOUSE_UP = "mouseup";
        CONST.MOUSE_CLICK = "click";
        CONST.DOUBLE_CLICK = "dblclick";
        CONST.CLICK = "click";
        $GLOBAL.CONST = CONST;
    })($GLOBAL = EFTut_Suppl.$GLOBAL || (EFTut_Suppl.$GLOBAL = {}));
})(EFTut_Suppl || (EFTut_Suppl = {}));
var EFTut_Suppl;
(function (EFTut_Suppl) {
    var $GLOBAL;
    (function ($GLOBAL_1) {
        class $GLOBAL {
            $preEnterScene(scene) {
                scene.setBreadCrumbs(scene.name);
            }
            $preExitScene(scene) {
                switch (scene.name) {
                    case "SScene17":
                        if (this.testFeatures("FTR_TEDEXP1")) {
                            this.delFeature("FTR_TEDEXP1");
                            this.addFeature("FTR_TEDEXP2");
                        }
                        break;
                }
            }
            $nodeConstraint(nodeId, constraintId) {
                let result = false;
                switch (nodeId) {
                    case "RQ_DEVSELECTOR":
                        result = this.testFeatures(constraintId);
                        break;
                    case "TED_INTRO":
                        result = this.testFeatures(constraintId);
                        break;
                    case "TEDQ1":
                        switch (constraintId) {
                            case "CORRECT":
                                result = this.getModuleValue("Expt1_Q1").value;
                                break;
                            case "INCORRECT":
                                result = !this.getModuleValue("Expt1_Q1").value;
                                break;
                            default:
                                break;
                        }
                        break;
                    case "TEDQ2":
                        switch (constraintId) {
                            case "CORRECT":
                                result = this.getModuleValue("Expt1_Q4").value;
                                break;
                            case "INCORRECT":
                                result = !this.getModuleValue("Expt1_Q4").value;
                                break;
                            default:
                                break;
                        }
                        break;
                    case "TEDQ5":
                        switch (constraintId) {
                            case "FTR_TEDEXP1":
                                result = this.testFeatures(constraintId);
                                break;
                            default:
                                break;
                        }
                        break;
                    case "TEDPOST":
                        switch (constraintId) {
                            case "POSTTEST":
                                let PTVarray = this.getModuleValue("TEDExptPOSTSequence");
                                result = PTVarray.length > 0;
                                break;
                            default:
                                break;
                        }
                        break;
                    default:
                        break;
                }
                switch (constraintId) {
                    default:
                        break;
                }
                return result;
            }
        }
        $GLOBAL_1.$GLOBAL = $GLOBAL;
    })($GLOBAL = EFTut_Suppl.$GLOBAL || (EFTut_Suppl.$GLOBAL = {}));
})(EFTut_Suppl || (EFTut_Suppl = {}));
//# sourceMappingURL=globals.js.map