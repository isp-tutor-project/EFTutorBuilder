# EFTutors

Tutor graphs and dependencies are maintained in sub-folders.

tutors.json contains a list of active tutors.
