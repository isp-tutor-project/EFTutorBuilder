(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib._3DGridWall = function() {
	this.initialize(img._3DGridWall);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1024,768);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.TC_TVirtual__ExptRgn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(102,255,255,0.988)").s().dr(-475,-329.5,950,659);
	this.shape.setTransform(475,329.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TVirtual__ExptRgn, new cjs.Rectangle(0,0,950,659), null);


(lib.TC_TObject__CallOutHighlight = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00CCFF").s("#FFFFFF").ss(1,1,1).rr(-120,-50,240,100,15);
	this.shape.setTransform(120,50);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__CallOutHighlight, new cjs.Rectangle(-1,-1,242,102), null);


(lib.CHinge = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").ss(1,1,1).p("AAkgjQAOAPAAAUQAAAVgOAOQgPAPgVAAQgUAAgPgPQgOgOAAgVQAAgUAOgPQADgCACgCQANgKARAAQASAAANAKQACACADACg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AgiAjQgPgOAAgVQAAgUAPgPIAEgEQANgKARAAQASAAANAKIAEAEQAPAPAAAUQAAAVgPAOQgOAPgVAAQgUAAgOgPg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.CHinge, new cjs.Rectangle(-6,-6,12,12), null);


(lib.Carrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Arrow Auto Shape
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(1,1,1).p("ABLhUIAAGjIiVAAIAAmjIhLAAICVj6ICWD6g");
	this.shape.setTransform(16,34.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF00").s().p("AhKFPIAAmjIhLAAICVj6ICWD6IhLAAIAAGjg");
	this.shape_1.setTransform(16,34.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,32,69);


(lib.CangleCueSolid = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099CC").s("#333333").ss(1,1,1).p("AlZFUYAAi2BJiuCCiAYCDiACvhGC2ADIgMKng");
	this.shape.setTransform(155.7,152.6,2.254,2.254,-0.3,0,0,34.5,33.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CangleCueSolid, new cjs.Rectangle(-1,-1,157.2,156), null);


(lib.CangleCueOutline = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Angle Layer
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AlZFUYAAi2BJiuCCiAYCDiACvhGC2ADIgMKng");
	this.shape.setTransform(244.2,141.1,2.254,2.254,-0.3,0,0,33.3,34.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CangleCueOutline, new cjs.Rectangle(90.2,-14.9,157.2,156), null);


(lib.TC_TObject__CinclineSmooth = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#8F5601").ss(1,1,1).p("AXcAyMgu3AAAIAAhjMAu3AAAg");
	this.shape.setTransform(150,5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF9900").s().p("A3bAyIAAhjMAu3AAAIAABjg");
	this.shape_1.setTransform(150,5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__CinclineSmooth, new cjs.Rectangle(-1,-1,302,12), null);


(lib.TC_TObject__CinclineRoughNew = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#543201").ss(1,1,1).p("AXXgxIAFAAIAABjMgu3AAAIAAhWA3bgrIAAgGIADAA");
	this.shape.setTransform(149.8,3.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC99FF").s().p("A3ZBHIAAhWIgEAAIAEgHIAAgGIADAAIAIgIQAIgKAJAAQAFAAALADQADABAIgBIAKgBQAPgBAEAKQAFgOAJACQADABACACIAGAGQACADADABQAFABABgDQACgIADgEQAFgHAHAEQADACAAAJIAAABQAEgCACgBQAFgBAEACIABABQAHgDALACIABABIAOgFQADgBAEAAQAFABgBAEQAJAAAHgCQADADABAGIABABIAFABIAEAAIABgBQADgCAHgDIABAAQAFgFAHADIAJgBQAEgBAEABQADABABACIAAAAQADgPAJACIAFAJIAAABIAEAGQACgEADgBQAFgBADABQAEACACAEIABAEIADACQAGgFAFgFIAIAIIAHgIQABAEAFABIACABQAHgEAEgFQAFgFADAAQAGAAACAGIAAADQADADgCACQAHgHAFgCQAEgBAEACQAEABACAEIAHgBIADgFQADgBAHgBIAPgCQAEAAADADQACADgBADQADgGAQABQAFABAFgCQAGgCAAgEQAJAJAFABQADAAAEgBIAHgCQAKgBABAGIAGgCIAFgGQAHgIAFAAQAEAAAEAEIAGAFIAAAAQAKgBAEACIABABIAIAAQAIABADAKQAFgLAOgDQAFgBAGACIAFACIAEAAIAAAAQADgEAGgBQAEgBAEADQAEACAAAEIAAADIADgCQABgEAFABQAEAAACAEIABADIACAAIACgDQAFgJAFgBQAFgBAFAFIAEAGIAPgIQAIgEAEAAQAIAAABAHIAAAAQABABABAAQAAAAABAAQAAAAABAAQAAAAABgBQACgBABgDIADgEQACgDACgBQADgBADADQACACAAADIAAAFQAIgCAFgEIAPAMQAGADAHgHQAJgHADAAQAFgBADAFQADAFgCAFIATgCQAOgCAEgDQAKgEABABQAFABACAEIAAAAIABgHQACgDADAAQAEgBACACQADACAAADQAAAEgCACIAAAAQAQgJALAEIAJADQAEgBAEABIAEABIAGgBQADAAADACQAKgCAMgLQAHAFgCAIIA0gPQAKgDAEACQADABABAFQAAAEgCABQAIABAGAHQAGgMANgDQAGAAAEAFQAEAFgFABQAFACAHgDIALgIQAGgDAGADQAIADgDAFQAfgKAfAFIAAAFIAFACIAHgGQAJgIAIgCQAJgDAIAJQAJAIgIAHQALgIAPAEIAkgOQAGACADAHIACAHIAGAAIANgMQAOALAUgCQAUgDAKgPQAHAJgBALQAIAFALgBQAGAAAOgEQALgDAJABQAHABADADIACgFQADgEAGgBQAFgBAFADQAEAEAAAFQAIAAAGgIQARAEAQgBIAHgIIAEAIQAKgBADABIAIAEIAAgBQAEgGAGgCQAGgCALABIAAAAIACgDIAEAEQAHAAADgBQgBAEACAFIADAAIAMADIABAAQAFgDAHgDQALgEAFAEIAAgDQAFAKANAAIACAAQALAAALgFIALgFIADAEQANAPANgGQAHgDAJgKQAEgDAFgBQAGgBADAEQAEAIAJACQAKACAIgFQACALAUgEIAxgIIAAACQACAFAEABIAEABQAFgBACgDIADAAQAGABAFgCQAHgCAAgGIAAgDIAFAAIAAADIABAGQABADAEACQADACADAAQAHgBABgIQABgDgCgGIAFgBIABADQADAIACABQAEADAGgCQAIgFgDgIIAIAAIAAABIAFAIIACADIACAAQACACADAAQAFgBACgEQACgEAAgDIACACQACAEADABIAIABIAHAAQAEgBABgDIAEgDIABAFIABADIACABQAGAEAHgFQAEgDACgGIAHAAQACABACADIAAAAIACgBIABACIACABIACABIAFAAIAAAAIABACIAGAFIADADIAEAAQADAGAIAAQAHABAEgHQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBAAgBIAAAAQAEABAFgCIACgCIACAHIACACIABABQAHADAEgDQACgBABgDQAIgCAJgIQAMAQAegFIAJgBIgBgBQgCgEAFgBQAEgBADADIABACIAQgDIANAAIABACQAEAEAGABIAEgBIAIAAIABgEQAAAAABgBQAAgBAAAAQABgBAAAAQABAAAAAAQABAAABgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQAGgBADAGIgDAEIAJgBIABAAIAIgBIACAAIABgBIAIgFQAEgBAEABIAGACIABgBIADAAIAIgDQAFgEAEABQADABACACQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQAOgBANgHIAMgFQAJgCAEAIQAGgIAJADQAEABACAFIABACQAEgEACAAQAAAAABABQABAAAAAAQABABAAAAQAAABAAAAIAAAFIgCADIAJgBQgBgGACgCQADgDACACQACAAACAEIABAGIABAAIABgBIADgDQABAAAAgBQABAAAAAAQABAAAAAAQABAAAAAAIAAgCQAEAAAEACIAEgJQAGgJAEADQACABABAGIABAQIAEgCIARgLQALgHAIAAQAIAAADADQACACABADQAAADgCACQAQAAANgHQADAEAAAHQAEACAEgBQAFgCACgEIABgCIAAgCQADgEAGAFQAEAEAAADQAFgEABgIQABgGABgBQAAAAABAAQAAAAABAAQAAgBABABQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAIABAJIAKgIIAFAHQAHACAUgDQAPgCAHAFIAdgBIADAEQADAAAFgEQAVAAAUABIAAABIAHAAIAQABQAKABAFgCQADgCABgDQAPgBAJAAQASABAMAHQAAgHAIgCQAJgCACAGQADgIAGABIAHgFIAJANQACgKAJgCIAHALIAFABIADgEIABADQAGgBAEgDQAKgHABgKQAJAGAAAMIAGgNQAMAEAFANQgBgEACgCQACgDADgBQAGACACAIQABAEAAADIAFAAIAABjgAOMgXIACAAIAFAAQgBAAAAgBQgBAAAAAAQgBgBAAAAQAAgBgBgBgAhzgdIADAAIAAgDgATIgdIAFAAIABgCIgGACgAIJgeIADAAIgBgCIgCACgApLggIABABIABABIgBgDgAEHgkIgDACIgBAAIABABIACAAIACgDIgBAAgAEOgjIABAAIgCgBgAnVgoIABACIADgEgAyZhGIgBAAIACAAIABABIgCgBg");
	this.shape_1.setTransform(149.6,1.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__CinclineRoughNew, new cjs.Rectangle(-1.2,-5.9,302,15.3), null);


(lib.TC_TObject__CinclineNone = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(1.5,1,1).p("AXcAyMgu3AAAIAAhjMAu3AAAg");
	this.shape.setTransform(150,5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__CinclineNone, new cjs.Rectangle(-1,-1,302,12), null);


(lib.Arrow1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(4,1,1).p("AkGB4IEGjvIEHDvg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AkGB4IEGjvIEHDvg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28.2,-13.9,56.5,28);


(lib.CdoorSolid = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00CC33").s("#006600").ss(1,1,1).rr(-5,-25,10,50,2);
	this.shape.setTransform(5,-25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CdoorSolid, new cjs.Rectangle(-1,-51,12,52), null);


(lib.CbaseNull = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("EAuMgBWIAABPMhe8AAAIAABeMBhhAAAIAAitg");
	this.shape.setTransform(41.4,0.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s().p("EgwwABXIAAheMBe8AAAIAAhPIClAAIAACtg");
	this.shape_1.setTransform(41.4,0.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.CbaseNull, new cjs.Rectangle(-271.7,-8.8,626.3,19.4), null);


(lib.TC_TObject__CballYellow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").ss(1,1,1).p("ACtAAQAABHgxAyQgBAAAAABIgBAAQgEAEgFAFQgwAqhBAAQhHAAgygzQgzgzAAhHQAAgQADgQQAIgtAfgjQAEgFAFgEIAAAAQAygzBHAAQBHAAAzAzQAzAyAABHg");
	this.shape.setTransform(17.3,17.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#999999").ss(0.3,1,1).p("AAAAAIgFgFIh0h0AAAAAIAAAAIh5B6AB2B2Qg3g3g3g3QgBgBgBgBIgGgGAB6h5Ih6B5");
	this.shape_1.setTransform(17.3,17.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#990000").ss(0.3,1,1).p("Ag0g0IgFgFIgGgGABABAIgEgE");
	this.shape_2.setTransform(23.1,23.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#FFFFFF","#999999"],[0.376,1],-0.2,-0.2,0,-0.2,-0.2,21.2).s().p("AgCgCIAAAAIAFAFg");
	this.shape_3.setTransform(17.5,17.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#FF0000","#760101"],[0,1],0.3,-1.9,0,0.3,-1.9,19.6).s().p("AADADIgFgFIAFAFg");
	this.shape_4.setTransform(17,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 2
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#999999").ss(1,1,1).p("AB6B6QgzAyhHAAQhGAAgygyQgzgzAAhHQAAhGAzgyQAygzBGAAQBHAAAzAzQAyAyAABGQAABHgyAzg");
	this.shape_5.setTransform(17.2,17.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.rf(["#FFFF00","#C1C002"],[0.329,1],0,0,0,0,0,17.8).s().p("Ah5B5QgygyAAhHQAAhGAygzQAzgyBGAAQBHAAAyAyQAzAzAABGQAABHgzAyQgyAzhHAAQhGAAgzgzg");
	this.shape_6.setTransform(17.2,17.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__CballYellow, new cjs.Rectangle(-1,-1,36.5,36.5), null);


(lib.TC_TObject__CballPink = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#990066").ss(1,1,1).p("ACtAAQAABHgxAyQgBAAAAABIgBAAQgEAEgFAFQgwAqhBAAQhHAAgygzQgzgzAAhHQAAgQADgQQAIgtAfgjQAEgFAFgEIAAAAQAygzBHAAQBHAAAzAzQAzAyAABHg");
	this.shape.setTransform(17.3,17.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(0.3,1,1).p("ABzB4Qg3g3g3g4QgBAAgBgBIgFgGAh1B2IBzh0IAAAAAh2hxIBvBuIAFAFIB5h5");
	this.shape_1.setTransform(17.5,17.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF33CC").ss(0.3,1,1).p("AgCh5IAFAGAADB0IgFAG");
	this.shape_2.setTransform(5.4,17.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#990000").ss(0.3,1,1).p("Ag/g/IAGAGIAFAFABABAIgEgE");
	this.shape_3.setTransform(23.1,23.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#FFFFFF","#999999"],[0.376,1],-0.2,-0.2,0,-0.2,-0.2,21.2).s().p("AgCgCIAAAAIAFAFg");
	this.shape_4.setTransform(17.5,17.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["#FF0000","#760101"],[0,1],0.3,-1.9,0,0.3,-1.9,19.6).s().p("AADADIgFgFIAFAFg");
	this.shape_5.setTransform(17,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 2
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FF33CC").ss(1,1,1).p("AB6B6QgzAyhHAAQhGAAgygyQgzgzAAhHQAAhGAzgyQAygzBGAAQBHAAAzAzQAyAyAABGQAABHgyAzg");
	this.shape_6.setTransform(17.2,17.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["#FE78D7","#CF0593"],[0.365,1],0,0,0,0,0,17.8).s().p("Ah5B5QgygyAAhHQAAhGAygzQAzgyBGAAQBHAAAyAyQAzAzAABGQAABHgzAyQgyAzhHAAQhGAAgzgzg");
	this.shape_7.setTransform(17.2,17.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__CballPink, new cjs.Rectangle(-1,-1,36.5,36.5), null);


(lib.TC_TObject__CballNone = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").ss(1.5,1,1).p("AB6h5QAzAyAABHQAABHgxAyQgBAAAAABIgBAAQgEAEgFAFQgwAqhBAAQhHAAgygzQgzgzAAhHQAAgQADgQQAIgtAfgjQAEgFAFgEIAAAAQAygzBHAAQBHAAAzAzIh6B5IAAAAIh5B6AAAAAIgFgFIh0h0AB2B2Qg3g3g3g3QgBgBgBgBIgGgG");
	this.shape.setTransform(17.3,17.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#990000").ss(0.3,1,1).p("Ag0g0IgFgFIgGgGABABAIgEgE");
	this.shape_1.setTransform(23.1,23.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#FFFFFF","#999999"],[0.376,1],-0.2,-0.2,0,-0.2,-0.2,21.2).s().p("AgCgCIAAAAIAFAFg");
	this.shape_2.setTransform(17.5,17.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#FF0000","#760101"],[0,1],0.3,-1.9,0,0.3,-1.9,19.6).s().p("AADADIgFgFIAFAFg");
	this.shape_3.setTransform(17,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__CballNone, new cjs.Rectangle(-1,-1,36.5,36.5), null);


(lib.CballRed = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").ss(1,1,1).p("ACtAAQAABHgxAyQgBAAAAABIgBAAQgEAEgFAFQgwAqhBAAQhHAAgygzQgzgzAAhHQAAgQADgQQAIgtAfgjQAEgFAFgEIAAAAQAygzBHAAQBHAAAzAzQAzAyAABHg");
	this.shape.setTransform(17.3,17.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#999999").ss(0.3,1,1).p("AAAAAIAAAAIh5B6AAAAAIgFgFIh0h0AB2B2Qg3g3g3g3QgBgBgBgBIgGgGAB6h5Ih6B5");
	this.shape_1.setTransform(17.3,17.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#990000").ss(0.3,1,1).p("Ag0g0IgFgFIgGgGABABAIgEgE");
	this.shape_2.setTransform(23.1,23.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#FFFFFF","#999999"],[0.376,1],-0.2,-0.2,0,-0.2,-0.2,21.2).s().p("AgCgCIAAAAIAFAFg");
	this.shape_3.setTransform(17.5,17.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#FF0000","#760101"],[0,1],0.3,-1.9,0,0.3,-1.9,19.6).s().p("AADADIgFgFIAFAFg");
	this.shape_4.setTransform(17,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 2
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#999999").ss(1,1,1).p("AB6B6QgzAyhHAAQhGAAgygyQgzgzAAhHQAAhGAzgyQAygzBGAAQBHAAAzAzQAyAyAABGQAABHgyAzg");
	this.shape_5.setTransform(17.2,17.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.rf(["#FFFF00","#C1C002"],[0.329,1],0,0,0,0,0,17.8).s().p("Ah5B5QgygyAAhHQAAhGAygzQAzgyBGAAQBHAAAyAyQAzAzAABGQAABHgzAyQgyAzhHAAQhGAAgzgzg");
	this.shape_6.setTransform(17.2,17.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.CballRed, new cjs.Rectangle(-1,-1,36.5,36.5), null);


(lib.TC_TObject__arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").ss(2,1,1).p("ABxEoICcAjImHExIi/myICcAbIDGtgIERA/g");
	this.shape.setTransform(-3.3,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0098FF").s().p("Ak5DKICcAbIDGtgIEQA/IjINkICbAjImGExg");
	this.shape_1.setTransform(-3.3,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__arrow, new cjs.Rectangle(-35.7,-63.6,64.7,129.3), null);


(lib.Speedgauge = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AASAxIAAgtIgjAAIAAAtIgLAAIAAhhIALAAIAAArIAjAAIAAgrIALAAIAABhg");
	this.shape.setTransform(44.2,2.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYAxIAAhfQAFgCAFAAIAJgBIAKABQAGACAEADQAFAEACAFQADAGAAAKQAAAIgDAGQgCAGgEADQgFAEgFACQgGACgFAAIgBAAIgDgBIgDAAIgCAAIAAAlgAgOgmIAAAoIACABIADAAIACAAIACAAIAHgBQADgBADgBIAEgHQACgFAAgGQAAgHgCgDQgBgFgCgBQgEgDgDgBIgGgBIgFAAIgFABg");
	this.shape_1.setTransform(37.6,2.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAZAxIAAg/IABgPIAAAAIgEAOIgUApIgDAAIgVgpIgEgOIgBAAIADAPIAAA/IgKAAIAAhhIAJAAIAXAwIADALIADgLIAWgwIAJAAIAABhg");
	this.shape_2.setTransform(29.7,2.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(0.1,1,1).p("AnfAAIO/AA");
	this.shape_3.setTransform(-1.5,10.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().ls(["#4F4F4F","#777777","#CDCDCD","#777777","#000000"],[0.024,0.141,0.173,0.42,1],-62.8,0,62.9,0).ss(6.8,1,1).p("AoElEIQJAAQBUAAAABkIAAHBQAABkhUAAIwJAAQhUAAAAhkIAAnBQAAhkBUAAg");

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AoEFFQhTAAAAhkIAAnBQAAhkBTAAIQJAAQBTAAAABkIAAHBQAABkhTAAgAHRBpIu/AAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Speedgauge, new cjs.Rectangle(-63.4,-35.8,126.8,71.7), null);


(lib.Redbutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(1,1,1).p("AAkAAQAAAPgLAKQgKALgPAAQgOAAgKgLQgLgKAAgPQAAgOALgKQAKgLAOAAQAPAAAKALQALAKAAAOg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("AgYAZQgLgLABgOQgBgNALgLQALgLANABQAOgBALALQALALgBANQABAOgLALQgLALgOgBQgNABgLgLg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Redbutton, new cjs.Rectangle(-4.5,-4.5,9.1,9.1), null);


(lib.graybar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("A0PgmMAofAAAIAABNMgofAAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s().p("A0OAnIAAhNMAodAAAIAABNg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.graybar, new cjs.Rectangle(-130.5,-4.9,261.1,9.9), null);


(lib.EIIntro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 3DGridWall.png
	this.instance = new lib._3DGridWall();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.EIIntro, new cjs.Rectangle(0,0,1024,768), null);


(lib.Border = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3.3,1,1).rr(-396.5,-296,793,592,20);
	this.shape.setTransform(396.5,296);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Border, new cjs.Rectangle(-1.6,-1.6,796.2,595.2), null);


(lib.ef_TutorModule = function(options) {
	this._element = new $.ef.TutorModule(options);
	this._el = this._element.create();
	var $this = this;
	this.addEventListener('added', function() {
		$this._lastAddedFrame = $this.parent.currentFrame;
		$this._element.attach($('#dom_overlay_container'));
	});
}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,100,100);

p._tick = _tick;
p._handleDrawEnd = _handleDrawEnd;
p._updateVisibility = _updateVisibility;



(lib.playButtonTop = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(30,1,1).p("Ai9FkIAArHIF7Fjg");
	this.shape.setTransform(19,35.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.playButtonTop, new cjs.Rectangle(-15,-15,68,101.2), null);


(lib.contentFrame = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#FFFFFF").ss(1,1,1).rc(-866.5,-523.4,1733,1046.8,11.4,11.4,-110,-110);
	this.shape.setTransform(866.5,523.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.contentFrame, new cjs.Rectangle(-1,-1,1735,1048.8), null);


(lib.TextArea = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s("#CCCCCC").ss(1,1,1).dr(-50,-50,100,100);
	this.shape.setTransform(50,50);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TextArea, new cjs.Rectangle(-1,-1,102,102), null);


(lib.cmuwozrampsimCGrabSolid = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Arrow1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,6.4,0.301,0.301,0,180,0);

	this.instance_1 = new lib.Arrow1("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,-6.3,0.301,0.301);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AhpivIDTAAQBGAAAABGIAADTQAABGhGAAIjTAAQhGAAAAhGIAAjTQAAhGBGAAg");
	this.shape.setTransform(0,0,0.643,0.893);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AhpCwQhGAAAAhGIAAjTQAAhGBGAAIDTAAQBGAAAABGIAADTQAABGhGAAg");
	this.shape_1.setTransform(0,0,0.643,0.893);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.cmuwozrampsimCGrabSolid, new cjs.Rectangle(-12.3,-16.7,24.7,33.5), null);


(lib.cmuwozrampsimCGateSolid = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// grab
	this.Sgrab = new lib.cmuwozrampsimCGrabSolid();
	this.Sgrab.name = "Sgrab";
	this.Sgrab.parent = this;
	this.Sgrab.setTransform(5.3,3.7,1,0.998,90);
	this.Sgrab.cache(-14,-19,29,38);

	this.timeline.addTween(cjs.Tween.get(this.Sgrab).wait(1));

	// door
	this.Sdoor = new lib.CdoorSolid();
	this.Sdoor.name = "Sdoor";
	this.Sdoor.parent = this;
	this.Sdoor.setTransform(5,-25,0.998,1,0,0,0,5,-25);
	this.Sdoor.cache(-3,-53,16,56);

	this.timeline.addTween(cjs.Tween.get(this.Sdoor).wait(1));

}).prototype = getMCSymbolPrototype(lib.cmuwozrampsimCGateSolid, new cjs.Rectangle(-10.9,-50.5,32.4,66), null);


(lib.CAngleCueLow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Angle Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ax+tpMAq2AN2Im5VUMgq2gN3g");
	mask.setTransform(86.8,137.7);

	// outline
	this.Soutline = new lib.CangleCueOutline();
	this.Soutline.name = "Soutline";
	this.Soutline.parent = this;
	this.Soutline.setTransform(168.8,63.4,1,1,0,0,0,168.8,63.4);

	var maskedShapeInstanceList = [this.Soutline];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.Soutline).wait(1));

	// solid
	this.Ssolid = new lib.CangleCueSolid();
	this.Ssolid.name = "Ssolid";
	this.Ssolid.parent = this;
	this.Ssolid.setTransform(168.8,63.4,1,1,0,0,0,77.6,77.3);

	var maskedShapeInstanceList = [this.Ssolid];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.Ssolid).wait(1));

}).prototype = getMCSymbolPrototype(lib.CAngleCueLow, new cjs.Rectangle(90.7,50.2,155.5,90.4), null);


(lib.CAngleCueHigh = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Angle Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("As01oMAl0AYeIsLSzMgl0gYeg");
	mask.setTransform(86.6,120);

	// outline
	this.Soutline = new lib.CangleCueOutline();
	this.Soutline.name = "Soutline";
	this.Soutline.parent = this;
	this.Soutline.setTransform(168.8,63.4,1,1,0,0,0,168.8,63.4);

	var maskedShapeInstanceList = [this.Soutline];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.Soutline).wait(1));

	// solid
	this.Ssolid = new lib.CangleCueSolid();
	this.Ssolid.name = "Ssolid";
	this.Ssolid.parent = this;
	this.Ssolid.setTransform(168.8,63.4,1,1,0,0,0,77.6,77.3);

	var maskedShapeInstanceList = [this.Ssolid];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.Ssolid).wait(1));

}).prototype = getMCSymbolPrototype(lib.CAngleCueHigh, new cjs.Rectangle(90.7,-14.4,156,155), null);


(lib.TC_TObject__VarsSteep = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CHinge();
	this.instance.parent = this;
	this.instance.setTransform(236.8,91.5,1.566,1.566,32.8);

	this.instance_1 = new lib.cmuwozrampsimCGrabSolid();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-169.3,-169.5,1.566,1.566,32.8,0,0,0.1,0.1);

	this.instance_2 = new lib.TC_TObject__CinclineSmooth();
	this.instance_2.parent = this;
	this.instance_2.setTransform(42.1,-32.7,1.566,1.566,32.8,0,0,149.5,5.2);

	this.instance_3 = new lib.graybar();
	this.instance_3.parent = this;
	this.instance_3.setTransform(89,95.7,1.741,1.793,0,0,0,41.5,0.8);

	this.instance_4 = new lib.CAngleCueHigh();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-183.6,35.5,2.577,2.577,0,0,0,87.5,120);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__VarsSteep, new cjs.Rectangle(-600.2,-323.1,849,717.4), null);


(lib.TC_TObject__VarsSmooth = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CHinge();
	this.instance.parent = this;
	this.instance.setTransform(236.8,91.5,1.566,1.566,32.8);

	this.instance_1 = new lib.cmuwozrampsimCGrabSolid();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-223,-55.5,1.566,1.566,17.8,0,0,0.1,0.1);

	this.instance_2 = new lib.TC_TObject__CinclineSmooth();
	this.instance_2.parent = this;
	this.instance_2.setTransform(16.4,22,1.566,1.566,17.8,0,0,149.5,5.3);

	this.instance_3 = new lib.graybar();
	this.instance_3.parent = this;
	this.instance_3.setTransform(89,95.7,1.741,1.793,0,0,0,41.5,0.8);

	this.instance_4 = new lib.CAngleCueLow();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-181.7,65.5,2.581,2.581,0,0,0,88,130.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__VarsSmooth, new cjs.Rectangle(-597.2,-309.2,846,749.2), null);


(lib.TC_TObject__VarsRough = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CHinge();
	this.instance.parent = this;
	this.instance.setTransform(236.8,91.5,1.566,1.566,32.8);

	this.instance_1 = new lib.cmuwozrampsimCGrabSolid();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-223,-55.5,1.566,1.566,17.8,0,0,0.1,0.1);

	this.instance_2 = new lib.TC_TObject__CinclineRoughNew();
	this.instance_2.parent = this;
	this.instance_2.setTransform(16.4,22,1.566,1.566,17.8,0,0,149.5,5.3);

	this.instance_3 = new lib.graybar();
	this.instance_3.parent = this;
	this.instance_3.setTransform(89,95.7,1.741,1.793,0,0,0,41.5,0.8);

	this.instance_4 = new lib.CAngleCueLow();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-181.7,65.5,2.581,2.581,0,0,0,88,130.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__VarsRough, new cjs.Rectangle(-597.2,-309.2,846,749.2), null);


(lib.TC_TObject__VarsNotSteep = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CHinge();
	this.instance.parent = this;
	this.instance.setTransform(236.8,91.5,1.566,1.566,32.8);

	this.instance_1 = new lib.cmuwozrampsimCGrabSolid();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-223,-55.5,1.566,1.566,17.8,0,0,0.1,0.1);

	this.instance_2 = new lib.TC_TObject__CinclineSmooth();
	this.instance_2.parent = this;
	this.instance_2.setTransform(16.4,22,1.566,1.566,17.8,0,0,149.5,5.3);

	this.instance_3 = new lib.graybar();
	this.instance_3.parent = this;
	this.instance_3.setTransform(89,95.7,1.741,1.793,0,0,0,41.5,0.8);

	this.instance_4 = new lib.CAngleCueLow();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-181.7,65.5,2.581,2.581,0,0,0,88,130.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__VarsNotSteep, new cjs.Rectangle(-597.2,-309.2,846,749.2), null);


(lib.TC_TObject__Ramp_steep_middle_yellowball = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CHinge();
	this.instance.parent = this;
	this.instance.setTransform(108.7,74.4,0.783,0.783,32.8);

	this.instance_1 = new lib.cmuwozrampsimCGateSolid();
	this.instance_1.parent = this;
	this.instance_1.setTransform(32.9,14.4,0.783,0.783,32.8,0,0,5.1,-17.2);

	this.ball1 = new lib.TC_TObject__CballYellow();
	this.ball1.name = "ball1";
	this.ball1.parent = this;
	this.ball1.setTransform(22.7,-2.6,0.783,0.783,32.8,0,0,17.3,17.3);

	this.instance_2 = new lib.cmuwozrampsimCGrabSolid();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-96,-57.9,0.783,0.783,32.8);

	this.instance_3 = new lib.TC_TObject__CinclineSmooth();
	this.instance_3.parent = this;
	this.instance_3.setTransform(9.6,10.6,0.783,0.783,32.8,0,0,149.5,5.2);

	this.instance_4 = new lib.graybar();
	this.instance_4.parent = this;
	this.instance_4.setTransform(34.8,75.9,0.87,0.897,0,0,0,41.5,0.8);

	this.instance_5 = new lib.CAngleCueHigh();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-54,58.6,1.033,1.033,0,0,0,87.6,120);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.ball1},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Ramp_steep_middle_yellowball, new cjs.Rectangle(-221.2,-85.1,335.9,287.6), null);


(lib.Ramp_noball = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CHinge();
	this.instance.parent = this;
	this.instance.setTransform(108.7,74.4,0.783,0.783,32.8);

	this.instance_1 = new lib.cmuwozrampsimCGateSolid();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-47.8,-37.7,0.783,0.783,32.8,0,0,5.1,-17.2);

	this.instance_2 = new lib.cmuwozrampsimCGrabSolid();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-96,-57.9,0.783,0.783,32.8);

	this.instance_3 = new lib.TC_TObject__CinclineSmooth();
	this.instance_3.parent = this;
	this.instance_3.setTransform(9.6,10.6,0.783,0.783,32.8,0,0,149.5,5.2);

	this.instance_4 = new lib.graybar();
	this.instance_4.parent = this;
	this.instance_4.setTransform(34.8,75.9,0.87,0.897,0,0,0,41.5,0.8);

	this.instance_5 = new lib.CAngleCueHigh();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-54,58.6,1.033,1.033,0,0,0,87.6,120);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Ramp_noball, new cjs.Rectangle(-221.2,-85.1,335.9,287.6), null);


(lib.BGGridWall = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Border
	this.instance = new lib.Border();
	this.instance.parent = this;
	this.instance.setTransform(396.4,295.9,1,1,0,0,0,396.4,295.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Eg60guPMB1pAAAQAhAAAeAKQAeALAZASQAZASASAZQASAZAKAeQAKAeABAhMAAABWPQgBAhgKAeQgKAegSAZQgSAZgZASQgZASgeALQgeAKghAAMh1pAAAQgpgBgkgPQglgPgbgcQgbgbgQgkQgPglgBgpMAAAhWPQABghAKgeQAKgeASgZQASgZAZgSQAZgSAegLQAegKAhAAg");
	mask.setTransform(396.5,296);

	// EIIntro
	this.instance_1 = new lib.EIIntro();
	this.instance_1.parent = this;
	this.instance_1.setTransform(396.1,297,0.772,0.772,0,0,0,512,383.9);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.BGGridWall, new cjs.Rectangle(-1.6,-1.6,796.1,595.2), null);


(lib.SceneRegion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// SbackMask
	this.instance = new lib.contentFrame();
	this.instance.parent = this;
	this.instance.setTransform(960,587.5,1,1,0,0,0,866.5,523.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s("#000066").ss(2.5,1,1).dr(-960,-600,1920,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.SceneRegion, new cjs.Rectangle(-1.2,-1.2,1922.5,1202.5), null);


(lib.playup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.playButtonTop();
	this.instance.parent = this;
	this.instance.setTransform(5,0,1,1,0,0,0,19,35.6);
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#333333").ss(10.6,1,1).de(-86,-86,172,172);
	this.shape.setTransform(-4,0,1,1,-90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.playup, new cjs.Rectangle(-95.3,-91.3,182.6,182.6), null);


(lib.TC_THtmlText__Text1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.SControlContainer = new lib.TextArea();
	this.SControlContainer.name = "SControlContainer";
	this.SControlContainer.parent = this;
	this.SControlContainer.setTransform(50,50,1,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.SControlContainer).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_THtmlText__Text1, new cjs.Rectangle(-0.5,-0.5,101,101), null);


(lib.TC_THtmlText__CallOutText = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.SControlContainer = new lib.TextArea();
	this.SControlContainer.name = "SControlContainer";
	this.SControlContainer.parent = this;
	this.SControlContainer.setTransform(50,50,1,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.SControlContainer).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_THtmlText__CallOutText, new cjs.Rectangle(-0.5,-0.5,101,101), null);


(lib.TC_TObject__Topic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Svar3b
	this.Svar3b = new lib.TC_TObject__Ramp_steep_middle_yellowball();
	this.Svar3b.name = "Svar3b";
	this.Svar3b.parent = this;
	this.Svar3b.setTransform(131.1,298.4,2.156,2.156,0,0,0,-53.3,58.7);

	this.timeline.addTween(cjs.Tween.get(this.Svar3b).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Topic, new cjs.Rectangle(-230.8,-11.7,724.1,620.1), null);


(lib.TC_TObject__Movie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_7
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(1,1,1).p("AAkAAQAAAOgLALQgKALgPAAQgNAAgLgLQgKgLAAgOQAAgNAKgLQALgLANAAQAPAAAKALQALALAAANg");
	this.shape.setTransform(258.7,311.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#660000").s().p("AgYAZQgLgLAAgOQAAgOALgKQALgKANAAQAPAAAKAKQAKAKAAAOQAAAOgKALQgKALgPAAQgNAAgLgLg");
	this.shape_1.setTransform(258.7,311.1);

	this.instance = new lib.Redbutton();
	this.instance.parent = this;
	this.instance.setTransform(258.7,311.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.instance}]},23).to({state:[{t:this.shape_1},{t:this.shape}]},2).wait(94));

	// Layer_6
	this.instance_1 = new lib.Carrow("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(258.1,290.1,0.433,0.433,0,0,0,16.1,34.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(23).to({_off:false},0).wait(96));

	// Layer_4
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AguBgQAUgCARgJQAQgHAMgNQAMgMAHgRQAIgQAEgSIgLAJIgMAGIgOADIgQAAQgPAAgNgEQgNgEgKgJQgKgHgGgMQgFgMAAgPQAAgPAEgNQAFgNAKgKQAKgKAOgFQAPgGARAAQASAAAPAGQAOAGAJAKQAKALAFAOQAFAPABATQgBAigIAcQgKAbgPATQgRASgVALQgVAKgaADgAgkhRQgNAMAAAXQAAAXANALQAOAMAWAAQATAAANgGQAOgFAFgJIABgGIAAgHQAAgLgEgLQgDgLgGgJQgHgIgJgFQgKgGgNAAQgYAAgMANg");
	this.shape_2.setTransform(258.4,340);
	this.shape_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(23).to({_off:false},0).wait(96));

	// Layer_3
	this.instance_2 = new lib.Speedgauge();
	this.instance_2.parent = this;
	this.instance_2.setTransform(259.4,343.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(119));

	// Layer_2
	this.ball1 = new lib.CballRed();
	this.ball1.name = "ball1";
	this.ball1.parent = this;
	this.ball1.setTransform(83.6,140.7,0.783,0.783,32.8,0,0,17.3,17.3);

	this.timeline.addTween(cjs.Tween.get(this.ball1).wait(6).to({regX:16.8,regY:17.2,scaleX:0.78,scaleY:0.78,x:105.5,y:153.7},0).wait(1).to({regX:17.3,regY:17.3,scaleX:0.78,scaleY:0.78,rotation:32.9,x:118.3,y:161.6},0).wait(1).to({x:130.8,y:169.2},0).wait(1).to({x:138.5,y:174.2},0).wait(1).to({x:146.1,y:179.2},0).wait(1).to({x:153.8,y:184.2},0).wait(1).to({x:159.1,y:187.9},0).wait(1).to({x:164.4,y:191.7},0).wait(1).to({x:169.7,y:195.4},0).wait(1).to({x:175.1,y:199.1},0).wait(1).to({x:186.4,y:206.1},0).wait(1).to({x:197.7,y:213.1},0).wait(1).to({x:209.1,y:220.1},0).wait(1).to({x:228.6,y:232.8},0).wait(1).to({x:248.1,y:245.5},0).wait(3).to({regX:17.4,regY:17.2,rotation:52.8,x:254,y:249.4},0).wait(2).to({regX:17.3,regY:16.7,rotation:-27.1,x:298.1,y:252.6},0).wait(3).to({regX:17.7,regY:16.6,scaleX:0.78,scaleY:0.78,rotation:-172.2,x:366,y:253.6},0).wait(5).to({rotation:-52.2,x:402,y:252.5},0).wait(2).to({regX:17.8,regY:16.7,rotation:-7.2,x:409.1},0).wait(3).to({regY:16.4,rotation:157.8,x:431,y:252.6},0).wait(4).to({regX:17.6,regY:16.6,rotation:277.8,x:446.1,y:252.5},0).wait(2).to({regX:17.7,rotation:367.8,x:457},0).wait(3).to({regX:17.9,regY:16.5,rotation:457.8,x:475.1,y:254.6},0).wait(2).to({regY:16.3,x:515,y:253.6},0).wait(3).to({regX:17.8,regY:16.6,rotation:397.8,x:518.1,y:253.7},0).to({_off:true},66).wait(1));

	// Layer 1
	this.instance_3 = new lib.CHinge();
	this.instance_3.parent = this;
	this.instance_3.setTransform(253.7,269.4,0.783,0.783,32.8);

	this.Sgrab = new lib.cmuwozrampsimCGrabSolid();
	this.Sgrab.name = "Sgrab";
	this.Sgrab.parent = this;
	this.Sgrab.setTransform(85.1,168.5,0.783,0.782,122.8);
	this.Sgrab.cache(-14,-19,29,38);

	this.Sdoor = new lib.CdoorSolid();
	this.Sdoor.name = "Sdoor";
	this.Sdoor.parent = this;
	this.Sdoor.setTransform(93.9,157.5,0.782,0.783,32.8,0,0,5,-25.1);
	this.Sdoor.cache(-3,-53,16,56);

	this.instance_4 = new lib.cmuwozrampsimCGrabSolid();
	this.instance_4.parent = this;
	this.instance_4.setTransform(49,137.2,0.783,0.783,32.8);

	this.instance_5 = new lib.TC_TObject__CinclineSmooth();
	this.instance_5.parent = this;
	this.instance_5.setTransform(154.6,205.6,0.783,0.783,32.8,0,0,149.5,5.2);

	this.instance_6 = new lib.CbaseNull();
	this.instance_6.parent = this;
	this.instance_6.setTransform(271.8,267,0.87,0.897,0,0,0,41.5,0.8);

	this.instance_7 = new lib.CAngleCueHigh();
	this.instance_7.parent = this;
	this.instance_7.setTransform(91,253.7,1.033,1.033,0,0,0,87.6,120);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.Sdoor,p:{x:93.9,y:157.5}},{t:this.Sgrab},{t:this.instance_3}]}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.Sdoor,p:{x:79.9,y:178.5}},{t:this.Sgrab},{t:this.instance_3}]},3).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.Sdoor,p:{x:79.9,y:178.5}},{t:this.Sgrab},{t:this.instance_3}]},3).wait(113));

	// Layer_5
	this.instance_8 = new lib.BGGridWall();
	this.instance_8.parent = this;
	this.instance_8.setTransform(275.9,194,0.696,0.696,0,0,0,396.4,295.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(119));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-76.2,-13,629.1,414.2);


(lib.TC_TObject__StartingGateNone = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// CGateSolid
	this.instance = new lib.cmuwozrampsimCGateSolid();
	this.instance.parent = this;
	this.instance.setTransform(29.4,35.3,0.783,0.783,32.8,0,0,5.1,-17.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Svar2b
	this.Svar2a = new lib.TC_TObject__CballNone();
	this.Svar2a.name = "Svar2a";
	this.Svar2a.parent = this;
	this.Svar2a.setTransform(18.7,18.8,0.783,0.783,32.8,0,0,17.3,17.3);

	this.timeline.addTween(cjs.Tween.get(this.Svar2a).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__StartingGateNone, new cjs.Rectangle(-0.8,-0.8,47.8,64.6), null);


(lib.TC_TObject__StartingGate = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// CGateSolid
	this.instance = new lib.cmuwozrampsimCGateSolid();
	this.instance.parent = this;
	this.instance.setTransform(29.4,35.3,0.783,0.783,32.8,0,0,5.1,-17.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Svar2b
	this.Svar2a = new lib.TC_TObject__CballYellow();
	this.Svar2a.name = "Svar2a";
	this.Svar2a.parent = this;
	this.Svar2a.setTransform(18.7,18.8,0.783,0.783,32.8,0,0,17.3,17.3);

	this.timeline.addTween(cjs.Tween.get(this.Svar2a).wait(1));

	// Svar2b
	this.Svar2b = new lib.TC_TObject__CballPink();
	this.Svar2b.name = "Svar2b";
	this.Svar2b.parent = this;
	this.Svar2b.setTransform(18.7,18.8,0.783,0.783,32.8,0,0,17.3,17.3);

	this.timeline.addTween(cjs.Tween.get(this.Svar2b).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__StartingGate, new cjs.Rectangle(-0.5,-0.5,47.6,64.3), null);


(lib.TC_TObject__RampSteep = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Svar3a
	this.Svar3a = new lib.TC_TObject__StartingGate();
	this.Svar3a.name = "Svar3a";
	this.Svar3a.parent = this;
	this.Svar3a.setTransform(130.5,81.1,1,1,0,0,0,26.9,31.6);

	this.timeline.addTween(cjs.Tween.get(this.Svar3a).wait(1));

	// Svar3b
	this.Svar3b = new lib.TC_TObject__StartingGate();
	this.Svar3b.name = "Svar3b";
	this.Svar3b.parent = this;
	this.Svar3b.setTransform(64.3,38.3,1,1,0,0,0,26.9,31.6);

	this.timeline.addTween(cjs.Tween.get(this.Svar3b).wait(1));

	// Grab
	this.Grab = new lib.cmuwozrampsimCGrabSolid();
	this.Grab.name = "Grab";
	this.Grab.parent = this;
	this.Grab.setTransform(18.1,21.8,0.783,0.783,32.8);

	this.timeline.addTween(cjs.Tween.get(this.Grab).wait(1));

	// CHinge
	this.instance = new lib.CHinge();
	this.instance.parent = this;
	this.instance.setTransform(222.8,154.1,0.783,0.783,32.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Svar4a
	this.Svar4a = new lib.TC_TObject__CinclineRoughNew();
	this.Svar4a.name = "Svar4a";
	this.Svar4a.parent = this;
	this.Svar4a.setTransform(122.5,91.3,0.783,0.783,32.8,0,0,149.5,5.2);

	this.timeline.addTween(cjs.Tween.get(this.Svar4a).wait(1));

	// Svar4b
	this.Svar4b = new lib.TC_TObject__CinclineSmooth();
	this.Svar4b.name = "Svar4b";
	this.Svar4b.parent = this;
	this.Svar4b.setTransform(123.3,90.4,0.783,0.783,32.8,0,0,149.5,5.2);

	this.timeline.addTween(cjs.Tween.get(this.Svar4b).wait(1));

	// graybar
	this.instance_1 = new lib.graybar();
	this.instance_1.parent = this;
	this.instance_1.setTransform(148.9,156.1,0.87,0.897,0,0,0,41.5,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// CAngleCueHigh
	this.instance_2 = new lib.CAngleCueHigh();
	this.instance_2.parent = this;
	this.instance_2.setTransform(60.1,138.3,1.033,1.033,0,0,0,87.6,120);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__RampSteep, new cjs.Rectangle(-107.1,-5.4,335.9,287.6), null);


(lib.TC_TObject__RampNotSteep = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Grab
	this.Grab = new lib.cmuwozrampsimCGrabSolid();
	this.Grab.name = "Grab";
	this.Grab.parent = this;
	this.Grab.setTransform(-9.1,79.3,0.783,0.783,17.8);

	this.timeline.addTween(cjs.Tween.get(this.Grab).wait(1));

	// Hinge
	this.Hinge = new lib.CHinge();
	this.Hinge.name = "Hinge";
	this.Hinge.parent = this;
	this.Hinge.setTransform(222.8,154.1,0.783,0.783,32.8);

	this.timeline.addTween(cjs.Tween.get(this.Hinge).wait(1));

	// Svar3a
	this.Svar3a = new lib.TC_TObject__StartingGate();
	this.Svar3a.name = "Svar3a";
	this.Svar3a.parent = this;
	this.Svar3a.setTransform(114.8,107.6,1,1,-15,0,0,26.9,31.7);

	this.timeline.addTween(cjs.Tween.get(this.Svar3a).wait(1));

	// Svar3b
	this.Svar3b = new lib.TC_TObject__StartingGate();
	this.Svar3b.name = "Svar3b";
	this.Svar3b.parent = this;
	this.Svar3b.setTransform(39.8,83.3,1,1,-15,0,0,26.9,31.7);

	this.timeline.addTween(cjs.Tween.get(this.Svar3b).wait(1));

	// Svar4a
	this.Svar4a = new lib.TC_TObject__CinclineRoughNew();
	this.Svar4a.name = "Svar4a";
	this.Svar4a.parent = this;
	this.Svar4a.setTransform(109.7,119.5,0.783,0.783,17.8,0,0,149.5,5.3);

	this.timeline.addTween(cjs.Tween.get(this.Svar4a).wait(1));

	// Svar4b
	this.Svar4b = new lib.TC_TObject__CinclineSmooth();
	this.Svar4b.name = "Svar4b";
	this.Svar4b.parent = this;
	this.Svar4b.setTransform(110.3,118.3,0.783,0.783,17.8,0,0,149.6,5.2);

	this.timeline.addTween(cjs.Tween.get(this.Svar4b).wait(1));

	// Base
	this.Base = new lib.graybar();
	this.Base.name = "Base";
	this.Base.parent = this;
	this.Base.setTransform(148.9,156.1,0.87,0.897,0,0,0,41.5,0.8);

	this.timeline.addTween(cjs.Tween.get(this.Base).wait(1));

	// AngleCue
	this.AngleCue = new lib.CAngleCueLow();
	this.AngleCue.name = "AngleCue";
	this.AngleCue.parent = this;
	this.AngleCue.setTransform(60.1,138.3,1.033,1.033,0,0,0,87.6,120);

	this.timeline.addTween(cjs.Tween.get(this.AngleCue).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__RampNotSteep, new cjs.Rectangle(-105.8,-0.5,334.6,300), null);


(lib.TC_TObject__VarsTop = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TC_TObject__StartingGateNone();
	this.instance.parent = this;
	this.instance.setTransform(-98.4,-150,1.791,1.791,0,0,0,26.9,31.6);

	this.instance_1 = new lib.CHinge();
	this.instance_1.parent = this;
	this.instance_1.setTransform(236.8,91.5,1.566,1.566,32.8);

	this.instance_2 = new lib.cmuwozrampsimCGrabSolid();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-169.3,-169.5,1.566,1.566,32.8,0,0,0.1,0.1);

	this.instance_3 = new lib.TC_TObject__CinclineNone();
	this.instance_3.parent = this;
	this.instance_3.setTransform(42.1,-32.7,1.566,1.566,32.8,0,0,149.5,5.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__VarsTop, new cjs.Rectangle(-198.7,-208.1,447.5,311.5), null);


(lib.TC_TObject__VarsMiddle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TC_TObject__StartingGateNone();
	this.instance.parent = this;
	this.instance.setTransform(34.6,-64,1.791,1.791,0,0,0,26.9,31.6);

	this.instance_1 = new lib.CHinge();
	this.instance_1.parent = this;
	this.instance_1.setTransform(236.8,91.5,1.566,1.566,32.8);

	this.instance_2 = new lib.cmuwozrampsimCGrabSolid();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-169.3,-169.5,1.566,1.566,32.8,0,0,0.1,0.1);

	this.instance_3 = new lib.TC_TObject__CinclineNone();
	this.instance_3.parent = this;
	this.instance_3.setTransform(42.1,-32.7,1.566,1.566,32.8,0,0,149.5,5.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__VarsMiddle, new cjs.Rectangle(-198.7,-201.1,447.5,304.5), null);


(lib.Ramps1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Speedgauge();
	this.instance.parent = this;
	this.instance.setTransform(-16.5,149.5);

	this.ball1 = new lib.CballRed();
	this.ball1.name = "ball1";
	this.ball1.parent = this;
	this.ball1.setTransform(-192.3,-53.3,0.783,0.783,32.8,0,0,17.3,17.3);

	this.instance_1 = new lib.CHinge();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-22.1,75.4,0.783,0.783,32.8);

	this.Sgrab = new lib.cmuwozrampsimCGrabSolid();
	this.Sgrab.name = "Sgrab";
	this.Sgrab.parent = this;
	this.Sgrab.setTransform(-190.7,-25.5,0.783,0.782,122.8);
	this.Sgrab.cache(-14,-19,29,38);

	this.Sdoor = new lib.CdoorSolid();
	this.Sdoor.name = "Sdoor";
	this.Sdoor.parent = this;
	this.Sdoor.setTransform(-181.9,-36.5,0.782,0.783,32.8,0,0,5,-25.1);
	this.Sdoor.cache(-3,-53,16,56);

	this.instance_2 = new lib.cmuwozrampsimCGrabSolid();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-226.9,-56.8,0.783,0.783,32.8);

	this.instance_3 = new lib.TC_TObject__CinclineSmooth();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-121.2,11.6,0.783,0.783,32.8,0,0,149.5,5.2);

	this.instance_4 = new lib.CbaseNull();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-4.1,73,0.87,0.897,0,0,0,41.5,0.8);

	this.instance_5 = new lib.CAngleCueHigh();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-184.9,59.7,1.033,1.033,0,0,0,87.6,120);

	this.instance_6 = new lib.BGGridWall();
	this.instance_6.parent = this;
	this.instance_6.setTransform(0,0,0.696,0.696,0,0,0,396.4,295.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(1,1,1).p("AAjAAQAAAPgKAKQgLAKgOAAQgNAAgLgKQgLgKAAgPQAAgOALgKQALgKANAAQAOAAALAKQAKAKAAAOg");
	this.shape.setTransform(-17.2,117.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#660000").s().p("AgYAZQgLgKAAgPQAAgOALgKQALgLANAAQAOAAALALQAKAKAAAOQAAAPgKAKQgLALgOgBQgNABgLgLg");
	this.shape_1.setTransform(-17.2,117.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.Sdoor},{t:this.Sgrab},{t:this.instance_1},{t:this.ball1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Ramps1, new cjs.Rectangle(-352,-207,629.1,414.2), null);


(lib.ramps_scene5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Redbutton();
	this.instance.parent = this;
	this.instance.setTransform(-17.2,117.1);

	this.instance_1 = new lib.Carrow("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-17.7,96.1,0.433,0.433,0,0,0,16.1,34.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgrBZQgPgNgDgYIAXgCQADARAJAHQAJAIANAAQAKAAAIgFQAJgFAGgJQAFgJAEgPQADgOAAgQIAAgFQgHAMgNAIQgNAHgNAAQgaAAgRgSQgRgRAAgeQAAgeASgTQASgSAbAAQASAAARAKQAQALAJATQAIAUAAAkQAAAmgIAXQgJAWgQAMQgRAMgVAAQgXAAgPgNgAgchEQgMAOAAAVQAAATAMAMQAMALAQAAQARAAALgLQAKgMABgVQgBgVgKgNQgMgMgQAAQgPAAgNANg");
	this.shape.setTransform(-17.5,145.3);

	this.instance_2 = new lib.Speedgauge();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-16.5,149.5);

	this.ball1 = new lib.CballRed();
	this.ball1.name = "ball1";
	this.ball1.parent = this;
	this.ball1.setTransform(-21.8,55.4,0.783,0.783,52.8,0,0,17.4,17.2);

	this.instance_3 = new lib.CHinge();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-22.1,75.4,0.783,0.783,32.8);

	this.Sgrab = new lib.cmuwozrampsimCGrabSolid();
	this.Sgrab.name = "Sgrab";
	this.Sgrab.parent = this;
	this.Sgrab.setTransform(-190.7,-25.5,0.783,0.782,122.8);
	this.Sgrab.cache(-14,-19,29,38);

	this.Sdoor = new lib.CdoorSolid();
	this.Sdoor.name = "Sdoor";
	this.Sdoor.parent = this;
	this.Sdoor.setTransform(-195.9,-15.5,0.782,0.783,32.8,0,0,5,-25.1);
	this.Sdoor.cache(-3,-53,16,56);

	this.instance_4 = new lib.cmuwozrampsimCGrabSolid();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-226.9,-56.8,0.783,0.783,32.8);

	this.instance_5 = new lib.TC_TObject__CinclineSmooth();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-121.2,11.6,0.783,0.783,32.8,0,0,149.5,5.2);

	this.instance_6 = new lib.CbaseNull();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-4.1,73,0.87,0.897,0,0,0,41.5,0.8);

	this.instance_7 = new lib.CAngleCueHigh();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-184.9,59.7,1.033,1.033,0,0,0,87.6,120);

	this.instance_8 = new lib.BGGridWall();
	this.instance_8.parent = this;
	this.instance_8.setTransform(0,0,0.696,0.696,0,0,0,396.4,295.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.Sdoor},{t:this.Sgrab},{t:this.instance_3},{t:this.ball1},{t:this.instance_2},{t:this.shape},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ramps_scene5, new cjs.Rectangle(-352,-207,629.1,414.2), null);


(lib.ramps_scene3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Speedgauge();
	this.instance.parent = this;
	this.instance.setTransform(-16.5,149.5);

	this.ball1 = new lib.CballRed();
	this.ball1.name = "ball1";
	this.ball1.parent = this;
	this.ball1.setTransform(-28.1,51.2,0.782,0.782,32.8,0,0,16.8,17.2);

	this.instance_1 = new lib.CHinge();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-22.1,75.4,0.783,0.783,32.8);

	this.Sgrab = new lib.cmuwozrampsimCGrabSolid();
	this.Sgrab.name = "Sgrab";
	this.Sgrab.parent = this;
	this.Sgrab.setTransform(-190.7,-25.5,0.783,0.782,122.8);
	this.Sgrab.cache(-14,-19,29,38);

	this.Sdoor = new lib.CdoorSolid();
	this.Sdoor.name = "Sdoor";
	this.Sdoor.parent = this;
	this.Sdoor.setTransform(-195.9,-15.5,0.782,0.783,32.8,0,0,5,-25.1);
	this.Sdoor.cache(-3,-53,16,56);

	this.instance_2 = new lib.cmuwozrampsimCGrabSolid();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-226.9,-56.8,0.783,0.783,32.8);

	this.instance_3 = new lib.TC_TObject__CinclineSmooth();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-121.2,11.6,0.783,0.783,32.8,0,0,149.5,5.2);

	this.instance_4 = new lib.CbaseNull();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-4.1,73,0.87,0.897,0,0,0,41.5,0.8);

	this.instance_5 = new lib.CAngleCueHigh();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-184.9,59.7,1.033,1.033,0,0,0,87.6,120);

	this.instance_6 = new lib.BGGridWall();
	this.instance_6.parent = this;
	this.instance_6.setTransform(0,0,0.696,0.696,0,0,0,396.4,295.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(1,1,1).p("AAjAAQAAAPgKAKQgLAKgOAAQgNAAgLgKQgLgKAAgPQAAgOALgKQALgKANAAQAOAAALAKQAKAKAAAOg");
	this.shape.setTransform(-17.2,117.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#660000").s().p("AgYAZQgLgKAAgPQAAgOALgKQALgLANAAQAOAAALALQAKAKAAAOQAAAPgKAKQgLALgOgBQgNABgLgLg");
	this.shape_1.setTransform(-17.2,117.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.Sdoor},{t:this.Sgrab},{t:this.instance_1},{t:this.ball1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ramps_scene3, new cjs.Rectangle(-352,-207,629.1,414.2), null);


(lib.ramps_scene2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Speedgauge();
	this.instance.parent = this;
	this.instance.setTransform(-16.5,149.5);

	this.ball1 = new lib.CballRed();
	this.ball1.name = "ball1";
	this.ball1.parent = this;
	this.ball1.setTransform(-192.3,-53.3,0.783,0.783,32.8,0,0,17.3,17.3);

	this.instance_1 = new lib.CHinge();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-22.1,75.4,0.783,0.783,32.8);

	this.Sgrab = new lib.cmuwozrampsimCGrabSolid();
	this.Sgrab.name = "Sgrab";
	this.Sgrab.parent = this;
	this.Sgrab.setTransform(-190.7,-25.5,0.783,0.782,122.8);
	this.Sgrab.cache(-14,-19,29,38);

	this.Sdoor = new lib.CdoorSolid();
	this.Sdoor.name = "Sdoor";
	this.Sdoor.parent = this;
	this.Sdoor.setTransform(-195.9,-15.5,0.782,0.783,32.8,0,0,5,-25.1);
	this.Sdoor.cache(-3,-53,16,56);

	this.instance_2 = new lib.cmuwozrampsimCGrabSolid();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-226.9,-56.8,0.783,0.783,32.8);

	this.instance_3 = new lib.TC_TObject__CinclineSmooth();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-121.2,11.6,0.783,0.783,32.8,0,0,149.5,5.2);

	this.instance_4 = new lib.CbaseNull();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-4.1,73,0.87,0.897,0,0,0,41.5,0.8);

	this.instance_5 = new lib.CAngleCueHigh();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-184.9,59.7,1.033,1.033,0,0,0,87.6,120);

	this.instance_6 = new lib.BGGridWall();
	this.instance_6.parent = this;
	this.instance_6.setTransform(0,0,0.696,0.696,0,0,0,396.4,295.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(1,1,1).p("AAjAAQAAAPgKAKQgLAKgOAAQgNAAgLgKQgLgKAAgPQAAgOALgKQALgKANAAQAOAAALAKQAKAKAAAOg");
	this.shape.setTransform(-17.2,117.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#660000").s().p("AgYAZQgLgKAAgPQAAgOALgKQALgLANAAQAOAAALALQAKAKAAAOQAAAPgKAKQgLALgOgBQgNABgLgLg");
	this.shape_1.setTransform(-17.2,117.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.Sdoor},{t:this.Sgrab},{t:this.instance_1},{t:this.ball1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ramps_scene2, new cjs.Rectangle(-352,-207,629.1,414.2), null);


(lib.TC_TVirtual__SceneRgn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// background
	this.instance = new lib.SceneRegion();
	this.instance.parent = this;
	this.instance.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TVirtual__SceneRgn, new cjs.Rectangle(-1.2,-1.2,1922.5,1202.5), null);


(lib.TC_TButton__PlayButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// SpinButtonUp
	this.instance = new lib.playup();
	this.instance.parent = this;
	this.instance.setTransform(115.7,86,1,1,0,0,0,115.7,86);
	this.instance.alpha = 0.191;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(4));

	// SpinButtonOver
	this.instance_1 = new lib.playup();
	this.instance_1.parent = this;
	this.instance_1.setTransform(115.7,86,1,1,0,0,0,115.7,86);
	this.instance_1.alpha = 0.191;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({_off:true},1).wait(3));

	// SpinButtonDown
	this.instance_2 = new lib.playup();
	this.instance_2.parent = this;
	this.instance_2.setTransform(115.7,86,1,1,0,0,0,115.7,86);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({_off:false},0).to({_off:true},1).wait(2));

	// SpinButtonDisabled
	this.instance_3 = new lib.playup();
	this.instance_3.parent = this;
	this.instance_3.setTransform(115.7,86.1,1,1,0,0,0,115.7,86.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(3).to({_off:false},0).to({_off:true},1).wait(1));

	// SpinButtonFocus
	this.instance_4 = new lib.playup();
	this.instance_4.parent = this;
	this.instance_4.setTransform(115.7,86,1,1,0,0,0,115.7,86);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(4).to({_off:false},0).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(210,210,210,0.008)").s().p("EhAcAogMAAAhQ/MCA5AAAMAAABQ/g");
	this.shape.setTransform(-0.5,-0.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-413,-260,825,518.5);


(lib.TC_TScene__RQmovie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.Splay = new lib.TC_TButton__PlayButton();
	this.Splay.name = "Splay";
	this.Splay.parent = this;
	this.Splay.setTransform(955.6,598.6,2.424,2.424);
	new cjs.ButtonHelper(this.Splay, 0, 1, 2, false, new lib.TC_TButton__PlayButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Splay).wait(1));

	// Layer_2
	this.Smovie = new lib.TC_TObject__Movie();
	this.Smovie.name = "Smovie";
	this.Smovie.parent = this;
	this.Smovie.setTransform(878.3,600,2.175,2.175,0,0,0,238.3,194);

	this.timeline.addTween(cjs.Tween.get(this.Smovie).wait(1));

	// Layer_1
	this.instance = new lib.TC_TVirtual__SceneRgn();
	this.instance.parent = this;
	this.instance.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__RQmovie, new cjs.Rectangle(-45.6,-31.8,2000,1256.8), null);


(lib.TC_TScene__RQmaterials = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Ball", "bold 45px 'PT Sans'");
	this.text.textAlign = "center";
	this.text.lineHeight = 60;
	this.text.parent = this;
	this.text.setTransform(1445,931.9);

	this.text_1 = new cjs.Text("Speedometer", "bold 45px 'PT Sans'");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 60;
	this.text_1.parent = this;
	this.text_1.setTransform(521.2,931.9);

	this.text_2 = new cjs.Text("A ramp", "bold 45px 'PT Sans'");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 60;
	this.text_2.parent = this;
	this.text_2.setTransform(965.5,649.4);

	this.Sarrow3 = new lib.TC_TObject__arrow();
	this.Sarrow3.name = "Sarrow3";
	this.Sarrow3.parent = this;
	this.Sarrow3.setTransform(1344.9,865.3,1,1,-103,0,0,-3.6,1);
	this.Sarrow3.shadow = new cjs.Shadow("rgba(153,153,153,1)",11,11,15);

	this.Sarrow1 = new lib.TC_TObject__arrow();
	this.Sarrow1.name = "Sarrow1";
	this.Sarrow1.parent = this;
	this.Sarrow1.setTransform(293.8,848.1,1,1,-103,0,0,-3.6,1);
	this.Sarrow1.shadow = new cjs.Shadow("rgba(153,153,153,1)",11,11,15);

	this.Sarrow2 = new lib.TC_TObject__arrow();
	this.Sarrow2.name = "Sarrow2";
	this.Sarrow2.parent = this;
	this.Sarrow2.setTransform(785.2,489.1,1,1,-103,0,0,-3.6,1);
	this.Sarrow2.shadow = new cjs.Shadow("rgba(153,153,153,1)",11,11,15);

	this.instance = new lib.Redbutton();
	this.instance.parent = this;
	this.instance.setTransform(515.1,782.5);

	this.instance_1 = new lib.Ramp_noball();
	this.instance_1.parent = this;
	this.instance_1.setTransform(950,590.8,2,2,0,0,0,-53.3,58.6);

	this.instance_2 = new lib.CballRed();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1499.5,863.5,2.2,2.2,0,0,0,17.3,17.3);

	this.instance_3 = new lib.Speedgauge();
	this.instance_3.parent = this;
	this.instance_3.setTransform(520.5,845.7,2,2);

	this.text_3 = new cjs.Text("Here are all of the materials that may be necessary for this experiment.", "bold 45px 'PT Sans'");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 60;
	this.text_3.lineWidth = 1406;
	this.text_3.parent = this;
	this.text_3.setTransform(960.2,159.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_3},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.Sarrow2},{t:this.Sarrow1},{t:this.Sarrow3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(1));

	// Layer_2
	this.instance_4 = new lib.TC_TVirtual__SceneRgn();
	this.instance_4.parent = this;
	this.instance_4.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__RQmaterials, new cjs.Rectangle(-1.2,-1.2,1922.5,1202.5), null);


(lib.TC_TScene__RQintro4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("We will measure the ball's speed at the bottom of the ramp.", "bold 55px 'PT Sans'");
	this.text.textAlign = "center";
	this.text.lineHeight = 73;
	this.text.lineWidth = 1732;
	this.text.parent = this;
	this.text.setTransform(960.3,82.1);

	this.instance = new lib.ramps_scene5();
	this.instance.parent = this;
	this.instance.setTransform(885.2,600.1,2,2,0,0,0,-37.5,0);

	this.instance_1 = new lib.TC_TVirtual__SceneRgn();
	this.instance_1.parent = this;
	this.instance_1.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance},{t:this.text}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__RQintro4, new cjs.Rectangle(-1.2,-1.2,1922.5,1202.5), null);


(lib.TC_TScene__RQintro3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("The ball will roll down the ramp.", "bold 55px 'PT Sans'");
	this.text.textAlign = "center";
	this.text.lineHeight = 73;
	this.text.lineWidth = 1728;
	this.text.parent = this;
	this.text.setTransform(962.3,84.5);

	this.instance = new lib.ramps_scene3();
	this.instance.parent = this;
	this.instance.setTransform(885.2,600.1,2,2,0,0,0,-37.5,0);

	this.instance_1 = new lib.TC_TVirtual__SceneRgn();
	this.instance_1.parent = this;
	this.instance_1.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance},{t:this.text}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__RQintro3, new cjs.Rectangle(-1.2,-1.2,1922.5,1202.5), null);


(lib.TC_TScene__RQintro2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("We will place a ball on the ramp. ", "bold 55px 'PT Sans'");
	this.text.textAlign = "center";
	this.text.lineHeight = 73;
	this.text.lineWidth = 1724;
	this.text.parent = this;
	this.text.setTransform(960.3,84.5);

	this.instance = new lib.ramps_scene2();
	this.instance.parent = this;
	this.instance.setTransform(885.2,600.1,2,2,0,0,0,-37.5,0);

	this.instance_1 = new lib.TC_TVirtual__SceneRgn();
	this.instance_1.parent = this;
	this.instance_1.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance},{t:this.text}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__RQintro2, new cjs.Rectangle(-1.2,-1.2,1922.5,1202.5), null);


(lib.TC_TScene__RQintro1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("Let's see how this experiment works. ", "bold 55px 'PT Sans'");
	this.text.textAlign = "center";
	this.text.lineHeight = 73;
	this.text.lineWidth = 1720;
	this.text.parent = this;
	this.text.setTransform(962.3,84.5);

	this.instance = new lib.Ramps1();
	this.instance.parent = this;
	this.instance.setTransform(885.2,600.1,2,2,0,0,0,-37.5,0);

	this.instance_1 = new lib.TC_TVirtual__SceneRgn();
	this.instance_1.parent = this;
	this.instance_1.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance},{t:this.text}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__RQintro1, new cjs.Rectangle(-1.2,-1.2,1922.5,1202.5), null);


(lib.TC_TTEDExpt__TEDExpt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Svar1a
	this.Svar1a = new lib.TC_TObject__RampNotSteep();
	this.Svar1a.name = "Svar1a";
	this.Svar1a.parent = this;
	this.Svar1a.setTransform(518.6,486.2,2.39,2.39,0,0,0,61.5,149.5);

	this.timeline.addTween(cjs.Tween.get(this.Svar1a).wait(1));

	// Svar1b
	this.Svar1b = new lib.TC_TObject__RampSteep();
	this.Svar1b.name = "Svar1b";
	this.Svar1b.parent = this;
	this.Svar1b.setTransform(516.9,459.7,2.39,2.39,0,0,0,60.8,138.4);

	this.timeline.addTween(cjs.Tween.get(this.Svar1b).wait(1));

	// Stag1
	this.Stag1 = new lib.TC_THtmlText__CallOutText();
	this.Stag1.name = "Stag1";
	this.Stag1.parent = this;
	this.Stag1.setTransform(130,129.5,2.4,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.Stag1).wait(1));

	// Shighlight1
	this.Shighlight1 = new lib.TC_TObject__CallOutHighlight();
	this.Shighlight1.name = "Shighlight1";
	this.Shighlight1.parent = this;
	this.Shighlight1.setTransform(73.7,104.6,1,1,0,0,0,63.7,25.1);

	this.timeline.addTween(cjs.Tween.get(this.Shighlight1).wait(1));

	// Stag2
	this.Stag2 = new lib.TC_THtmlText__CallOutText();
	this.Stag2.name = "Stag2";
	this.Stag2.parent = this;
	this.Stag2.setTransform(130,261.3,2.4,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.Stag2).wait(1));

	// Shighlight2
	this.Shighlight2 = new lib.TC_TObject__CallOutHighlight();
	this.Shighlight2.name = "Shighlight2";
	this.Shighlight2.parent = this;
	this.Shighlight2.setTransform(73.7,236.4,1,1,0,0,0,63.7,25.1);

	this.timeline.addTween(cjs.Tween.get(this.Shighlight2).wait(1));

	// Stag3
	this.Stag3 = new lib.TC_THtmlText__CallOutText();
	this.Stag3.name = "Stag3";
	this.Stag3.parent = this;
	this.Stag3.setTransform(130,393.1,2.4,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.Stag3).wait(1));

	// Shighlight3
	this.Shighlight3 = new lib.TC_TObject__CallOutHighlight();
	this.Shighlight3.name = "Shighlight3";
	this.Shighlight3.parent = this;
	this.Shighlight3.setTransform(73.7,368.2,1,1,0,0,0,63.7,25.1);

	this.timeline.addTween(cjs.Tween.get(this.Shighlight3).wait(1));

	// Stag4
	this.Stag4 = new lib.TC_THtmlText__CallOutText();
	this.Stag4.name = "Stag4";
	this.Stag4.parent = this;
	this.Stag4.setTransform(130,524.9,2.4,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.Stag4).wait(1));

	// Shighlight4
	this.Shighlight4 = new lib.TC_TObject__CallOutHighlight();
	this.Shighlight4.name = "Shighlight4";
	this.Shighlight4.parent = this;
	this.Shighlight4.setTransform(73.7,500,1,1,0,0,0,63.7,25.1);

	this.timeline.addTween(cjs.Tween.get(this.Shighlight4).wait(1));

	// Region
	this.instance = new lib.TC_TVirtual__ExptRgn();
	this.instance.parent = this;
	this.instance.setTransform(473.9,328.5,1,1,0,0,0,474.9,329.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TTEDExpt__TEDExpt, new cjs.Rectangle(-1,-0.9,950,845.4), null);


(lib.TC_TObject__Vars = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Svar1a
	this.Svar1a = new lib.TC_TObject__VarsNotSteep();
	this.Svar1a.name = "Svar1a";
	this.Svar1a.parent = this;
	this.Svar1a.setTransform(247.6,241.1);

	this.timeline.addTween(cjs.Tween.get(this.Svar1a).wait(1));

	// Svar1b
	this.Svar1b = new lib.TC_TObject__VarsSteep();
	this.Svar1b.name = "Svar1b";
	this.Svar1b.parent = this;
	this.Svar1b.setTransform(168.7,296,1.085,1.085,0,0,0,-53.3,58.6);

	this.timeline.addTween(cjs.Tween.get(this.Svar1b).wait(1));

	// Svar2a
	this.Svar2a = new lib.TC_TObject__CballYellow();
	this.Svar2a.name = "Svar2a";
	this.Svar2a.parent = this;
	this.Svar2a.setTransform(247.8,172.1,3.75,3.75,0,0,0,17.3,17.3);

	this.timeline.addTween(cjs.Tween.get(this.Svar2a).wait(1));

	// Svar2b
	this.Svar2b = new lib.TC_TObject__CballPink();
	this.Svar2b.name = "Svar2b";
	this.Svar2b.parent = this;
	this.Svar2b.setTransform(247.8,172.1,3.75,3.75,0,0,0,17.3,17.3);

	this.timeline.addTween(cjs.Tween.get(this.Svar2b).wait(1));

	// Svar3a
	this.Svar3a = new lib.TC_TObject__VarsMiddle();
	this.Svar3a.name = "Svar3a";
	this.Svar3a.parent = this;
	this.Svar3a.setTransform(155.6,299.7,1,1,0,0,0,-53.2,58.6);

	this.timeline.addTween(cjs.Tween.get(this.Svar3a).wait(1));

	// Svar3b
	this.Svar3b = new lib.TC_TObject__VarsTop();
	this.Svar3b.name = "Svar3b";
	this.Svar3b.parent = this;
	this.Svar3b.setTransform(155.6,299.7,1,1,0,0,0,-53.2,58.6);

	this.timeline.addTween(cjs.Tween.get(this.Svar3b).wait(1));

	// Svar4a
	this.Svar4a = new lib.TC_TObject__VarsRough();
	this.Svar4a.name = "Svar4a";
	this.Svar4a.parent = this;
	this.Svar4a.setTransform(192.7,300.1,0.991,0.991,0,0,0,-53.2,58.6);

	this.timeline.addTween(cjs.Tween.get(this.Svar4a).wait(1));

	// Svar4b
	this.Svar4b = new lib.TC_TObject__VarsSmooth();
	this.Svar4b.name = "Svar4b";
	this.Svar4b.parent = this;
	this.Svar4b.setTransform(194.4,299.7,1,1,0,0,0,-53.2,58.6);

	this.timeline.addTween(cjs.Tween.get(this.Svar4b).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Vars, new cjs.Rectangle(-424.7,-118.1,921.1,799.2), null);


(lib.TC_TScene__RQenumVars = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.Sicon2 = new lib.TC_TObject__Vars();
	this.Sicon2.name = "Sicon2";
	this.Sicon2.parent = this;
	this.Sicon2.setTransform(1256.5,798.3,1,1,0,0,0,134.3,298.3);

	this.Sicon1 = new lib.TC_TObject__Vars();
	this.Sicon1.name = "Sicon1";
	this.Sicon1.parent = this;
	this.Sicon1.setTransform(437,798.3,1,1,0,0,0,134.3,298.3);

	this.SsubTitle2 = new lib.TC_THtmlText__Text1();
	this.SsubTitle2.name = "SsubTitle2";
	this.SsubTitle2.parent = this;
	this.SsubTitle2.setTransform(1371.4,972.4,5.494,1.278,0,0,0,50.3,50);

	this.SsubTitle1 = new lib.TC_THtmlText__Text1();
	this.SsubTitle1.name = "SsubTitle1";
	this.SsubTitle1.parent = this;
	this.SsubTitle1.setTransform(551.9,972.4,5.494,1.278,0,0,0,50.3,50);

	this.Stitle = new lib.TC_THtmlText__Text1();
	this.Stitle.name = "Stitle";
	this.Stitle.parent = this;
	this.Stitle.setTransform(973.4,250.8,14.918,2.193,0,0,0,50.9,50.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Stitle},{t:this.SsubTitle1},{t:this.SsubTitle2},{t:this.Sicon1},{t:this.Sicon2}]}).wait(1));

	// Layer_1
	this.instance = new lib.TC_TVirtual__SceneRgn();
	this.instance.parent = this;
	this.instance.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__RQenumVars, new cjs.Rectangle(-122.1,-1.2,2043.4,1202.5), null);


// stage content:
(lib.EFMod_Ramps = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(10));

	// Scene Bounds
	this.instance = new lib.SceneRegion();
	this.instance.parent = this;
	this.instance.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10));

	// Module Content
	this.instance_1 = new lib.TC_TScene__RQintro1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(960,600,1,1,0,0,0,960,600);

	this.instance_2 = new lib.TC_TScene__RQintro2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(960,600,1,1,0,0,0,960,600);

	this.instance_3 = new lib.TC_TScene__RQintro3();
	this.instance_3.parent = this;
	this.instance_3.setTransform(960,600,1,1,0,0,0,960,600);

	this.instance_4 = new lib.TC_TScene__RQintro4();
	this.instance_4.parent = this;
	this.instance_4.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[]},1).to({state:[]},2).wait(4));

	// Module Component
	this.instance_5 = new lib.ef_TutorModule({'id': 'instance_5', 'compositionID':'EFF037AC4C96E3669290FFC080C190C0'});

	this.instance_5.setTransform(960,600,1,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({_off:true},1).wait(9));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(958.8,598.8,1922.5,1202.5);
// library properties:
lib.properties = {
	id: 'EFF037AC4C96E3669290FFC080C190C0',
	width: 1920,
	height: 1200,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/_3DGridWall.jpg", id:"_3DGridWall"},
		{src:"components/EFComponents/src/ef_loadManager.js", id:"EFComponents/src/ef_loadManager.js"},
		{src:"components/EFComponents/src/ef_module.js", id:"ef.TutorModule"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['EFF037AC4C96E3669290FFC080C190C0'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}

function _updateVisibility(evt) {
	if((this.getStage() == null || this._off || this._lastAddedFrame != this.parent.currentFrame) && this._element) {
		this._element.detach();
		stage.removeEventListener('drawstart', this._updateVisibilityCbk);
		this._updateVisibilityCbk = false;
	}
}
function _handleDrawEnd(evt) {
	var props = this.getConcatenatedDisplayProps(this._props), mat = props.matrix;
	var tx1 = mat.decompose(); var sx = tx1.scaleX; var sy = tx1.scaleY;
	var dp = window.devicePixelRatio || 1; var w = this.nominalBounds.width * sx; var h = this.nominalBounds.height * sy;
	mat.tx/=dp;mat.ty/=dp; mat.a/=(dp*sx);mat.b/=(dp*sx);mat.c/=(dp*sy);mat.d/=(dp*sy);
	this._element.setProperty('transform-origin', this.regX + 'px ' + this.regY + 'px');
	var x = (mat.tx + this.regX*mat.a + this.regY*mat.c - this.regX);
	var y = (mat.ty + this.regX*mat.b + this.regY*mat.d - this.regY);
	var tx = 'matrix(' + mat.a + ',' + mat.b + ',' + mat.c + ',' + mat.d + ',' + x + ',' + y + ')';
	this._element.setProperty('transform', tx);
	this._element.setProperty('width', w);
	this._element.setProperty('height', h);
	this._element.update();
}

function _tick(evt) {
	var stage = this.getStage();
	stage&&stage.on('drawend', this._handleDrawEnd, this, true);
	if(!this._updateVisibilityCbk) {
		this._updateVisibilityCbk = stage.on('drawstart', this._updateVisibility, this, false);
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;