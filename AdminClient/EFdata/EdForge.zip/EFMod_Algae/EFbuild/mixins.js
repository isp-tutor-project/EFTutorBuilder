var EFTut_Suppl;
(function (EFTut_Suppl) {
    var EFMod_Algae;
    (function (EFMod_Algae) {
        class CONST {
        }
        EFMod_Algae.CONST = CONST;
    })(EFMod_Algae = EFTut_Suppl.EFMod_Algae || (EFTut_Suppl.EFMod_Algae = {}));
})(EFTut_Suppl || (EFTut_Suppl = {}));
var EFTut_Suppl;
(function (EFTut_Suppl) {
    var EFMod_Algae;
    (function (EFMod_Algae) {
        class $Common {
            $preCreateScene() { }
            $onCreateScene() { }
            $preEnterScene() { }
            $onEnterScene() { }
            $preExitScene() { }
            $onExitScene() { }
            $preShowScene() { }
            $preHideScene() { }
            $demoInitScene() { }
            $logScene() { }
            $rewindScene() { }
            $resolveTemplate(templID) { }
            $handleEvent() { }
            $nodePreEnter(nodeId) { }
            $nodePreExit(nodeId) { }
            $nodeAction(actionId) { }
            $nodeConstraint(constrainId) {
                let result = false;
                return result;
            }
            $cuePoints(id) { }
            $timedEvents(id) { }
        }
        EFMod_Algae.$Common = $Common;
    })(EFMod_Algae = EFTut_Suppl.EFMod_Algae || (EFTut_Suppl.EFMod_Algae = {}));
})(EFTut_Suppl || (EFTut_Suppl = {}));
//# sourceMappingURL=mixins.js.map