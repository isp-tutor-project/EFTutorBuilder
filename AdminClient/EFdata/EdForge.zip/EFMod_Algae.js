(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.TC_TObject__Highlight = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,204,255,0)").s("rgba(255,255,255,0)").ss(1,1,1).rr(-63.55,-25,127.1,50,10);
	this.shape.setTransform(63.5,25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Highlight, new cjs.Rectangle(-1,-1,129.1,52), null);


(lib.TC_TObject__CalloutShort = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0.008)").ss(3,1,1).p("AlGhUIAADxAk2AnIJ9jD");
	this.shape.setTransform(32.7,15.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__CalloutShort, new cjs.Rectangle(-1.5,-1.5,68.3,34.4), null);


(lib.TC_TObject__CalloutLong = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0)").ss(3,1,1).p("ArHA4IAADyAq4C0IWAnd");
	this.shape.setTransform(71.2,1.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__CalloutLong, new cjs.Rectangle(-1.5,-29.7,145.4,62.6), null);


(lib.TC_TObject__CallOutHighlight = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00CCFF").s("#FFFFFF").ss(1,1,1).rr(-120,-50,240,100,15);
	this.shape.setTransform(120,50);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__CallOutHighlight, new cjs.Rectangle(-1,-1,242,102), null);


(lib.line = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().ls(["#000000","#888888","#B0B0B0","#E9E9E9","#FFFFFF"],[0,0,0,0.89,1],-6,0,6,0).ss(3.5,1,1).p("AgsAhIBZhB");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.line, new cjs.Rectangle(-6.2,-5,12.5,10), null);


(lib.TC_TVirtual__ExptRgn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(102,255,255,0.988)").s().dr(-475,-329.5,950,659);
	this.shape.setTransform(475,329.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TVirtual__ExptRgn, new cjs.Rectangle(0,0,950,659), null);


(lib.TC_TObject__Shade = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ASu1QIhAAAMgpEAAAIhfAAIAAloMAxrAAAIAAFoIh0AAIkUAAQgqSzA1TFIABAMQAAALAAAMQAAA+gNAsQgNAsgTAAQgTAAgOgsQgNgsAAg+QAAgFAAgFQABgRABgQQA+y3gxy5AXC1QMAAAAwJMguYAAAMAAAgwJ");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("A3LYFMAAAgwJMApEAAAQAxS5g+S3IgCAhIAAAKQAAA+ANAsQANAsATAAQAUAAAMgsQAOgsAAg+IgBgXIAAgMQg1zFApyzIEVAAMAAAAwJg");
	this.shape_1.setTransform(-1,18);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#999999").s().p("ARsWhQgNgsAAg+IAAgKIACghQA+y5gxy3MgpEAAAIhfAAIAAloMAxrAAAIAAFoIh0AAIkUAAQgqSyA1TGIABAMIAAAXQAAA+gNAsQgNAsgTAAQgTAAgOgsgASuxkIhAAAg");
	this.shape_2.setTransform(0,-23.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Shade, new cjs.Rectangle(-159.9,-173.1,320,346.2), null);


(lib.TC_TObject__HeaterWater = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(153,255,255,0.498)").s().p("ACTFnIgGAAIgDAAIkEgFIgegDIAAgQIAAg2IgBguIADhiQAGibAAhBQAAg2gChEIgEhkIAIgSQAGgKALgLIAMgNIAGgBIgIAKQgJAIgHADQAfgIA1ANQA/AOAYgCQARgBAcgIQAigIAMgCQAIgBAGgEIAAAWIABAVIACAVQACAPACAFIABABIgCFVQAACFACCMIABAAIAAABIgEADg");
	this.shape.setTransform(15.4,35.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__HeaterWater, new cjs.Rectangle(0,0,30.8,71.9), null);


(lib.TC_TObject__Arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").ss(2,1,1).p("ABxEoICcAjImHExIi/myICcAbIDGtgIERA/g");
	this.shape.setTransform(-3.3,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0098FF").s().p("Ak5DKICcAbIDGtgIEQA/IjINkICbAjImGExg");
	this.shape_1.setTransform(-3.3,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Arrow, new cjs.Rectangle(-35.7,-63.6,64.7,129.3), null);


(lib.grams = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("0.11 g", "21px 'Arial'", "#CCFF00");
	this.text.lineHeight = 26;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(-65.9,-14.6);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.grams, new cjs.Rectangle(-67.9,-16.6,104.4,27.6), null);


(lib.squarethermometernumbers = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIAWIgEgBIACgHIADABIAEAAQAEAAACgCQACgCAAgDQAAgEgDgCQgCgCgEAAIgFAAIAAgWIAVAAIAAAIIgOAAIAAAIIACAAIAFABIAFADIACAEIABAFQAAAEgBADQgBADgDACIgFADIgGABIgFgBg");
	this.shape.setTransform(-1.5,33.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgLAWIAOghIADgDIgEAAIgPAAIAAgHIAbAAIAAACIgRApg");
	this.shape_1.setTransform(-5,33.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgLARQgDgGAAgLQAAgLADgGQAEgFAHAAQAIAAAEAFQADAGAAALQAAAMgDAFQgFAGgHAAQgHAAgEgGgAgEgLQgCAEAAAHQAAAIACAEQABAEADAAQAEAAABgEQACgEAAgIQABgHgCgEQgCgEgEAAQgDAAgBAEg");
	this.shape_2.setTransform(-1.4,24);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgFAWIgFgCIgCgEIgBgFIAAgEIACgDIACgCIADgCIgEgEQgCgDAAgEIABgEIACgEQACgCADAAIAEgBIAFAAIAEADQABAAAAAAQABABAAAAQAAABABAAQAAABAAAAIABAEQAAAEgCADIgFAFQAEABACADQACACAAAEIgBAGIgDAEIgEACIgGABIgFgBgAgFAGIgBAEQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQACACACAAQABAAAAAAQABAAAAAAQABAAAAgBQABAAAAAAQABgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAIAAgDIgCgCIgDgCIgCgCQgDACgBACgAgDgOIgBAEIAAACIACACIACACIACABQADgDAAgEQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAg");
	this.shape_3.setTransform(-5,24);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgIAWIgEgBIACgHIADABIAEAAQAEAAACgCQACgCAAgDQAAgEgDgCQgCgCgEAAIgFAAIAAgWIAVAAIAAAIIgOAAIAAAIIACAAIAFABIAFADIACAEIABAFQAAAEgBADIgEAFIgFADIgGABIgFgBg");
	this.shape_4.setTransform(-1.5,14.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgFAWIgFgCIgCgEIgBgFIAAgEIACgDIACgCIADgCIgEgEQgCgDAAgEIABgEIACgEQACgCADAAIAEgBIAFAAIAEADQABAAAAAAQABABAAAAQAAABABAAQAAABAAAAIABAEQAAAEgCADIgFAFQAEABACADQACACAAAEIgBAGIgDAEIgEACIgGABIgFgBgAgFAGIgBAEQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQACACACAAQABAAAAAAQABAAAAAAQABAAAAgBQABAAAAAAQABgBAAAAQAAgBABAAQAAAAAAgBQAAgBAAAAIAAgDIgCgCIgDgCIgCgCQgDACgBACgAgDgOIgBAEIAAACIACACIACACIACABQADgDAAgEQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAAAQAAgBgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAg");
	this.shape_5.setTransform(-5,14.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgLARQgDgGAAgLQAAgLADgGQAEgFAHAAQAIAAAEAFQADAGAAALQAAAMgDAFQgFAGgHAAQgHAAgEgGgAgEgLQgCAEAAAHQAAAIACAEQABAEADAAQAEAAABgEQACgEAAgIQABgHgCgEQgCgEgEAAQgDAAgBAEg");
	this.shape_6.setTransform(-1.4,4.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJARIAGgCIAEgDIAEgFIABgFIgDADIgEAAIgEgBQgDAAgCgCIgDgDIgBgGIABgGIACgFIAGgDIAFgBQAHAAAEAEQAEAEAAAJQAAAGgCAFQgCAGgDADQgDAEgEACIgIACgAgEgNQgCACAAADQAAAEACACQACABACAAIAFAAIACgCIAAgDIgBgDIgBgEIgCgCIgDgBQgDAAgBADg");
	this.shape_7.setTransform(-5,4.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgIAWIgEgBIACgHIADABIAEAAQAEAAACgCQACgCAAgDQAAgEgDgCQgCgCgEAAIgFAAIAAgWIAVAAIAAAIIgOAAIAAAIIACAAIAFABIAFADIACAEIABAFQAAAEgBADIgEAFIgFADIgGABIgFgBg");
	this.shape_8.setTransform(-1.5,-4.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgJARIAGgCIAEgDIAEgFIABgFIgDADIgEAAIgEgBQgDAAgCgCIgDgDIgBgGIABgGIACgFIAGgDIAFgBQAHAAAEAEQAEAEAAAJQAAAGgCAFQgCAGgDADQgDAEgEACIgIACgAgEgNQgCACAAADQAAAEACACQACABACAAIAFAAIACgCIAAgDIgBgDIgBgEIgCgCIgDgBQgDAAgBADg");
	this.shape_9.setTransform(-5,-4.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgLARQgDgGAAgLQAAgLADgGQAEgFAHAAQAIAAAEAFQADAGAAALQAAAMgDAFQgFAGgHAAQgHAAgEgGgAgEgLQgCAEAAAHQAAAIACAEQABAEADAAQAEAAACgEQABgEAAgIQABgHgCgEQgCgEgEAAQgDAAgBAEg");
	this.shape_10.setTransform(2.2,-14.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgLARQgDgGAAgLQAAgLADgGQAEgFAHAAQAIAAAEAFQADAGAAALQAAAMgDAFQgFAGgHAAQgHAAgEgGgAgEgLQgCAEAAAHQAAAIACAEQABAEADAAQAEAAABgEQACgEAAgIQABgHgCgEQgCgEgEAAQgDAAgBAEg");
	this.shape_11.setTransform(-1.4,-14.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgLAXIAAgHIAJAAIAAgYIABgFIgDAEIgGAEIgDgFIANgMIAFAAIAAAmIAJAAIAAAHg");
	this.shape_12.setTransform(-5,-14.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgIAWIgEgBIACgHIADABIAEAAQAEAAACgCQACgCAAgDQAAgEgDgCQgCgCgEAAIgFAAIAAgWIAVAAIAAAIIgOAAIAAAIIACAAIAFABIAFADIACAEIABAFQAAAEgBADQgBADgDACIgFADIgGABIgFgBg");
	this.shape_13.setTransform(2.1,-23.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgLARQgDgGAAgLQAAgLADgGQAEgFAHAAQAIAAAEAFQADAGAAALQAAAMgDAFQgFAGgHAAQgHAAgEgGgAgEgLQgCAEAAAHQAAAIACAEQABAEADAAQAEAAABgEQACgEAAgIQABgHgCgEQgCgEgEAAQgDAAgBAEg");
	this.shape_14.setTransform(-1.4,-23.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgLAXIAAgHIAJAAIAAgYIABgFIgDAEIgGAEIgDgFIANgMIAFAAIAAAmIAJAAIAAAHg");
	this.shape_15.setTransform(-5,-23.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgMAWIAAgrIAZAAIAAAHIgRAAIAAALIAQAAIAAAHIgQAAIAAASg");
	this.shape_16.setTransform(-5.1,-33.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.squarethermometernumbers, new cjs.Rectangle(-8.1,-38.8,16.4,77.7), null);


(lib.squarethermometercolorroomtemp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(51,153,153,0.498)").s().p("AhDAkIAAhHICHAAIAABHg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.squarethermometercolorroomtemp, new cjs.Rectangle(-6.7,-3.6,13.5,7.3), null);


(lib.squarethermometercolorhot = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(153,0,0,0.498)").s().p("AhDAkIAAhHICHAAIAABHg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.squarethermometercolorhot, new cjs.Rectangle(-6.7,-3.6,13.5,7.3), null);


(lib.squarefishtankthermometer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(0.3,1,1).p("AAEAAQAAABgBACQgBABgCAAQgBAAgBgBQgBgCAAgBQAAAAABgBQABgCABAAQACAAABACQABABAAAAg");
	this.shape.setTransform(-6.5,-39.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(0,0,0,0.6)").ss(1,1,1).p("AhmmiIDNAAIAANFIjNAAg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgCADIgBgCQAAgBAAAAQAAAAAAAAQAAAAABgBQAAAAAAAAQAAAAABgBQAAAAAAAAQABAAAAAAQAAgBAAAAQAAAAABABQAAAAABAAQAAAAAAAAQAAABABAAQAAAAAAAAQABABAAAAQAAAAAAAAQAAAAAAABIgBACIgDAAIgCAAg");
	this.shape_2.setTransform(-6.5,-39.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(0,0,0,0.8)").s().p("AhmGjIAAtFIDNAAIAANFgAhDmMQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAAAABIABACIADAAIADAAIABgCQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAAAAAQgBAAAAgBQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAABQAAAAgBAAQAAAAAAAAQgBABAAAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.squarefishtankthermometer, new cjs.Rectangle(-11.3,-42.9,22.7,85.8), null);


(lib.CScalecopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(4.2,1,1).p("ANoAAQAAAZgPASQgCACgDADQgTAUgcAAQgcAAgUgUQgCgDgCgCQgQgSAAgZQAAgbAUgUQAUgUAcAAQAcAAATAUQAUAUAAAbgAr5AIQAAAXgQAPIgBABQgPAQgXAAQgXAAgQgQQAAAAAAgBQgQgPAAgXQAAgXAQgPQAQgRAXAAQAXAAAQARQAQAPAAAXg");
	this.shape.setTransform(-22.7,26.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#CC9900").ss(4.2,1,1).p("AN0gBIBdAAIBdgBAI/AAIDNgBAwtADIBkgBICOAAAruACIDsgB");
	this.shape_1.setTransform(-25.5,31.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#006699").ss(1.6,1,1).p("AQNjRIhEDlIggBuIAABQAuGjRIhLDqIg7C5");
	this.shape_2.setTransform(-24.7,29);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#999999").ss(4.2,1,1).p("AVFnAIgBAzIgDBcIgCBGAM+G3IH+o5IADhnANhATQAPAMAAAcIgLBWIgOBoIgZC+IhkAAI+0AAIgFABQgSAChTAHIBBjDIBBjDQAAgcAPgM");
	this.shape_3.setTransform(-4,6.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#666666").ss(1.6,1,1).p("Aj5FrIHnooIAAgDAAEhSIDvkPIAHgJAjvDBIAEgEIBvh+Aj5ElIHpor");
	this.shape_4.setTransform(106.5,1.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0066CC").s().p("AglAnIgBAAQgQgQAAgXQAAgWAQgQQAQgQAWAAQAXAAAQAQQAQAQAAAWQAAAXgQAQIAAAAQgQAQgXAAQgWAAgPgQg");
	this.shape_5.setTransform(-104.4,27.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#66CC66").s().p("AogCHIAAhMIAAjBIRBAAIAAC+IAABPg");
	this.shape_6.setTransform(-22.4,25.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF9900").s().p("AgvAwIgEgFQgPgSAAgZQAAgbATgUQAUgUAbAAQAcAAATAUQAVAUAAAbQgBAZgPASIgFAFQgTATgcAAQgbAAgUgTg");
	this.shape_7.setTransform(57.8,26.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#FFFFFF","#CFCFCF","#656565","#959595","#8F8F8F","#949494","#666666"],[0,0.11,0.408,0.569,0.706,0.714,1],-139.9,-6.5,102,-6.5).s().p("AOsEnIhzAAIgkAAI+SAAIhfAAIibAAII6pNMAi1AAAIhbB6IjwFBIhtCSg");
	this.shape_8.setTransform(0,-21.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#666666").s().p("AwZAUIBBjCQAAgcAPgMIBfAAIeSAAIAkAAQAPAMAAAcIgLBWIgEAEIAEgEIgOBnIhdAAIBDjlIhDDlIhdAAIBdAAIggBuIAABQI+1AAIA7i5ICOgBIiOABIBLjqIhLDqIhkAAIBkAAIg7C5IgFABIhlAJgAnuBfIRBAAIAAhPIAAi+IxBAAIAADBIjsAAIDsAAgAMkhKQgTATAAAcQAAAZAPASIAEAEQAUAUAcAAQAcAAAUgUIAEgFQAQgRAAgZQAAgcgUgTQgUgUgcAAQgcAAgUAUgAsog6QgQAQAAAXQAAAWAQAQIABAAQAQAQAWAAQAXAAAQgQIAAAAQAQgQAAgWQAAgXgQgQQgQgQgXAAQgXAAgQAQgAJTAQIDNAAgAPFDNIAAhQIAghuIBdAAIgZC+gAu1AUgAnuATgAPlAPgARCAPgARQhYg");
	this.shape_9.setTransform(-27.5,29.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.CScalecopy, new cjs.Rectangle(-141,-51,281,104.1), null);


(lib.CScale = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.CScale, null, null);


(lib.TC_TObject__CRadionomusic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFCC33").s().p("AgJAOIAAgbIASAAIAAADIgOAAIAAAJIAMAAIAAACIgMAAIAAANg");
	this.shape.setTransform(25.1,9.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFCC33").s().p("AgJAOIAAgbIASAAIAAADIgOAAIAAAJIAMAAIAAACIgMAAIAAANg");
	this.shape_1.setTransform(22.7,9.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFCC33").s().p("AgGANQgEgCgBgEQgCgDAAgEQAAgGAEgEQAEgEAFAAQAEAAADACQADACACADQACAEAAADQAAAEgCAEQgCADgDACQgDACgEAAQgDAAgDgCgAgGgIQgDADAAAFQAAAGADADQADACADAAQAEAAADgDQADgDAAgFQAAgDgCgCIgDgEQgCgCgDAAQgDAAgDADg");
	this.shape_2.setTransform(19.8,9.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#666666").s().p("AAIAMIAAgTIgHATIgBAAIgHgTIAAATIgDAAIAAgXIAEAAIAGAPIAAAEIABgEIAGgPIAEAAIAAAXg");
	this.shape_3.setTransform(-9.5,9.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#666666").s().p("AAHAMIgCgIIgJAAIgDAIIgDAAIAJgXIACAAIAKAXgAgBgEIgCAGIAHAAIgDgGIgBgEIgBAEg");
	this.shape_4.setTransform(-11.9,9.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAIALIAAgSIgGASIgCAAIgHgTIAAATIgDAAIAAgVIAEAAIAGAPIAAADIACgDIAFgPIAEAAIAAAVg");
	this.shape_5.setTransform(8.8,9.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgHALIAAgVIAPAAIAAACIgMAAIAAAHIAKAAIAAACIgKAAIAAAKg");
	this.shape_6.setTransform(6.5,9.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(0.1,1,1).p("AG/hCQgBADgBAEAAmhLQAAASgNAMQgNANgQAAQgSAAgMgNQgNgMAAgSQAAgRANgNQAMgMASAAQAQAAANAMQANANAAARgAm8B2QgBAAgBgB");
	this.shape_7.setTransform(-1.1,18);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,1,1).p("AJurnQgEgFAAgHQAAgIAGgGQAGgGAIAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgDADgEABQgCACgCAAQgCAAgCAAQgBAAgCAAIgCAEAJ7reQgGgBgFgFQgCgBAAgCIjqHTIAAAwID8n2AFDkQIAAg5IBBAAIAAA1AENgmQALADAKADQARAFAQAGIAAhNIAAgwgAEiggIAhhCAFDiSIAAh+IqQAAIAADzQCMgwCtAAQCaAACHAnAGEADQAgAOAeAQQBCAjAzAvQADADADACQBnBiAmCTQA5DfhtBXQhsBYmoAMQmnAMj0hPQiUgvgkhsQgXhFAXheQABgCAAgCQA+jzC7huQAmgXAqgRIgBAAIAAkJIAAg5ILLAAAHVB9QAsAWAbAnQAwBFAABiQAABigwBFQgwBFhDAAQhEAAgwhFQgvhFAAhiQAAhiAvhFQAwhFBEAAQAOAAANADQAJACAIADgAE3B0QAAAcgUAUQgTAUgcAAQgcAAgUgUQgUgUAAgcQAAgcAUgUQAUgTAcAAQAcAAATATQAUAUAAAcgADKB+IAjAAIAAANIgjAAgACNBgQAAAYgnAaQgpAZg3AAQg2AAgogWQgngYgBgbQAAgbAogIQAogJA2AAQA3AAApAJQAnAJAAAYgACAETIBDAAIAAAcIhDAAgAAhETIBDAAIAAAcIhDAAgAA3HnQAAAGgEAFQgFAEgGAAQgHAAgEgEQgEgFAAgGQAAgHAEgEQAEgFAHAAQAGAAAFAFQAEAEAAAHgAhVIoIhJAAIAAjLIFQAAIAADLIhOAAIi5AAIAAh2IC5AAIAAB2AGEjkIAADnAFDgVQAhALAgANAmHgHQAcgMAegKAlNkQIg7AAAj5BaQAFgDAFAAQAIAAAGAGQAGAGAAAIQAAAIgGAGQgGAGgIAAQgIAAgGgGQgGgGAAgIQAAgEACgEQgFADgGAAQgIAAgHgGQgFgFAAgJQAAgIAFgHQAHgFAIAAQAJAAAFAFQAGAHAAAIQAAAEgBAEgAkBBjQABgDADgDQACgCACgBAjDB/QAAAFgEADQgDAEgFAAQgFAAgEgEQgDgDAAgFQAAgFADgEQAEgDAFAAQAFAAADADQAEAEAAAFgAhBETIBCAAIAAAcIhCAAgAimETIBDAAIAAAcIhDAAgAgVHnQAAAGgEAFQgFAEgGAAQgHAAgEgEQgFgFAAgGQAAgHAFgEQAEgFAHAAQAGAAAFAFQAEAEAAAHgAj8FgQAABigwBFQgvBFhDAAQhEAAgwhFQgvhFAAhiQAAhiAvhFQAwhFBEAAQBDAAAvBFQAwBFAABig");
	this.shape_8.setTransform(-1.7,0);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#999999").s().p("ABbBlIAAh1Ii6AAIAAB1IhIAAIAAjJIFPAAIAADJgAAUAvQgFgEAAgHQAAgGAFgEQAEgFAGAAQAHAAAEAFQAFAEAAAGQAAAHgFAEQgEAFgHAAQgGAAgEgFgAg5AvQgEgEAAgHQAAgGAEgEQAFgFAGAAQAHAAAFAFQAEAEAAAGQAAAHgEAEQgFAFgHAAQgGAAgFgFg");
	this.shape_9.setTransform(-0.8,45.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFCC33").s().p("AByAOIAAgbIBDAAIAAAbgAATAOIAAgbIBDAAIAAAbgAhPAOIAAgbIBDAAIAAAbgAi0AOIAAgbIBDAAIAAAbg");
	this.shape_10.setTransform(-0.3,28.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#666666").s().p("AEwDJQguhFgBhiQABhhAuhFQAxhFBDAAQAOAAANADQAJACAIADIAAAHIACgBQAEABACACIAEADIgMgMQAsAXAbAmQAwBFAABhQAABigwBFQgwBFhDAAQhDAAgxhFgAHcibIABgBIgBAAgAoXDIQgvhFAAhiQAAhhAvhFQAxhFBDAAQBDAAAwBFQAvBFAABhQAABigvBFQgwBFhDAAQhDAAgxhFgAm8gVIABACIABAAIgBgCIAAAAIgBAAgAC/iaQgTgTAAgdQAAgbATgVQAUgTAcAAQAcAAATATQAVAVAAAbQAAAdgVATQgTAUgcAAQgcAAgUgUgADGizIAiAAIAAgMIgiAAgAjdi2QgDgEAAgFQAAgFADgDQAEgEAFAAQAFAAAEAEQADADAAAFQAAAFgDAEQgEADgFAAQgFAAgEgDgAkBjFQgHgGAAgIQAAgEACgDQACgEADgDIADgDQAFgDAFAAQAJAAAFAGQAGAGABAIQgBAIgGAGQgFAGgJAAQgIAAgFgGgAkfjeQgGgFAAgIQAAgJAGgHQAGgFAIAAQAJAAAGAFQAFAHAAAJIgBAHIgDADQgDADgCAEQgEADgHAAQgIAAgGgHgAkGjaIAAAAg");
	this.shape_11.setTransform(-1.2,31.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.498)").s().p("AgdAeQgNgMAAgSQAAgQANgNQAMgMARAAQARAAANAMQANANAAAQQAAASgNAMQgNAMgRAAQgRAAgMgMg");
	this.shape_12.setTransform(-1.6,10.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CCCCCC").s().p("AnMB5IABgBIAAABIABABIAAAAIgCgBgAhsgaQgogYAAgbQgBgbAogIQApgJA3AAQA2AAAoAJQAoAJAAAYQAAAYgoAaQgoAZg2AAQg3AAgogWgAgwhlQgNANAAARQAAASANAMQAMANASAAQARAAAMgNQANgMAAgSQAAgRgNgNQgMgMgRAAQgSAAgMAMgAHMgNIABAAIAAAAg");
	this.shape_13.setTransform(0.3,17.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#0080FE").s().p("AoZFnQiUgwgkhrQgXhFAXheIABgEQA+jzC7huQAmgWAqgSQAcgNAegKQCMgvCtAAQCaAACHAmIAVAGIAhALQAhALAgAPQAgANAeAQQBCAkAzAvIAGAFQBnBiAmCSQA5DehtBYQhsBXmoAMQg6ACg3AAQlYAAjShEgAE1ijQgvBFAABhQAABiAvBFQAwBFBEAAQBDAAAwhFQAwhFAAhiQAAhhgwhFQgbgmgsgWIAMAAIgKgFIgCgBIAAAGQgIgEgJgCQgNgDgOAAQhEAAgwBFgAoSijQgvBFAABgQAABiAvBFQAwBFBEAAQBDAAAvhFQAwhFAAhiQAAhggwhFQgvhFhDAAQhEAAgwBFgAieDKIBJAAIC5AAIBOAAIAAjKIlQAAgACAgtIBDAAIAAgdIhDAAgAAhgtIBDAAIAAgdIhDAAgAhBgtIBCAAIAAgdIhCAAgAimgtIBDAAIAAgdIhDAAgADEkYQgUAUAAAcQAAAcAUATQAUAUAcAAQAcAAATgUQAUgTAAgcQAAgcgUgUQgTgUgcAAQgcAAgUAUgAhYkeQgoAJAAAbQABAbAnAXQAoAXA2AAQA3AAApgaQAngZAAgYQAAgYgngKQgpgJg3AAQg2AAgoAJgAjYjmQgDADAAAFQAAAFADAEQAEADAFAAQAFAAADgDQAEgEAAgFQAAgFgEgDQgDgEgFAAQgFAAgEAEgAkDjyQAAAIAGAGQAGAGAIAAQAIAAAGgGQAGgGAAgIQAAgIgGgGQgGgGgIAAQgFAAgFADIABgHQAAgJgGgGQgFgGgJAAQgIAAgHAGQgFAGAAAJQAAAIAFAGQAHAGAIAAQAGAAAFgDQgCADAAAEgAHEjlIABgHIgBAHgAHVjfg");
	this.shape_14.setTransform(-1.7,35);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#0000FF").s().p("AFGCNIAAhNIAAgwIAAh9IAAg4IBBAAIAAA0IAAAwIAADoQgggPghgLgAmGCcIAAkJIA8AAIAADyQgeAKgdANgAlKhtIg8AAIAAg4ILMAAIAAA4gAmGhtgAFGilg");
	this.shape_15.setTransform(-2,-16.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("Al0KYIAAh2IC7AAIAAB2gAkAJMQgFAFAAAGQAAAHAFAEQAEAFAGgBQAHABAEgFQAFgEAAgHQAAgGgFgFQgEgEgHAAQgGAAgEAEgAlOJMQgEAFAAAGQAAAHAEAEQAFAFAGgBQAHABAFgFQAEgEAAgHQAAgGgEgFQgFgEgHAAQgGAAgFAEgAhTD7IAAgMIAjAAIAAAMgAgQBJIA1hrIAAAvIghBCIgUgGgABmikIDqnSIACACQAEAFAHABQgHgBgEgFIgCgCQgFgFAAgHQAAgJAHgGQAFgGAJAAQAJAAAFAGQAHAGAAAJQAAAIgHAGQgCADgEACIgEABIgEAAIgDAAIADAAIAEAAIAEgBIAKAAIgJAEIgBABIgGAAIj8H2gAFbpqIACgEg");
	this.shape_16.setTransform(26.9,-11.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__CRadionomusic, new cjs.Rectangle(-76,-78.6,148.6,157.3), null);


(lib.TC_TObject__CRadio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFCC33").s().p("AAJASIgRgbIAAAbIgFAAIAAgjIAFAAIASAbIAAgbIAEAAIAAAjg");
	this.shape.setTransform(23.8,9.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFCC33").s().p("AgIAQQgEgDgCgDQgCgFAAgFQAAgHAFgGQAEgEAHAAQAFgBAEADQAEADACAEQACAEAAAEQAAAFgCAFQgCAEgFADQgEABgEAAQgEAAgEgCgAgIgKQgDADAAAHQAAAHADAEQAEAEAEAAQAGAAADgEQAEgEAAgHQAAgDgCgEQgCgDgDgBQgCgDgEAAQgEAAgEAEg");
	this.shape_1.setTransform(20.1,9.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s().p("AAIAMIAAgTIgHATIgBAAIgHgTIAAATIgDAAIAAgXIAEAAIAGAPIAAAEIABgEIAGgPIAEAAIAAAXg");
	this.shape_2.setTransform(-9.5,9.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#666666").s().p("AAHAMIgCgIIgJAAIgDAIIgDAAIAJgXIACAAIAKAXgAgBgEIgCAGIAHAAIgDgGIgBgEIgBAEg");
	this.shape_3.setTransform(-11.9,9.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAIALIAAgSIgHASIgBAAIgHgTIAAATIgDAAIAAgVIAEAAIAGAPIAAADIABgDIAGgPIAEAAIAAAVg");
	this.shape_4.setTransform(8.2,9.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgHALIAAgVIAPAAIAAACIgMAAIAAAHIAKAAIAAACIgKAAIAAAKg");
	this.shape_5.setTransform(5.9,9.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(0.1,1,1).p("AGSh4IAAADIAAAAQgBAFgBAGQgBABAAABQAAAAAAABQgDAIgIAFQgHAFgKAAQgHAAgFgBQgDgCgDgCQgIgFAAgHQAAgGAIgFQACgCAEgCQAIgEAPgFQAGgBADgBIAAhUIAgAEQABAAABAAQAAAAABABQAkANgJAfAHEijIAAAAQgCAGgDAGQgBABgCAAAGHjUIAGAAAGHh9IAAgDAGSh+QABABAAADQgBABAAABAGSh+IAAAGAGSh+IAAhBQATAAAMAMQAOAMAAAQAIeilIAGAAAIeilIAgAEQABAAABAAQAAAAABABQAkANgJAfAJbh0IAAAAQgCAGgDAGQgBABgCAAAIphPIAAhBQATAAAMAMQAOAMAAAQAIehOIAAgDIAAhUAIphJIAAADIAAAAQgBAFgBAGQgBABAAABQAAAAAAABQgDAIgIAFQgHAFgKAAQgLAAgHgFQgIgFAAgHQAAgBABgBQABgFAGgEQAHgFAWgIQAGgBADgBAIphPQABABAAADQgBABAAABAIphPIAAAGAFwAcIAAABQgCAFgDAHQgBAAgCAAAEhAIQABACAAACQABAGgCAJAEzgUIAgAEQABAAABABQAAAAABAAQAWAJADAPAE+BBIAAgbIAAgmQAMAAAJAFQAFADAFAEIAAAAQAOAMAAARAEzgUIAGAAAE+BBQABACAAACQgBABAAABAE+BBIAAAGIAAADIAAAAQgBAGgBAFQgBABAAABQAAABAAAAQgDAJgIAFQgHAFgKAAQgLAAgHgFQgIgFAAgHQAAgHAIgFQAHgFAWgHQAGgCADgBAEzBDIAAgEIAAgeIAAg1Ah1AMQAAARgNANQgNAMgRAAQgSAAgMgMQgNgNAAgRQAAgRANgMQAMgNASAAQARAAANANQANAMAAARgAovBWIAgAEQABAAABAAQAAAAABABQAkANgJAfAn3CTQgBABgCAAAokCsIAAhBQATAAAMAMQAOAMAAAQAnyCHIAAAAQgCAGgDAGAokCsIAAAGIAAADIAAAAQgBAFgBAGQgBABAAABQAAAAAAABQgDAIgIAFQgHAFgKAAQgLAAgHgFQgIgFAAgHQAAgGAIgFQAHgFAWgIQAGgBADgBAokCsQABABAAADQgBABAAABAovBWIAGAAAovCtIAAgDIAAhU");
	this.shape_6.setTransform(14.5,9.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1).p("AJurnQgEgFAAgHQAAgIAGgGQAGgGAIAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgDADgEABQgCACgCAAQgCAAgCAAQgBAAgCAAIgCAEAJ7reQgGgBgFgFQgCgBAAgCIjqHTIAAAwID8n2AFDkQIAAg5IBBAAIAAA1AENgmQALADAKADQARAFAQAGIAAhNIAAgwgAEiggIAhhCAFDiSIAAh+IqQAAIAADzQCMgwCtAAQCaAACHAnAHhCCQAgARAbAnQAwBFAABiQAABigwBFQgwBFhDAAQhEAAgwhFQgvhFAAhiQAAhiAvhFQAwhFBEAAQAOAAANADQAJACAIADAGEADQAgAOAeAQQDPBuA5DeQA5DfhtBXQhsBYmoAMQmnAMj0hPQiUgvgkhsQgXhFAXheQABgCAAgCQA+jzC7huQAmgXAqgRIgBAAIAAkJIAAg5ILLAAAE0B7QAAAcgUATQgUAUgcAAQgcAAgUgUQgTgTAAgcQAAgcATgUQAUgUAcAAQAcAAAUAUQAUAUAAAcgAD6CFIAjAAIAAAMIgjAAgACNBgQAAAYgnAaQgpAZg3AAQg2AAgogWQgngYgBgbQAAgbAogIQAogJA2AAQA3AAApAJQAnAJAAAYgACAETIBDAAIAAAcIhDAAgAAhETIBDAAIAAAcIhDAAgAA3HnQAAAGgEAFQgFAEgGAAQgHAAgEgEQgEgFAAgGQAAgHAEgEQAEgFAHAAQAGAAAFAFQAEAEAAAHgAhVIoIhJAAIAAjLIFQAAIAADLIhOAAIi5AAIAAh2IC5AAIAAB2AFDgVQAhALAgANAGEjkIAADnAlNkQIg7AAAmHgHQAcgMAegKAj5BaQAFgDAFAAQAIAAAGAGQAGAGAAAIQAAAIgGAGQgGAGgIAAQgIAAgGgGQgGgGAAgIQAAgEACgEQgFADgGAAQgIAAgHgGQgFgFAAgJQAAgIAFgHQAHgFAIAAQAJAAAFAFQAGAHAAAIQAAAEgBAEgAkBBjQABgDADgDQACgCACgBAjDB/QAAAFgEADQgDAEgFAAQgFAAgEgEQgDgDAAgFQAAgFADgEQAEgDAFAAQAFAAADADQAEAEAAAFgAhBETIBCAAIAAAcIhCAAgAimETIBDAAIAAAcIhDAAgAgVHnQAAAGgEAFQgFAEgGAAQgHAAgEgEQgFgFAAgGQAAgHAFgEQAEgFAHAAQAGAAAFAFQAEAEAAAHgAj8FgQAABigwBFQgvBFhDAAQhEAAgwhFQgvhFAAhiQAAhiAvhFQAwhFBEAAQBDAAAvBFQAwBFAABig");
	this.shape_7.setTransform(-1.7,0);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#999999").s().p("ABbBlIAAh1Ii6AAIAAB1IhIAAIAAjJIFPAAIAADJgAAUAvQgFgEAAgHQAAgGAFgEQAEgFAGAAQAHAAAEAFQAFAEAAAGQAAAHgFAEQgEAFgHAAQgGAAgEgFgAg5AvQgEgEAAgHQAAgGAEgEQAFgFAGAAQAHAAAFAFQAEAEAAAGQAAAHgEAEQgFAFgHAAQgGAAgFgFg");
	this.shape_8.setTransform(-0.8,45.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFCC33").s().p("AByAOIAAgbIBDAAIAAAbgAATAOIAAgbIBDAAIAAAbgAhPAOIAAgbIBDAAIAAAbgAi0AOIAAgbIBDAAIAAAbg");
	this.shape_9.setTransform(-0.3,28.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#666666").s().p("AEwDGQguhFgBhiQABhhAuhFQAxhFBDAAQAOAAANADQAJACAIADIAAAfIgIACQgWAIgIAFQgHAFAAAGQAAAHAHAFQAIAFALAAQAKAAAHgFQAIgFACgIIABgBIAAgCIACgLIABAAIAAgDIABgCQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAgBAAAAIAAgcQAgARAbAnQAwBFAABhQAABigwBFQgwBFhDAAQhDAAgxhFgAoXDFQgvhFAAhiQAAhhAvhFQAxhFBDAAQBDAAAwBFQAvBFAABhQAABigvBFQgwBFhDAAQhDAAgxhFgAmRg7IgJADQgWAHgHAFQgIAFAAAHQAAAHAIAFQAHAFALAAQAKAAAHgFQAIgFADgJIAAgBIABgCIABgLIABAAIAAgDIAAgCQABAAAAgBQAAgBAAAAQAAgBgBAAQAAAAAAgBIAAhBIAHACQARAEAJALIADAGIAAABIABAAQABAAAAABQAAAAABABQAAAAAAABQAAAAABABIAAADIACAGIAAAEIABADIABgDIAAAAIABAAIACgFIADgHIAAgBIABAAIAAgCQACgKgGgKIAAgBIgDgDIgFgGQgGgHgJgFQAcALAAAWQAAAFgBAGQABgGAAgFQAAgWgcgLIgBAAIgCgBQgKgEgLAAQgDgBgCABIgGAAgAC7iXQgTgTAAgcQAAgcATgUQAVgUAcAAQAbAAAUAUQAUAUAAAcQAAAcgUATQgUAUgbAAQgcAAgVgUgAD1iwIAjAAIAAgMIgjAAIAjAAIAAAMIgjAAIAAgMIAAAMgAjdi6QgDgDAAgFQAAgFADgEQAEgDAFAAQAFAAAEADQADAEAAAFQAAAFgDADQgEAEgFAAQgFAAgEgEgAkBjIQgHgGAAgIQAAgEACgEQACgDADgDIADgDQAFgDAFAAQAJAAAFAGQAGAGABAIQgBAIgGAGQgFAGgJAAQgIAAgFgGgAkfjhQgGgFAAgJQAAgIAGgHQAGgFAIAAQAJAAAGAFQAFAHAAAIIgBAIIgDADQgDADgCADQgEADgHAAQgIAAgGgGgAkGjeIAAAAg");
	this.shape_10.setTransform(-1.2,32.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.498)").s().p("AgdAeQgNgMAAgSQAAgQANgNQAMgMARAAQARAAANAMQANANAAAQQAAASgNAMQgNAMgRAAQgRAAgMgMg");
	this.shape_11.setTransform(-1.6,10.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CCCCCC").s().p("ApVDRQgHgFAAgHQAAgHAHgFQAIgFAWgHIAIgDIAAAEIAAgEIAAhUIAhAEIABABIABAAQAKAFAGAHIAFAGIADADIAAABQAFAKgCAKIAAACIAAAAIAAABIgGAMIAGgMIgDAHIgCAFIgBAAQAAgRgNgMQgNgMgSAAIAABBIAAAGIAAgGQAAAAAAABQABAAAAABQAAAAAAABQAAAAgBABIAAACIAAADIgBAAIgCALIAAACIgBABQgCAJgIAFQgHAFgLAAQgKAAgIgFgAn5CUIACAAIAAAAIgCADIAAgDgAn5CUIAAgEIgDgGIAAgDQAAgBAAgBQAAAAAAgBQgBAAAAAAQAAgBgBAAIgBAAIAAgBIgDgGQgJgLgSgEIgGgCQASAAANAMQANAMAAARIgCAAIAAAAgAENBmQgHgFAAgHQAAgGAHgFQAIgFAWgIIAIgCIAAADIAAgDIAAgfIAAg0IAhAEIABAAIABABQAKAEAGAHIAFAGIADACIAAACIACACIABADIABAHIAAAEIgBADIAAADIAAAAIAAAAIgGAMIAGgMIgDAHIgCAFIgBAAQAAgQgNgMIgBgBQgEgEgFgCQgKgFgLAAIAAAlIAAAcQAAAAAAAAQABABAAAAQAAABAAAAQAAABgBABIAAACIAAgGIAAAGIAAADIgBAAIgCALIAAACIgBABQgCAIgIAFQgHAFgLAAQgKAAgIgFgAojBrIAAAAgAoOBagAovBWIAHAAQACgBADABQALAAAKAEgAj6A5QgngYgBgbQAAgaAogIQAogJA3AAQA3AAApAJQAnAJAAAXQAAAYgnAaQgpAZg3AAQg3AAgogWgAi+gRQgMANAAAQQAAASAMAMQANANARAAQASAAAMgNQANgMAAgSQAAgQgNgNQgMgMgSAAQgRAAgNAMgAFpAqIACgBIAAABIgCACIAAgCgAFpAqIAAgEIgDgGIAAgEQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAIgBAAIAAgBIgDgHIgFgFIgHgEQgHgDgIgCIgGgCQALAAAKAFQAFACAEAEIABABQANAMAAAQIgCABIAAAAgAE/ABIAAAAgAFUgPgAEzgTIAHAAQACgBADAAQALABAKAEgAEzgTgAH4gqQgHgFAAgHIAAgDQABgFAGgEQAIgFAWgHIAIgDIAAAEIAAgEIAAhUIAhAEIABABIABAAQAKAFAGAHIAFAGIADADIAAABQAFAKgCAKIAAACIAAAAIAAABIgGAMQAAgRgNgMQgNgMgSAAIAABBIAAAGIAAADIgBAAIgCALIAAACIgBABQgCAJgIAFQgHAFgLAAQgKAAgIgFgAIqhPQAAAAAAABQABAAAAABQAAAAAAABQAAAAgBABIAAACgAFohWIgHgDQgHgFAAgHQAAgHAHgFIAHgDQAIgEAPgFIAIgDIAAAEIAAgEIAAhUIAhAEIABABIABAAQAKAFAGAHIAFAGIADADIAAABQAFAKgCAKIAAACIAAAAIAAABIgDAHIgCAFIgBAAIgCAAIAAgEIgDgGIAAgDQAAgBAAgBQAAAAAAgBQgBAAAAAAQAAgBgBAAIgBAAIAAgBIgDgGQgJgLgSgEIgGgCQASAAANAMQANAMAAARIAGgMIgGAMQAAgRgNgMQgNgMgSAAIAABBIAAAGIAAgGQAAAAAAABQABAAAAABQAAAAAAABQAAAAgBABIAAACIAAADIgBAAIgCALIAAACIgBABQgCAJgIAFQgHAFgLAAQgGAAgFgCgAJUhnIACAAIAAAAIgCADIAAgDgAJUhnIAAgEIgDgGIAAgDQAAgBAAgBQAAAAAAgBQgBAAAAAAQAAgBgBAAIgBAAIAAgBIgDgGQgJgLgSgEIgGgCQASAAANAMQANAMAAARIgCAAIAAAAgAJWhnIAGgMIgDAHIgCAFgAJchzIAAAAgAG9iWIACAAIAAAAIgCADIAAgDgAIeilIAHAAQACgBADABQALAAAKAEgAGojQgAGHjUIAHAAQACgBADABQALAAAKAEg");
	this.shape_12.setTransform(14.5,9.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0080FE").s().p("AoZFnQiUgwgkhrQgXhFAXheIABgEQA+jzC7huQAmgWAqgSQAcgNAegKQCMgvCtAAQCaAACHAmIAVAGIAhALQAhALAgAPQAgANAeAQQDPBuA5DeQA5DehtBYQhsBXmoAMQg6ACg3AAQlYAAjShEgAE1ijQgvBFAABhQAABiAvBFQAwBFBEAAQBDAAAwhFQAwhFAAhiQAAhhgwhFQgbgmgggRIAAgmIAGACQAIACAHAEIAHAEIAFAFIADAGIAAABIABAAQABABAAAAQAAAAAAABQABAAAAABQAAAAAAABIAAADIADAGIAAAEIAAADIACgDIAAAAIABAAIACgFIADgHIAAgBIAAAAIAAgCIABgEIAAgEIgBgGIgCgDQgCgQgXgJIgBAAIgBgBQgKgEgLAAQgDgBgCABIgHAAIAAA2QgIgEgJgCIABgKIAAgFIgBgEIABAEIAAAFIgBAKQgNgDgOAAQhEAAgwBFgAoSijQgvBFAABgQAABiAvBFQAwBFBEAAQBDAAAvhFQAwhFAAhiQAAhggwhFQgvhFhDAAQhEAAgwBFgAieDKIBJAAIC5AAIBOAAIAAjKIlQAAgACAgtIBDAAIAAgdIhDAAgAAhgtIBDAAIAAgdIhDAAgAhBgtIBCAAIAAgdIhCAAgAimgtIBDAAIAAgdIhDAAgADAkSQgTAUAAAcQAAAcATAUQAUAUAcAAQAcAAAUgUQAUgUAAgcQAAgcgUgUQgUgTgcAAQgcAAgUATgAhYkeQgoAJAAAbQABAbAnAXQAoAXA2AAQA3AAApgaQAngZAAgYQAAgYgngKQgpgJg3AAQg2AAgoAJgAjYjmQgDADAAAFQAAAFADAEQAEADAFAAQAFAAADgDQAEgEAAgFQAAgFgEgDQgDgEgFAAQgFAAgEAEgAkDjyQAAAIAGAGQAGAGAIAAQAIAAAGgGQAGgGAAgIQAAgIgGgGQgGgGgIAAQgFAAgFADIABgHQAAgJgGgGQgFgGgJAAQgIAAgHAGQgFAGAAAJQAAAIAFAGQAHAGAIAAQAGAAAFgDQgCADAAAEgAIQj6IAAgBIgDgDIgFgGQgGgHgKgFQAXAJACAQIgBgDgAH4kQIAAAAg");
	this.shape_13.setTransform(-1.7,35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#0000FF").s().p("AFGCNIAAhNIAAgwIAAh9IAAg4IBBAAIAAA0IAAAwIAADoQgggPghgLgAmGCcIAAkJIA8AAIAADyQgeAKgdANgAlKhtIg8AAIAAg4ILMAAIAAA4gAmGhtgAFGilg");
	this.shape_14.setTransform(-2,-16.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("Al0KYIAAh2IC7AAIAAB2gAkAJMQgFAFAAAGQAAAHAFAEQAEAFAGgBQAHABAEgFQAFgEAAgHQAAgGgFgFQgEgEgHAAQgGAAgEAEgAlOJMQgEAFAAAGQAAAHAEAEQAFAFAGgBQAHABAFgFQAEgEAAgHQAAgGgEgFQgFgEgHAAQgGAAgFAEgAgQBJIA1hrIAAAvIghBCIgUgGgABmikIDqnSIACACQAEAFAHABQgHgBgEgFIgCgCQgFgFAAgHQAAgJAHgGQAFgGAJAAQAJAAAFAGQAHAGAAAJQAAAIgHAGQgCADgEACIgEABIgEAAIgDAAIADAAIAEAAIAEgBIAKAAIgJAEIgBABIgGAAIj8H2gAFbpqIACgEg");
	this.shape_15.setTransform(26.9,-11.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__CRadio, new cjs.Rectangle(-76,-78.6,152.1,157.3), null);


(lib.CRadio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AAHAOIAAgOIAAgFIgCAFIgEAJIgBAAIgFgJIgCgFIABAFIAAAOIgEAAIAAgbIAEAAIAGAMIAAADIABAAIAAgDIAGgMIAEAAIAAAbg");
	this.shape.setTransform(-9.6,10.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AAFAOIgCgGIgGAAIgBAGIgFAAIAIgbIADAAIAIAbgAAAgCIgCAGIAEAAIgBgGIgBgEg");
	this.shape_1.setTransform(-12,10.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAHAOIAAgOIAAgFIgBAFIgFAJIgBAAIgFgJIgCgFIABAFIAAAOIgEAAIAAgbIAEAAIAGAMIAAADIABAAIAAgDIAGgMIAEAAIAAAbg");
	this.shape_2.setTransform(8.5,10.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgGAOIAAgbIANAAIAAAFIgIAAIAAAHIAIAAIAAAEIgIAAIAAALg");
	this.shape_3.setTransform(6.4,10.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.1,1,1).p("AGSh4IAAADIAAAAQgBAFgBAGQgBABAAABQAAAAAAABQgDAIgIAFQgHAFgKAAQgHAAgFgBQgDgCgDgCQgIgFAAgHQAAgGAIgFQACgCAEgCQAIgEAPgFQAGgBADgBIAAhUIAgAEQABAAABAAQAAAAABABQAkANgJAfAHEijIAAAAQgCAGgDAGQgBABgCAAAGHjUIAGAAAGHh9IAAgDAGSh+QABABAAADQgBABAAABAGSh+IAAAGAGSh+IAAhBQATAAAMAMQAOAMAAAQAIeilIAGAAAIeilIAgAEQABAAABAAQAAAAABABQAkANgJAfAJbh0IAAAAQgCAGgDAGQgBABgCAAAIphPIAAhBQATAAAMAMQAOAMAAAQAIehOIAAgDIAAhUAIphJIAAADIAAAAQgBAFgBAGQgBABAAABQAAAAAAABQgDAIgIAFQgHAFgKAAQgLAAgHgFQgIgFAAgHQAAgBABgBQABgFAGgEQAHgFAWgIQAGgBADgBAIphPQABABAAADQgBABAAABAIphPIAAAGAFwAcIAAABQgCAFgDAHQgBAAgCAAAEhAIQABACAAACQABAGgCAJAEzgUIAgAEQABAAABABQAAAAABAAQAWAJADAPAE+BBIAAgbIAAgmQAMAAAJAFQAFADAFAEIAAAAQAOAMAAARAEzgUIAGAAAE+BBQABACAAACQgBABAAABAE+BBIAAAGIAAADIAAAAQgBAGgBAFQgBABAAABQAAABAAAAQgDAJgIAFQgHAFgKAAQgLAAgHgFQgIgFAAgHQAAgHAIgFQAHgFAWgHQAGgCADgBAEzBDIAAgEIAAgeIAAg1Ah1AMQAAARgNANQgNAMgRAAQgSAAgMgMQgNgNAAgRQAAgRANgMQAMgNASAAQARAAANANQANAMAAARgAovBWIAgAEQABAAABAAQAAAAABABQAkANgJAfAn3CTQgBABgCAAAokCsIAAhBQATAAAMAMQAOAMAAAQAnyCHIAAAAQgCAGgDAGAokCsIAAAGIAAADIAAAAQgBAFgBAGQgBABAAABQAAAAAAABQgDAIgIAFQgHAFgKAAQgLAAgHgFQgIgFAAgHQAAgGAIgFQAHgFAWgIQAGgBADgBAokCsQABABAAADQgBABAAABAovBWIAGAAAovCtIAAgDIAAhU");
	this.shape_4.setTransform(14.5,9.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("AJurnQgEgFAAgHQAAgIAGgGQAGgGAIAAQAJAAAGAGQAGAGAAAIQAAAJgGAGQgDADgEABQgCACgCAAQgCAAgCAAQgBAAgCAAIgCAEAJ7reQgGgBgFgFQgCgBAAgCIjqHTIAAAwID8n2AFDkQIAAg5IBBAAIAAA1AENgmQALADAKADQARAFAQAGIAAhNIAAgwgAEiggIAhhCAFDiSIAAh+IqQAAIAADzQCMgwCtAAQCaAACHAnAHhCCQAgARAbAnQAwBFAABiQAABigwBFQgwBFhDAAQhEAAgwhFQgvhFAAhiQAAhiAvhFQAwhFBEAAQAOAAANADQAJACAIADAGEADQAgAOAeAQQDPBuA5DeQA5DfhtBXQhsBYmoAMQmnAMj0hPQiUgvgkhsQgXhFAXheQABgCAAgCQA+jzC7huQAmgXAqgRIgBAAIAAkJIAAg5ILLAAADsCdQgPAAgLgKQgKgLAAgPQAAgOAKgLQALgKAPAAQAOAAALAKQAKALAAAOQAAAPgKALQgLAKgOAAIAAgqACNBgQAAAYgnAaQgpAZg3AAQg2AAgogWQgngYgBgbQAAgbAogIQAogJA2AAQA3AAApAJQAnAJAAAYgACAETIBDAAIAAAcIhDAAgAAhETIBDAAIAAAcIhDAAgAA3HnQAAAGgEAFQgFAEgGAAQgHAAgEgEQgEgFAAgGQAAgHAEgEQAEgFAHAAQAGAAAFAFQAEAEAAAHgAhVIoIhJAAIAAjLIFQAAIAADLIhOAAIi5AAIAAh2IC5AAIAAB2AFDgVQAhALAgANAGEjkIAADnAlNkQIg7AAAmHgHQAcgMAegKAj5BaQAFgDAFAAQAIAAAGAGQAGAGAAAIQAAAIgGAGQgGAGgIAAQgIAAgGgGQgGgGAAgIQAAgEACgEQgFADgGAAQgIAAgHgGQgFgFAAgJQAAgIAFgHQAHgFAIAAQAJAAAFAFQAGAHAAAIQAAAEgBAEgAkBBjQABgDADgDQACgCACgBAjDB/QAAAFgEADQgDAEgFAAQgFAAgEgEQgDgDAAgFQAAgFADgEQAEgDAFAAQAFAAADADQAEAEAAAFgAhBETIBCAAIAAAcIhCAAgAimETIBDAAIAAAcIhDAAgAgVHnQAAAGgEAFQgFAEgGAAQgHAAgEgEQgFgFAAgGQAAgHAFgEQAEgFAHAAQAGAAAFAFQAEAEAAAHgAj8FgQAABigwBFQgvBFhDAAQhEAAgwhFQgvhFAAhiQAAhiAvhFQAwhFBEAAQBDAAAvBFQAwBFAABig");
	this.shape_5.setTransform(-1.7,0);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#999999").s().p("ABbBlIAAh1Ii6AAIAAB1IhIAAIAAjJIFPAAIAADJgAAUAvQgFgEAAgHQAAgGAFgEQAEgFAGAAQAHAAAEAFQAFAEAAAGQAAAHgFAEQgEAFgHAAQgGAAgEgFgAg5AvQgEgEAAgHQAAgGAEgEQAFgFAGAAQAHAAAFAFQAEAEAAAGQAAAHgEAEQgFAFgHAAQgGAAgFgFg");
	this.shape_6.setTransform(-0.8,45.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFCC33").s().p("AByAOIAAgbIBDAAIAAAbgAATAOIAAgbIBDAAIAAAbgAhPAOIAAgbIBDAAIAAAbgAi0AOIAAgbIBDAAIAAAbg");
	this.shape_7.setTransform(-0.3,28.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#666666").s().p("AEwDDQguhGgBhiQABhgAuhFQAxhFBDgBQAOABANACQAJACAIAEIAAAeIgIADQgWAIgIAFQgHAEAAAHQAAAHAHAFQAIAFALAAQAKAAAHgFQAIgFACgJIABAAIAAgCIACgLIABAAIAAgEIABgCQAAAAAAgBQAAAAAAgBQAAAAgBgBQAAAAAAAAIAAgcQAgARAbAnQAwBFAABgQAABigwBGQgwBEhDAAQhDAAgxhEgAoXDCQgvhGAAhiQAAhgAvhFQAxhFBDAAQBDAAAwBFQAvBFAABgQAABigvBGQgwBEhDAAQhDAAgxhEgAmRg+IgJACQgWAIgHAFQgIAFAAAGQAAAIAIAEQAHAGALAAQAKAAAHgGQAIgEADgJIAAgBIABgCIABgLIABAAIAAgDIAAgCQABgBAAAAQAAgBAAAAQAAgBgBAAQAAgBAAAAIAAhBIAHACQARAEAJALIADAGIAAABIABAAQABAAAAABQAAAAABAAQAAABAAAAQAAABABAAIAAAEIACAGIAAAEIABACIABgCIAAAAIABAAIACgGIADgHIAAAAIABAAIAAgCQACgLgGgJIAAgBIgDgDIgFgGQgGgIgJgEQAcALAAAVQAAAGgBAGQABgGAAgGQAAgVgcgLIgBgBIgCAAQgKgEgLAAQgDgBgCABIgGAAgADninIAAgqIAAAqQgOAAgMgLQgKgKAAgPQAAgOAKgLQAMgLAOABQAPgBAKALQAKALAAAOQAAAPgKAKQgKALgPAAgAjdi9QgDgEAAgFQAAgEADgEQAEgEAFABQAFgBAEAEQADAEAAAEQAAAFgDAEQgEADgFAAQgFAAgEgDgAkBjMQgHgGAAgHQAAgEACgEQACgDADgEIADgCQAFgDAFAAQAJAAAFAFQAGAHABAIQgBAHgGAGQgFAHgJgBQgIABgFgHgAkfjkQgGgGAAgIQAAgJAGgGQAGgFAIAAQAJAAAGAFQAFAGAAAJIgBAIIgDACQgDAEgCADQgEADgHAAQgIAAgGgGgAkGjhIAAAAg");
	this.shape_8.setTransform(-1.2,32.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.498)").s().p("AgdAeQgNgMAAgSQAAgQANgNQAMgMARAAQARAAANAMQANANAAAQQAAASgNAMQgNAMgRAAQgRAAgMgMg");
	this.shape_9.setTransform(-1.6,10.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CCCCCC").s().p("ApVDRQgHgFAAgHQAAgHAHgFQAIgFAWgHIAIgDIAAAEIAAgEIAAhUIAhAEIABABIABAAQAKAFAGAHIAFAGIADADIAAABQAFAKgCAKIAAACIAAAAIAAABIgGAMIAGgMIgDAHIgCAFIgBAAQAAgRgNgMQgNgMgSAAIAABBIAAAGIAAgGQAAAAAAABQABAAAAABQAAAAAAABQAAAAgBABIAAACIAAADIgBAAIgCALIAAACIgBABQgCAJgIAFQgHAFgLAAQgKAAgIgFgAn5CUIACAAIAAAAIgCADIAAgDgAn5CUIAAgEIgDgGIAAgDQAAgBAAgBQAAAAAAgBQgBAAAAAAQAAgBgBAAIgBAAIAAgBIgDgGQgJgLgSgEIgGgCQASAAANAMQANAMAAARIgCAAIAAAAgAENBmQgHgFAAgHQAAgGAHgFQAIgFAWgIIAIgCIAAADIAAgDIAAgfIAAg0IAhAEIABAAIABABQAKAEAGAHIAFAGIADACIAAACIACACIABADIABAHIAAAEIgBADIAAADIAAAAIAAAAIgGAMIAGgMIgDAHIgCAFIgBAAQAAgQgNgMIgBgBQgEgEgFgCQgKgFgLAAIAAAlIAAAcQAAAAAAAAQABABAAAAQAAABAAAAQAAABgBABIAAACIAAgGIAAAGIAAADIgBAAIgCALIAAACIgBABQgCAIgIAFQgHAFgLAAQgKAAgIgFgAojBrIAAAAgAoOBagAovBWIAHAAQACgBADABQALAAAKAEgAj6A5QgngYgBgbQAAgaAogIQAogJA3AAQA3AAApAJQAnAJAAAXQAAAYgnAaQgpAZg3AAQg3AAgogWgAi+gRQgMANAAAQQAAASAMAMQANANARAAQASAAAMgNQANgMAAgSQAAgQgNgNQgMgMgSAAQgRAAgNAMgAFpAqIACgBIAAABIgCACIAAgCgAFpAqIAAgEIgDgGIAAgEQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAIgBAAIAAgBIgDgHIgFgFIgHgEQgHgDgIgCIgGgCQALAAAKAFQAFACAEAEIABABQANAMAAAQIgCABIAAAAgAE/ABIAAAAgAFUgPgAEzgTIAHAAQACgBADAAQALABAKAEgAEzgTgAH4gqQgHgFAAgHIAAgDQABgFAGgEQAIgFAWgHIAIgDIAAAEIAAgEIAAhUIAhAEIABABIABAAQAKAFAGAHIAFAGIADADIAAABQAFAKgCAKIAAACIAAAAIAAABIgGAMQAAgRgNgMQgNgMgSAAIAABBIAAAGIAAADIgBAAIgCALIAAACIgBABQgCAJgIAFQgHAFgLAAQgKAAgIgFgAIqhPQAAAAAAABQABAAAAABQAAAAAAABQAAAAgBABIAAACgAFohWIgHgDQgHgFAAgHQAAgHAHgFIAHgDQAIgEAPgFIAIgDIAAAEIAAgEIAAhUIAhAEIABABIABAAQAKAFAGAHIAFAGIADADIAAABQAFAKgCAKIAAACIAAAAIAAABIgDAHIgCAFIgBAAIgCAAIAAgEIgDgGIAAgDQAAgBAAgBQAAAAAAgBQgBAAAAAAQAAgBgBAAIgBAAIAAgBIgDgGQgJgLgSgEIgGgCQASAAANAMQANAMAAARIAGgMIgGAMQAAgRgNgMQgNgMgSAAIAABBIAAAGIAAgGQAAAAAAABQABAAAAABQAAAAAAABQAAAAgBABIAAACIAAADIgBAAIgCALIAAACIgBABQgCAJgIAFQgHAFgLAAQgGAAgFgCgAJUhnIACAAIAAAAIgCADIAAgDgAJUhnIAAgEIgDgGIAAgDQAAgBAAgBQAAAAAAgBQgBAAAAAAQAAgBgBAAIgBAAIAAgBIgDgGQgJgLgSgEIgGgCQASAAANAMQANAMAAARIgCAAIAAAAgAJWhnIAGgMIgDAHIgCAFgAJchzIAAAAgAG9iWIACAAIAAAAIgCADIAAgDgAIeilIAHAAQACgBADABQALAAAKAEgAGojQgAGHjUIAHAAQACgBADABQALAAAKAEg");
	this.shape_10.setTransform(14.5,9.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#0080FE").s().p("AoZFnQiUgwgkhrQgXhFAXheIABgEQA+jzC7huQAmgWAqgSQAcgNAegKQCMgvCtAAQCaAACHAmIAVAGIAhALQAhALAgAPQAgANAeAQQDPBuA5DeQA5DehtBYQhsBXmoAMQg6ACg3AAQlYAAjShEgAE1ijQgvBFAABhQAABiAvBFQAwBFBEAAQBDAAAwhFQAwhFAAhiQAAhhgwhFQgbgmgggRIAAgmIAGACQAIACAHAEIAHAEIAFAFIADAGIAAABIABAAQABABAAAAQAAAAAAABQABAAAAABQAAAAAAABIAAADIADAGIAAAEIAAADIACgDIAAAAIABAAIACgFIADgHIAAgBIAAAAIAAgCIABgEIAAgEIgBgGIgCgDQgCgQgXgJIgBAAIgBgBQgKgEgLAAQgDgBgCABIgHAAIAAA2QgIgEgJgCIABgKIAAgFIgBgEIABAEIAAAFIgBAKQgNgDgOAAQhEAAgwBFgAoSijQgvBFAABgQAABiAvBFQAwBFBEAAQBDAAAvhFQAwhFAAhiQAAhggwhFQgvhFhDAAQhEAAgwBFgAieDKIBJAAIC5AAIBOAAIAAjKIlQAAgACAgtIBDAAIAAgdIhDAAgAAhgtIBDAAIAAgdIhDAAgAhBgtIBCAAIAAgdIhCAAgAimgtIBDAAIAAgdIhDAAgAhYkeQgoAJAAAbQABAbAnAXQAoAXA2AAQA3AAApgaQAngZAAgYQAAgYgngKQgpgJg3AAQg2AAgoAJgADSj8QgKAKAAAPQAAAPAKAKQALALAPAAQAOAAALgLQAKgKAAgPQAAgPgKgKQgLgLgOAAQgPAAgLALgAjYjmQgDADAAAFQAAAFADAEQAEADAFAAQAFAAADgDQAEgEAAgFQAAgFgEgDQgDgEgFAAQgFAAgEAEgAkDjyQAAAIAGAGQAGAGAIAAQAIAAAGgGQAGgGAAgIQAAgIgGgGQgGgGgIAAQgFAAgFADIABgHQAAgJgGgGQgFgGgJAAQgIAAgHAGQgFAGAAAJQAAAIAFAGQAHAGAIAAQAGAAAFgDQgCADAAAEgAIQj6IAAgBIgDgDIgFgGQgGgHgKgFQAXAJACAQIgBgDgAH4kQIAAAAg");
	this.shape_11.setTransform(-1.7,35);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#0000FF").s().p("AFGCNIAAhNIAAgwIAAh9IAAg4IBBAAIAAA0IAAAwIAADoQgggPghgLgAmGCcIAAkJIA8AAIAADyQgeAKgdANgAlKhtIg8AAIAAg4ILMAAIAAA4gAmGhtgAFGilg");
	this.shape_12.setTransform(-2,-16.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("Al0KYIAAh2IC7AAIAAB2gAkAJMQgFAFAAAGQAAAHAFAEQAEAFAGgBQAHABAEgFQAFgEAAgHQAAgGgFgFQgEgEgHAAQgGAAgEAEgAlOJMQgEAFAAAGQAAAHAEAEQAFAFAGgBQAHABAFgFQAEgEAAgHQAAgGgEgFQgFgEgHAAQgGAAgFAEgAgQBJIA1hrIAAAvIghBCIgUgGgABmikIDqnSIACACQAEAFAHABQgHgBgEgFIgCgCQgFgFAAgHQAAgJAHgGQAFgGAJAAQAJAAAFAGQAHAGAAAJQAAAIgHAGQgCADgEACIgEABIgEAAIgDAAIADAAIAEAAIAEgBIAKAAIgJAEIgBABIgGAAIj8H2gAFbpqIACgEg");
	this.shape_13.setTransform(26.9,-11.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.CRadio, new cjs.Rectangle(-76,-78.6,152.1,157.3), null);


(lib.CFishtank_heater = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(96,96,96,0.6)").s().p("AACAJIAAgBIAAgBIgCABIgCAAIAAAAIgBAAIAAgBIAAgOIAAgBIABAAIAAAAIABAAIAAACIAAAAIAAALIADAAIACABIAAACIgBAAIAAABIgBAAg");
	this.shape.setTransform(-10.5,32.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,0,0,0.6)").s().p("ABUCrIgBgBIAAgBIADgTIABgKIABgBIAAgBIAAgDQACgLgBgLIgCgWIAAgTQAAgIgDgLQgDgLADgLQADgJgBgIIABgBIAAAAIABAAIABABQABAHgDALQgDAKACALQADALAAAIIABATIABAWQACALgCALIgBAEIAAABIAAABIgBAJQAAAFgEAPIAAABIgBAAIAAAAgAhWCdIAAgBQgDgGgCgGIAAgCIAAgBIgBgIQABgNAEgIIABgCQADgGgCgIIgBgLIgBgHIAAgBIgBgTIAAgUQABgLgCgLIAAAAQgBgLACgJIACgJIACgKQABgIgDgJIgBgDIAAgBIABgBIAAAAIABAAIAAABQAFALgCAKIgDAUIgBADQgBAIABAIIAAACQABAKAAAKIAAAUIABATIACATQABAJgEAIIgBACQgDAIAAAKIAAAHIAAABIABACIACAJIACADIAAABIAAAAIgBAAIgBABIAAAAgABYAMIgBgBIgBAAIAAgUIAAgVIAAgTQAAgJgCgJQgBgIACgNQADgMABgLIAAAAQACgKgCgHIgDgSQgDgMADgLIABAAIABgBIABABIAAABQgDAKACALIAEASQABAHgBALQgBALgDANQgDAMACAIQACAIAAAKIAAATIAAAVIAAAUIAAAAIgBABIAAAAgAhWguIgBgBIAAgBIAAgUIAAgTIABgSIAAgCQACgIgCgIIgBgDQgDgKABgLIAAAAIADgPIAAgCIAAgCIAAgBIgBAAIAAgBIABgBIABABQAAAAAAAAQABAAAAABQAAAAAAABQABAAAAABIgBADIgCANIAAACIAAAAIAAAMIACAIQADAKgCAKIgCAUIAAATIAAAUIAAABIgBABIAAAAgAgZhsQgDAAgDgCQgCgCAAgEQAAgEACgCQADgCADAAQAEAAACACQACACAAAEQAAAEgCACQgCACgEAAIAAAAgAgdh4QAAAAgBABQAAAAAAABQAAAAgBABQAAAAAAABQAAABAAAAQABABAAAAQAAABAAAAQABABAAAAQABAAAAABQAAAAABAAQAAABABAAQABAAAAAAQABAAAAAAQABAAAAgBQABAAAAAAQABgBAAAAQABAAAAgBQAAAAAAgBQABAAAAgBQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAAAgBgBQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAAAgBAAQgBAAAAABQgBAAAAAAQAAABgBAAg");
	this.shape_1.setTransform(0.3,15.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(0,0,0,0.6)").s().p("AAPGgIgFAAIgJAAIgBAAIAAgBIAAgBIABAAIADAAIAGAAIAFAAIABAAIAAABIAAABIgBAAIAAAAgAgCGgIgHAAQgiAAgXgXQgYgYAAgiIAAguQgPgIgEgKQgBgDAAgFQAAgDABgEIAAAPIAAABIABAAIABAAIABAAQAEAIANAHIAAAAIABAAIAAABIANAFIAAABIABAAIAAAAIAQAFQAXAGAdABIAAAAIACAAIAIAAQAiAAAbgGIATgHIAFgCIAAAAQAcgMAAgQQAAgOgYgMIAAgBIAAgBQAaAMAAAQQAAASgcANIAAApQAAAigXAYQgVAUgcADIgBgBIgBAAIAAgBIAAAAIACgBIAAAAIALgCQANgDALgIIAMgKQAXgXAAggIAAgoIgEABIgFABIgBABIgOAEQgLADgNABIgBABQgRACgTAAIgHAAIgBAAIgCAAIgBAAIgPgBIgDgBIgOgBIgDgBIgBAAIgPgEIgBAAIgDgBIgNgEIgBAAIgBgBIgLgFIAAAtQAAAgAXAXQARARAVAFIAJABIAJABIAHAAIABAAIAAABIAAABIgBAAIAAAAgABBEEIAAAAIgBAAIAAgBIAAgEIAAgBIABAAIABAAIAAABIAAAEIAAABIgBAAIAAAAgAhqEBIAAgCIgBAAIgBAAIgBAAQAFgKAQgIIAAABIAAACQgOAIgEAJgAhWDtIAAgBIACgBIABAAIAAAAIABAAIAAABIgBABIAAAAIgCACIgBgCgABaDsIAAAAIgGgCIgDgBIgBAAIAAgBIAAgBIAAAAIABgBIABAAIADABIAAAAIAGADIAAABIgBABgAgpiEQgZgCgUgEIAAAAIgCAAIgBAAQgigIAAgKQAAgLAigIIABAAIAAAAIABABIAAABIgBAAIAAAAQggAHAAAKQAAAIAfAHIABAAIADABQATAEAZACQATABAWAAIAigBQAZgBAVgEIADAAIADgBQAjgHAAgJQAAgKgjgHIAAAAIAAgBIgBAAIAAgBIABgBIABAAQAlAIAAAMQAAALglAHIgDABIgBAAIgCABIAAAAIgCAAQgVADgYACIgiABQgWAAgTgCgAhZjIIgBAAIAAgBIAAiFQAAgiAYgYQAXgXAiAAIADAAIABAAIAAABIAAABIgBAAIgDAAQggAAgYAYQgXAXAAAgIAACFIAAABIAAAAIgBAAIAAAAgAA5mNQgPgLgRgDIAAAAIgBgBIAAgBIABgBIABAAQASADAOAMIABABIAAAAIAAABIgBAAIAAAAIgBAAg");
	this.shape_2.setTransform(0,5.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,0,0,0.2)").s().p("AgDAEQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQgBgBAAAAg");
	this.shape_3.setTransform(-2.3,3.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,0,0,0.498)").s().p("AA5CQIABgPIAAgBIAAglIgBieIABhaIAAgDIAGgDIADgCIAHgBIAIgDIAAAAIAAACIAAE0IAAACIAAAAIgBABIABABIAAABIAAAAQAAALgDAJIgLACIgBgBIgBAAIgBAAIAAABIgGABIgEABIACgagAhLCnIgFgCIAAAAIAAgBIgBgDIAAgHIAAgEIAAAAIABgBIAAgBIgBAAIAAAAIAAgYIABgCQAEgIgCgKIgCgSIgBgTIAAgUQABgKgBgLIAAgRIAAgFIAEgSQABgKgEgMIgBgBIAAAAIAAgBIABAAIAAgBIAAgUIAAgUIABgTQACgKgDgKIgBgIIAAgOIACgNIAAgEIADADIAGACIAEACIgCAYIgEB7IAAAbIAABJIABArIACAcIAAAAIAAABIgGgCgAhRBeIABALQABAHgCAHgAhRgfQACAJgBAIIgBAKgAhRhyQABAHgBAIIAAACg");
	this.shape_4.setTransform(-0.1,14.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#FFFFFF","#000000"],[0,1],367.9,260.7,367.9,260.7).s().p("AAOA8IAAgBIgBAAIgFAAIgGAAIABgBIAFAAIABAAQABAAABAAQAAABABAAQAAAAABgBQABAAAAAAIABAAIABAAIABAAIgBAAIgBABIAAAAIAAABgAgdA5IgFgCIgDgCQgCAAgFgEIgDgDQgEgCgBgDQgFgDAAgFQgEgDgCgGIAFAHQADAEAMALIAJAHQAFADAJACIgJgBgAAlAzIATgTQAFgHAEgKQAGgNADgMIACgJIAAgHQAEgNAAgIQAAgFgCgBIgBgDIABgBIADABQABAKgBALIgCAUIgDAPIgBAAIgCAGIgBABIgDAJIgEAKQgEAJgJAKQgLAIgNADIAJgFgAgcArIACABIACACIgEgDgAgRAnQgJgLgDgFIgHgSIgDgVQgCgOAAgIIABgBIAAAFIABAMIABAAQAAAGABAIIADAOIABABIABAHIACABQgCADAEADIABADIABABIAEAGQADACACADQABAAAAABQABAAAAAAQAAABABAAQAAAAAAABIABAAIABACIACACIgHgEgAgDAiIADAFIABABIgBABgAgEgEIAAgEIgBgCIAAgEIgCgPQgCgIAAgIIABAAIABAAIACAAIAAABQAAAAgBAAQAAABgBAAQAAAAgBABQAAAAAAABQgBACABADIALA9QAAAFgCAEIAAACgAg5APIgDgEIgBgEIgEgoQgBgOACgHIADABIAAAAIADAkQAAAJABAHQABAKACAEIABAEIAEAIIgIgKgAAVAUIABgDQACgFAAgFIAAgBIANg1IACgBIABABIgBAAIgCAFIgHAqQgCAGgFALIgCAFgAgWAIIgEgVIgCgiIADABIABABIgBACIgCAEIAAAKIACASIAFAagAAKAIIABgjIAAgEIABgEIABAVIgBAIIgBAFIAAAMgAg9AKIgEgKIgDgNIAIAXgAA2gqIAAAAIgBAKIAAABgAhKgqIABABIAAAFgAAMgtIACAAIgBADIgBgDgAA3gvQAAAAAAgBQAAAAAAgBQAAAAABAAQAAAAAAAAIADgBIgCACIgCADgAgsgxIACABIAAABIgCgCgAhPg5IgBABIAAgDIAAAAIABABIACAAIAAACIgCgBg");
	this.shape_5.setTransform(0.2,41.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.2)").s().p("AABASIAAgBIgBgBIgBgCIgBgCIgCgCIAAAAIgCgbIADAAIAAALIABABQAAADACAEIACACIAEAFQABADgBAGg");
	this.shape_6.setTransform(-6.7,30.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#FFFFFF","#7B7B7B","#313131","#000000"],[0,0,0.137,1],-11.4,-0.6,11.3,-0.6).s().p("AgJAlIgCAAIAAAAQgdgBgXgHIgPgFIgBAAIAAAAIgBAAIgMgGIgBAAIgBAAIAAAAQgMgIgEgIIACgBIABABIAAABIABAAIABgBIAAgCIgCAAIgEAAIAAgMQAEgJAPgIQABAHADAFIAAABIABAAIABgBIAFACIAGADIAAgBIAAABIACABIAAACIACACIAAABQAJAHAVACQAIADAOAAIAuAAQAWABAHgJIAEgGIAAAAIABgBIAAgBIAAgDIALgCQAEgJAAgMIADABIAGACIAAABIABAAIgBAKIgEATIAAABIABAAIABAAIABgBQADgPAAgEIABgJQAYALAAAPQAAAPgbAMIgBAAIgFACIgTAGQgbAHghAAIgJAAgAhageIACgBIAAADIAAAIIgCgKg");
	this.shape_7.setTransform(0.5,32.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#FFFFFF","#000000"],[0,1],-7,2.5,7,2.5).s().p("AAlCtIguAAQgOAAgIgCQgVgCgJgIIAAgCIACACIAAABIAFAAQAAgHgBgDIgEgEIgBgDQgDgFAAgDIgCAAIABgLIgDgBIgCgrIAAhJIABgbIAEh7IACgYIgEgCIACABIAKACIAPAGQASAFAbgGIA4gNIgBBaIABCeIAAAlIgiABIAHABIAbgBIgBAPIgDAaIAFgBIAGgBIAAAEIAAABIABAAIgEAGQgGAJgTAAIgEAAgAgLh0QADgDAAgDQAAgEgDgCQgCgCgEAAQgDAAgDACQgCACAAAEQAAADACADQADACADAAQAEAAACgCgAhBCaIAAgBIACADIgCgCg");
	this.shape_8.setTransform(-0.5,16.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#FFFFFF","#7B7B7B","#313131","#000000"],[0,0,0.137,1],-12.2,-0.3,12.3,-0.3).s().p("AgpATQgZgCgTgEIgDgBIgBAAQgfgHAAgHQAAgKAggHIAAACQAQAKAlABQBFADAigFQAMgCAGgEIAAgFIAAAAQAjAHAAAKQAAAIgjAHIgDABIgDAAQgVAEgZABIgiABQgWAAgTgBg");
	this.shape_9.setTransform(0,-9.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAAGeIgBgBIgBAAIgHAAIgIAAQgKgDgEgDIgKgHQgMgLgDgEIgEgGQACAFAEADQAAAFAFADQABAEAEABIADAEQAEADADAAIACACIAGACQgWgEgQgRQgXgXAAghIAAgsIAKAEIgBAAIAAADIABAAIADAAIAAgBIAMAEQgBAHABANIAEApIAAAEIAEAFIAHAJIgDgHIgCgFQgBgEgBgKQgCgIAAgJIgCgjIAPADIACAAIACACIAAgBIAOACIABAhIAEAXIACAHIgEgbIgCgSIAAgKIABgFIABgBIAAgCIAQABQgBAIACAIIACAPIAAAEIABACIAAAEIAGAqIAAgCQABgFAAgFIgLg9QgBgEABgCQABAAAAgBQAAAAABgBQAAAAABAAQAAgBABAAIgBgBIAHAAQATAAARgCIgNA3IgBAAQAAAGgBAFIgBACIgBADIADgGQAFgKABgIIAIgqIACgEIABgBIgCAAQANgCAMgCIAOgFIAAADQACACAAAFQAAAHgDANIgBAHIgBAKQgEAMgFAOQgEAJgGAHIgTATIgJAGIgKACIgBgBIgCAAIAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAQAAAAgBgBIgCAAIgEAAIgCABIgDAAIgBAAIAAABIAAAAIAAAAgAgWGQIgBgBIgDgBIAEACgAgIGNIgCgCIgBgCIgBAAQAAAAAAgBQAAAAAAAAQgBgBAAAAQgBAAAAgBQgCgDgDgBIgEgHIgBgBIgCgDQgDgDABgCIgBgBIgCgHIgBgBIgCgQQgCgHABgHIgCAAIgBgMIAAgEIAAABQgBAHACAOIAEAXIAHARQACAFAKALIAGAEgAADGMIAAgCIgBgBIgDgFgAAOFCIgBAFIAAAkIAAACIABgNIABgFIAAgIIAAgVgAg+FiIAEAKIAAABIgHgZgAA3FDIABgCIABgKIgBAAgAhGE9IgBgFIAAAAgAAPE3IABgCIgBAAIAAACgAA7EwQAAAAgBAAQAAAAAAABQAAAAgBAAQAAABAAAAIABACIABgDIACgCIAAAAIgCABgABDF9IAFgLIADgIIABgBIABgHIABAAIADgQIACgUQABgKgBgLIgDAAIAFgCIAEgBIAAAoQAAAhgXAXIgLAJQAIgJAEgJgAAXDXIAiAAIAAAAIgbABIgHgBgAgsg5IgPgFIgKgDIgCAAIgGgDIgDgCIgCgZIgDgrIgBAAIAAAAIABAAQATAEAZACQATABAWAAIAigBQAZgBAUgEIAAABIAAABQgBAYABAMIACARIgIACIgHACIgDACIgGADIAAACIg4ANQgOAEgMAAQgLAAgIgDgAgjigQglgBgQgLIAAgBIAAAAIABgBIAAgBIAAgBIgBAAIAAgZIABAAIABAAIgBAAIAAiGQAAggAXgXQAXgXAgAAIADAAIABALIAcABQAAgDACgIIABAAQARADAOALIABABQABAJgBALIARAAIACAJIABADIAAACQgBAPAEAdIAAAeIgBBoIABAGQABAEADAAIABAAIAAABIAAAAIAAAFQgGAFgLABQgXAEgnAAIgqgBg");
	this.shape_10.setTransform(0,6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#FFFFFF","#7B7B7B","#313131","#000000"],[0,0,0.137,1],-4.3,-0.4,5.2,-0.4).s().p("AAWBNQABgLgBgJIAAAAIABgBIAJAMIAGAKgAgqA0IAAgLIABAAIAAgBIAAgBIgBAAIABgRIABgOIABg6IAAgOIABgEQAFgJAOAAQAHAAAMADIAAABQANAGAIAMIAFAJIABAFIADATIABAEIAAAFIABAoIgKgFQABgVgJgTIgCgEIgEgHQgGgHAAgEIgHgHIgCAAQABACgDAGIgBAIIABA+IgBAJIgBAAIAAABIAAABIABABQgDAIABACgAAqAzIABAAIAAABIgBgBg");
	this.shape_11.setTransform(3.6,-39.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.CFishtank_heater, new cjs.Rectangle(-13.2,-47.4,26.5,95.8), null);


(lib.Chandholdingalgae = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF00").s().p("AAmDSQgTgBgKgDIgDgBIAAgBIgDAAIgRgMQgIgEgCgEIgBAAIAAgCIAAgCIgDgFIgJgJIgFgIIgCgHIAAgCIgCgCIgGgMQgEgHgCgIIAAgBIgBgKIgQgVIgOgOIABgEIgEgHQgFgFgLgKIgOgQIgPgZQgGgJgGgHIADgBQABgEgBgDIAPgOIALgRIAKgPQADgFADgDQAFgMASgXIAJgOIAAgCIABAAIALgVIADgHIACgCQgBgCABgDQACgBAGAAQALAAAHABIACAAIANACQAEACAMgBIAYAAIAPgBIANABIAIAAIAPABIAQABQABgDAHACQAGAAADACIAHAEQAJAFALANQAEAEACAEQACAEABAFQgBAFgEACQgCACgFgBIgKgDIgCABIACAFIAEAAIAJADIAKACIADADIADgCIABABIABABQAFAEAGAKIADAFQAEAHgDAMQABAIgDADQgBAFgGABQgHADgGAAQAGADAGAFIAFADQABADADABIADAFQAFAAADAEIAAAAIAEACQADACABAEIABADIABAMIABADQgCADAAAFQgBAVgQAfIgBADIgCADIgHALIADADIgBAAIgFgCIAFgOIgGgTIAAgBIgCgFIgBgBIAAgCIAAgCIgDgMIgFgCIgqgYQgLgGgGgEQgGgBgBAEQgCAHANAEQATAHAPAIQgBABAAAAQAAABAAABQAAAAAAABQAAAAABABIAIACIAGAEIgBADIAEAHIgBAAIACAFIACADIABAAIAEAKIADAHIADAKIgBADIAAACIABAMIAAACIgCAEIgJAfIgIAaIgBAFIgDAHQAAAEgDAEIgCACIgDACIAAABIgEABIgBABIAAAAIAAgBIgCABIgEAAIgDgCIgBAAIgDAAIgGgBQgGgCgBgDIgBgDIgBgEIgBgCIgBgCIgHgMIgCgGQAAgBAAAAQAAgBAAgBQAAAAABgBQAAAAAAgBQgBgFABgEIADgKQABgHgBgDIgCgHIgCgFIgBgCIgCgJIABgCIgLgEIgMgCIgGgBQgJAAgCgCIgCgCIgCgEIgFAAIgCgBIgEgCIgEgDIgDgBIgBACIAAACIgCgEIgGgCIAAABIAGAyIAEAKQAAADAKAHQAJAIAFANIAAACIABACIABAHIADAIIADAFQAAACgDAEIgCACIAAAEIAAAHQgBACgFAAIgCAAgABeBJIADgFIgDgDgACCA1IAAgBIgBgBIgEAAIAFACgACpAsIABAAIAAgCIgBAAgABihJQgBgGAAgHIgDgBQABAHADAHgABwhvIABAAIgBgBIAAAAgACTCwIACgHIAAADIAAACIAAAAIgBACIgCAGIgEAFIAFgLgACYCoIgDgBIAAgBIAHAAIgBACIgDAAgAivgTQgFgBgDgGQgFgJgBgMQAAgIgBgCIAEgPIAHgKIAkgzQALgPARgjIAGgHQABAAAAgBQAAAAAAgBQAAAAAAAAQAAgBgBAAIACgBQALgHAIgCIADgCIAHgEQAKAAAFARIACARIgBAAQAAAJgFAIIABAEQgDALgJALIgIANQgJASgKAMIgKARIgGAIIgKANIgRAYIgBABIgNAIIgHABQgEAAgCgCgAiShEIAEgCIAAgBIgEADg");
	this.shape.setTransform(0,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAVDXIgTgDQgGgCgHgFIgEgEIgGgFQgKgIgIgKIgFgEQgNgbgJgiIgOgOQgBgCgFgDIgWgZIgCgCIgEgHIgEgEQgKgKgEgHIgHgMQgLgNgGgLIgBgDIgFgFIgEAAIgCABIgBAAQgLgCgIgLIgGgOQgGgVAKgXIAFgOIAEgJIAmg3QAHgKAEgHIAPgUQAEgIAFgCIAMgGIAXgIQABgBAFABIABACQAGAEAAAHIACAHIADAJQADAEgCAIIAAAHIAIAAIADACQAGADAEgEIAqAAIAUAAQAMgCAKACIAZACQAfAHANAIQAFADAKALQARAUASAeQAHANABAIQACAHgDANQAEAFgBADIABAJQALALAEAUIAAAJIABABIgCAEIgBACIAAADIADADIgBABIgFAMIgDANQgDAMgMAVQgCADAAAEIABACIgBACIgCABIgBAEIgDALIgDAGIAAABIgDAHIABABIgDAGIgGATQgDAIAAAGIAAABIADABIADABIgFAIIgBAAIAAgCIAAgBIABgCIgBgDIgCAHIgEAMIAAABIgBAAQAAAAgBAAQAAAAAAABQAAAAAAAAQAAABAAAAQgDAIgFAEIgCgBQgDACgDAAQgDABgHgBQgTgDgFgHIgFgKQgDgGgDgCIABgDIgCgBQgCgGAAgHIAAgKIACgLIABgMQgBgIgGgJIABgBIgCgBIgRgFIgUgOQgDgFgDgCQgDgBgCAAIgBAAIgFABIABABQgDACAAADIAAAHIgBAIQAAAHAGAIIABABQADAOAJANIALAPIABACIAIAOIAAABIABADQACAGAAAHIAAACQAAAIgFAFQgFAEgHACIgKABIgIgBgAAWDWQAAAAABAAQAAAAABAAQABAAAAAAQABAAAAAAIACAAIAGAAIADgDQAHABACgDIAAgHIACgEIAAgCQACgDAAgCIgDgFIgBgJIgCgGIgCgCIAAgDQgEgNgJgHQgKgIgBgDIgEgKIgGgxIABgBIAFACIACAEIABgCIABgCIACABIAEACIAFACIABABIAIAEIABADQACABAKAAIAFACIANACIALADIgCACIADAKIAAABIACAGIACAHQACADgCAGIgCAKQgBAFABAFQgBAAAAAAQAAABAAABQAAAAgBABQAAAAAAABIADAHIAHAMIABACIAAABIACAEIAAAEQABADAGACIAHABIAEABIADAAIADABIACAAIABAAIABgBIADgCIABAAIADgCIACgCQACgEAAgEIADgIIACgFIAIgaIAJgfIABgDIABgDIgBgMIgBgCIABgCIgCgLIgDgHIgFgJIgEgIIAAgBIgDgHIAAgCIACgDIgCgCQgHgEgHgCQgPgJgTgHQgNgDACgIQACgDAGAAQAFAFAMAGIApAYIAFACIADAMIAAgBIABAIIADADIAFAUIgEANIAFADIAAAAIgDgDIAHgMIADgDIAAgDQAQgeACgWQAAgFABgCIgBgDIAAgMIgBgEQgCgEgCgCIgEgBQgEgHgHgFIgFgCIgFgDQgFgEgGgDQAGAAAGgEQAGgBACgFQADgDgBgHQACgMgEgHIgDgFQgGgLgEgDIgCgBIgBgBIgBgBIgCACIgDgCIgJgDIgKgDIgDAAIgDgFIADAAIAJACQAGABACgBQADgCABgFQAAgGgCgEQgCgEgFgEQgKgMgKgGIgHgEQgCgBgGgBQgIgBgBADIgQgBIgOgBIgJAAIgMgBIgPAAIgZABQgLAAgEgCIgNgBIgDAAQgGgCgLAAQgGAAgCACQgBADABACIgDABIgCAIIgLAUIgBABIgBABIgJAOQgRAYgGALQgDADgCAFIgKAPIgMASIgPAOQACACgBAEIgDACQAGAGAFAJIAPAZIAOARQAMAJAEAGIAEAHIAAAEIAOAOIAPAVIABAJIABABQABAJAFAHIAGAMIACAEIABAGIAFAJIAJAIIADAFIgCAAIACADIAAABIACABQACADAIAEIARANIACAAIABAAIACACIAGAEIABABIAEAAIADAAIAAABgAhWjLIgCABQgIADgLAGIgCABQAAAAAAABQAAAAAAABQAAAAAAAAQAAABAAABIgHAHQgQAjgLAPIglAyIgGALIgEAPQABABAAAJQAAALAGAJQADAGAEACQAEACAJgCIAOgHIABgBIARgZIAKgNIAGgIIAKgRQAJgLAJgSIAJgNQAIgMADgLIAAgEQAEgIABgIIABAAIgDgSQgEgQgKgBIgIAFgACugfIADABIgCgEIgBADg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Chandholdingalgae, new cjs.Rectangle(-19.7,-21.5,39.5,43.1), null);


(lib.CHand = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF00").s().p("ABUFRQgDABgHAAIgCgBQgCABgDAAQgFAAgGgDIAAgDIgLgHQgHgIAAgBIgDgJIgFgIIAAgDIAAgDQgHgKAAgHQgCgIACgGIAEgPQADgJgDgGQAAgEgEgGIgEgLIgFgSQgCgIgKgGIgMgNIgQgLIgGgHQgNgGgCgEIAAgFIAAgFIgHgFQAAAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAAAIgEgHIgEgFIgCgEQgBAAAAAAQgBAAAAABQAAAAgBAAQAAABgBAAIgBADIAAgHIgGgIIgCACIgfBFQgEAKABAFQgBAEAHASQAHAQgEAUIgCADIAAAEQAAACgEAHIgDANIAAAJQgCADgGACQAAAAgBAAQAAAAgBABQgBAAAAAAQgBAAAAAAIgEAFIgFAJQgFACgJgGQgZgOgMgMIgDgFIgDgCIgQgdQgHgLAAgHIgCgBIABgBIACgEIAAgJIgGgSQgBgHABgHIADgKIABgDIAAgDIABgUQAAgNAEgMIABgCIAFgMIgFgnIgIgdQABgDAEgCIAAgMQgCgJgIgVIgHggIgBgrQAAgRgDgNIAGAAQAFgFgBgEQAQgBARgGIAegNIAagMQAHgFAHgCQARgLArgRIAYgLIABgCIACAAQAUgKANgIIAJgIIAEAAQAAgDAEgDQAEAAAJADIAXAQIADACIAQALQAFAGASAJIAiARIAWALQAGADALAHIALAHIAUALIAVAOQAFgDAIAHQAIAGADADIAHAKQAIAPAFAYQADAJgBAGQAAAHgFAIQgEAFgGAAQgFAAgHgFQgGgEgFgGIgDgBIgBAJQAAAAABAAQAAABABAAQABAAAAAAQABABAAAAIALAKQADAFAJAFIACAGIAFABIABABIABADQADAIAAAQIAAAJQAAANgMANQgFALgHABQgHAGgIgDQgNgBgHgEQAGAIADAKIAFAIQAAAEACADQACAFAAAFQAGADAAALIAAADQAAAEgDAHIgHAIIAAAEIgFADIgDAEIgDADIgRANQgEAEgGADIgEADIgEAAQgEgCgCgEIAAgDIgEAAIgBAAQgGgDgKgOIgog+QgKgQgEgKQgJgFgFAEQgIAHAPAPQAVAXAOAWQgDADAAADIAJAJQALAVAEAQIAAAIIAFAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABIgBAEIgCAEQgJAUgLAoIgUA6QAAAGgFAGIgGAEQgDAEgFABIgCABgAA/E6IgDgFIgCgBQACAEADACgAC9CDIADAAQACgBAAgDIAAgEIgFAIgACkgaQAEgKAFgJIgCgDQgFAJgCANgADWhCIADAAIgCgBIgBAAgACBEtIABAFIgBADIAAACIgEAKQgEADgCAFIAKgcgAj0iXQgNgEgEgHQgFgFAAgKQAAgQAIgPQAHgKAAgDQAJgKAJgHIARgJIBcgmQAcgLAzggIAOgGQABAAABgBQAAAAAAgBQABAAAAgBQAAAAAAAAIAEAAQAVAAAMACIAEAAQAIgBAGABQAOAIgHAZQgEALgHANIgCgBQgHALgMAHIgCAFQgNAMgWAJIgWAKQgbARgWAHIgcAPIgPAGIgYAKIgsATIgCAAIgNAAIgMAAgAi1jLIAHAAIABgCIABAAIgJACg");
	this.shape.setTransform(0.3,-0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ABOFhQgWgEgRgRIgJgKQgOgTgCgVIAAgOIAFgRIAAgSQAAgVgigfIgUgTIgRgiQABgHgDgFQgDgEgEgCIAAAAIgIgDIAAACQgFABgDADIgGAKIgHAKQgGAIACAOIABADQgHAUABAYIADAcIABADIAAAXIgBADIgBAEQgCAJgFAJIgCADQgHAJgMAEQgJACgNgEQgLgEgMgIIgagTQgHgHgFgNIgEgIIgDgLQgHgRgEgTIgEgJQAEgtAOgzIgIgcQAAgEgEgHIgLgvIAAgEIAAgMQAAgEgDgFQgGgVAAgMIAAgUQgGgZACgSIAAgFIgCgMIgFgCIgEgCIgBgBQgOgJgCgUQAAgMACgLQAJggAhgWQAFgGAOgIIAMgJIBigrQARgHAKgHIAmgPQANgGAJAAIAUACIAlAHQAEAAAFADIAAAEQAFAKgFAJIgDAKIgCAPQAAAGgJAKIgGAJIAKAGQAAABADADQAHAJAJgBIA7AfIAcAOQATAHAMAKIAhAVQAnAgAKAUQAFAJAGAVQAHAnAAAzQAAAWgEAKQgEALgOAOQAAAKgDAEIgGALQAHAYgMAdQgNAVgaATIgGACQgTAAgMAPIgMAXQAAAHgHAQIgKAcQgGAPACAKIgLAcIAAACIgBABQAAAAgBAAQAAAAAAAAQAAABgBAAQAAAAAAABQgIASgNAEQgFABgGAAIgIAAgABNFOQAGABAEgBIACgCQAEAAAEgEIAGgEQAEgHAAgFIAUg6QAMgoAIgUIACgEIACgEIAAgFIgEgMIgMgcQgGgKgIgJQgOgVgVgXQgPgPAJgHQAFgEAIAFQAEAJALARIAnA+QALAOAGADIABAAQACAGAAAFIABAFQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQADgCAGgCIADgDQAHgDAEgFIACAAIAPgMIACgDIAEgEIAEgDIAHgNQAEgGAAgEQACgOgHgOIgGgHIgEgHQgEgKgFgJQAHAFAMABQAJACAGgFQAHgBAFgLQANgOAAgMIAAgJQAAgQgEgIIgBgDIAAgBQgBgBAAAAQAAAAAAgBQgBAAAAAAQAAgBAAAAIgEABIgCgFQgIgFgDgFIgLgLQgBAAAAAAQgBAAgBAAQAAgBgBAAQAAAAgBgBIABgIIAEABQAFAGAGAEQAHAFAEAAQAGAAAFgGQAFgHAAgHQABgHgEgIQgFgYgIgPIgHgKQgCgEgIgFQgJgHgEACIgVgNIgUgLIgMgHQgKgHgHgDIgVgLIgjgSQgRgIgFgGIgQgLIgEgDIgWgPQgJgEgFABQgEADAAADIgEAAIgKAIQgMAIgTAKIgCAAIgCACIgXALQgsARgRALQgGACgHAFIgaAMIgeANQgSAFgPACQAAAEgFAFIgFAAQADANAAARIAAArIAHAgQAIAUACAKIAAAMQgDACgBADIAIAdIAFAmIgGANIAAACQgFAMAAAMIgBAVIgBAGIgCAJQgBAIABAHIAGASIgBAJIgDgCIACAFIgBACIACABQAAAGAHAMIAPAdIADACIADAGIAFAKIAAABIAGADIADACIAAABQACADAEABIADABIAJAEIAGgBQAJAGAEgCIAGgJIAGgEIACgDQAGgCABgCIAAgJIAGgMQACgIgBgDIAAgDIACgDQAEgUgHgQQgHgSACgEQgBgGADgKIAghEIACgCIAFAIIAAAGIACgCQAAgBABAAQAAgBAAAAQABAAAAAAQABAAAAAAIADADIADAGIAFAGQAAABAAAAQAAAAAAABQAAAAABAAQAAAAABABIAHAKIAAAFQABADAOAHIAGAGIAPAMIANANQAJAGADAHIAFATIAEALQAEAGAAAEQACAFgCAJIgEAPQgCAHACAIQAAAHAGAKIABADIAAACIAEAJIADAJQAAABAHAHIAMAIIAAACQAFAEAFAAQAEAAACgCIACACgADyBNIACADIABgHQgBAAgBABQAAAAAAABQgBAAAAABQAAAAAAABgAgclSIgPAFQgzAhgbALIhcAmIgSAJQgJAGgIALQAAACgHALQgIAPAAAQQAAAKAEAFQAEAHAOADIAZAAIACAAIAsgSIAXgKIAQgGIAcgPQAWgHAbgRIAWgKQAVgJAMgMIAEgFQAMgHAHgLIACABQAGgNAEgMQAHgYgNgIQgGgBgJABIgEAAQgMgDgVAAIgDAAQAAABgBAAQAAABAAAAQgBABAAAAQgBABAAAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.CHand, new cjs.Rectangle(-27.6,-35.3,55.4,70.7), null);


(lib.WaterAddition = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(153,255,255,0.498)").s().p("AuwAxIH5j6IAsAAIgSBfIoXE0gAmFixIAAgYIU6AAIAAAYg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.WaterAddition, new cjs.Rectangle(-94.9,-20.1,189.9,40.3), null);


(lib.squaretintedfishtanklid = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0.6)").ss(1,1,1).p("AmmjIIW5AAIn+GRI4nAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(0,0,0,0.8)").s().p("AwSDJIJsmRIW5AAIn/GRg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.squaretintedfishtanklid, new cjs.Rectangle(-105.2,-21.1,210.5,42.3), null);


(lib.squarefishtank = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AHfovIH2lUIAAVVAHfHSIAAGyI2zgSIJEmmINvAGIH2AAIn2GyAHfovIAAQBAmQuDIAAFUIAAP7AvUovIJEAAINvAAAvUovIJElUIVlAAAvUNyIAA2h");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#000000","#888888","#B0B0B0","rgba(222,222,222,0.149)","rgba(233,233,233,0.298)","#FFFFFF"],[0,0,0,0,0.89,1],-73,0,73,0).s().p("ArZLHIJEmlIAAv7INvAAIAAQBItvgGINvAGIAAGygArZrZIJEAAIAAP7IpEGlgAiVEig");
	this.shape_1.setTransform(-25,17);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#000000","#888888","#B0B0B0","rgba(222,222,222,0.149)","rgba(233,233,233,0.298)","#FFFFFF"],[0,0,0,0,0.89,1],-25.1,-8.5,37.9,-8.5).s().p("Aj6HSIAAwBIH1lUIAAVVIn1AAIH1AAIn1Gyg");
	this.shape_2.setTransform(73,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.squarefishtank, new cjs.Rectangle(-99,-91,198.1,182), null);


(lib.OldWater = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(153,255,255,0.498)").s().p("AgODfQgCkDABieIADm+IAMAAQgCCFAAEFIAANiIgIAVIgEmigAAJJpIAAgKIgBAAIgBgUIAAsuQAAkQACiNIAEAAIAAAHIADAAIgFKNQgCC/AAGXIAAgBg");
	this.shape.setTransform(48.4,4.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(153,255,255,0.498)").s().p("AAYDRIgXAAIgQAAIgZgBIgBAAQgHgHgBgQIgBgfIABiDQAAgRAEgGIAFgFIAEgGIACgOQAAgGADgIIAEgNQADgMAAgYIgBh4IBDABQgCAzADAaIAEAUQABBlADBnIgBAIIgCAVQgDAhACA1g");
	this.shape_1.setTransform(41.9,48.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(153,255,255,0.498)").s().p("AABH4QgPACgKgDIgChHIgDhYQgCg3ABhlIABgJQAAgUAAghIAIp2IA3ABQANCPACBLQADB4gNBgIgIAyIgGAxQgEAlABA8IABCZQAAAVAFAKIAKAPQAGAKAAAYIgBCRQgKgDggACgAgwHDIAAgOIAAgBIABAiIgBgTg");
	this.shape_2.setTransform(-94.2,13.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(153,255,255,0.498)").s().p("AgwHQQAEhngLkwQgKj9ATiYIAGg0QADgfgBgWQALAAAlgGIAjgFQgBB+AADXIgKBmQgBANgKgUQgJgTABALQAND9gJD5gAA3nRIAEAAQADCPgIBrIABj6g");
	this.shape_3.setTransform(43.7,-9.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(153,255,255,0.498)").s().p("AgLFQQgDgBgBgDQgIgMgBgRIAAgBIAAgTIABgPQAKhygBhyQAAgUADgKQAGgPACgIQABgHgFgWQgCgPAAggIAAhKIgKAjIgBACIACicIAKAwQAGgHACgLIABgUQACghALgfQAIAFgFAUQgEARAEAYIAGAqQADAXgBAmIAAAyQAAAFgCADQgCAEgEAAQgDgBgDgGIgLgcQAAAdABAvIADBLQABAggEBWIgBAaIgDA0IgJA/QgEAkAJAZIABAEQAAAAgBABQAAAAAAAAQAAABgBAAQAAAAgBAAIgCgBgAgOjCIACgBQgBgEACgEIABgCIgBgDQgBgCAAgEIgBgCQAAgBAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAgAAKjZIABAHQABAFACACIABgPIgBgMIgDgNIgBAAg");
	this.shape_4.setTransform(-94.8,12.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(153,255,255,0.498)").s().p("AgaFeIABgJIAAgZQAPg7ABgjQAAgRgEgvQgFg0ABhCQABgoAFhOIgJgDIADjvQACgDAEABIAAgoIALgJIAEB6QABAfAFAPIAHAVIAIAWQADAPgCAkIgMCdQAEgCADAFQACAEgBAFIgaEtQAAAKgGAAIgDg5IgNA6IAAgWgAADgLQAFgJAAgVIAAhkQAAgbgFgMIAACpg");
	this.shape_5.setTransform(-94.6,-2.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(153,255,255,0.498)").s().p("ADoAjImqgGQg4gBglADQgnACgKAAQgcgBgTgIIgNgIIAUgLQASgJALgJIAngHQAdgGARgCQAZgDAnABQEpACEqgGQgEAMgIAKQgXAfgvAKQgZAGgsAAIgOAAg");
	this.shape_6.setTransform(-8.9,-61.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(153,255,255,0.498)").s().p("AMxGHQgkgyhPiOQhQiQglgzQg8hTgkAJIACjHQgEAAABgbQACgagDACIAAhbQA3gCBXgQIFaABIgCBoQAAAbABANIABAJIgFBTQgYgKgNgWQgOgXADFqQAEFrgOgXQgHADgHAAQggAAgxhDgAu/h7IgNgHIAAgBQAAgHgCgEQAegYAQgLQAbgRAzgSIA7gVQAqgCAogGQAjgGARgHQARgGATgNIAhgYQA2goA8giQASgKALgIIAngIQAdgGARgCQAZgDAnABQGAAEGAgMQgCAFAAAGIgCBmIgHAKIgMANQgJAKgHAYIgGAWIglAMQg6ARhMALQgtAGhcAHQhwAKg/AEQhhAGhPgBQi6gHhcgBQijgChwAbQgmALgTAEQghAHgaAAIgCAAQgfAAgZgLgAL1nHIALgCIADACIgGAAIgIAAg");
	this.shape_7.setTransform(0.9,-23.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(153,255,255,0.498)").s().p("AGxKpIgXAAIgRAAIzKgJIiPgEIAAgZIgChYIgDhLQAFhJAJhXQAcj/AAhoQABhZgLhuQgGg1gNhtQAZgUAOgJQAbgSAzgRIA7gWIAZgCIgnAQQgnAPgjAEQCVgMD7ATQEqAYBygDQBOgCCJgMQCZgOA+gDQAngCAXgGQgEATACARQACAOAFAUIAKAhQAIAZAMAIIAFACIgIItQgBDYAIDkIAFAAIgCACIgPAFgAHkKSQAEgKgBgMIgGhRIAAmRIACiXIABlFQAEgCgFgNIgCgKIAAgHQAGgGABgEQAEgPgCgOIgBgdQgBgMgGgdIgBgDIAAguQAKgDgBgGIgEg0QARgMAxAiQASANBSBFQCTB6A0gbQADgBAPhBQAQhBADgCQAVgBAKgcQAFgRAGgtQAIhAATgTIAPAAIAABoQAAAbABANIABAKIgGBSQAAAuACBDIADBHIADBYQABBnACBSIADBsIgECOIgTANQggAXg8AxIl/E5IAAgCgAHwlEIgDABIAOgDIAAAAIgLACgAlJp6IgngHQgYgFgPAAQgUABgaAIIAHgFIAmgIIAlgGIAsACQAnABAwgGIBKAAIgVAFIhHARQgcAFgXAAIgUgCg");
	this.shape_8.setTransform(1,1.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.OldWater, new cjs.Rectangle(-99.1,-69.6,198.4,139.3), null);


(lib.CFishtankheater = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(96,96,96,0.6)").s().p("AACAJIAAgBIAAgBIgCABIgCAAIAAAAIgBAAIAAgBIAAgOIAAgBIABAAIAAAAIABAAIAAACIAAAAIAAALIADAAIACABIAAACIgBAAIAAABIgBAAg");
	this.shape.setTransform(-10.5,32.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,0,0,0.6)").s().p("ABUCrIgBgBIAAgBIADgTIABgKIABgBIAAgBIAAgDQACgLgBgLIgCgWIAAgTQAAgIgDgLQgDgLADgLQADgJgBgIIABgBIAAAAIABAAIABABQABAHgDALQgDAKACALQADALAAAIIABATIABAWQACALgCALIgBAEIAAABIAAABIgBAJQAAAFgEAPIAAABIgBAAIAAAAgAhWCdIAAgBQgDgGgCgGIAAgCIAAgBIgBgIQABgNAEgIIABgCQADgGgCgIIgBgLIgBgHIAAgBIgBgTIAAgUQABgLgCgLIAAAAQgBgLACgJIACgJIACgKQABgIgDgJIgBgDIAAgBIABgBIAAAAIABAAIAAABQAFALgCAKIgDAUIgBADQgBAIABAIIAAACQABAKAAAKIAAAUIABATIACATQABAJgEAIIgBACQgDAIAAAKIAAAHIAAABIABACIACAJIACADIAAABIAAAAIgBAAIgBABIAAAAgABYAMIgBgBIgBAAIAAgUIAAgVIAAgTQAAgJgCgJQgBgIACgNQADgMABgLIAAAAQACgKgCgHIgDgSQgDgMADgLIABAAIABgBIABABIAAABQgDAKACALIAEASQABAHgBALQgBALgDANQgDAMACAIQACAIAAAKIAAATIAAAVIAAAUIAAAAIgBABIAAAAgAhWguIgBgBIAAgBIAAgUIAAgTIABgSIAAgCQACgIgCgIIgBgDQgDgKABgLIAAAAIADgPIAAgCIAAgCIAAgBIgBAAIAAgBIABgBIABABQAAAAAAAAQABAAAAABQAAAAAAABQABAAAAABIgBADIgCANIAAACIAAAAIAAAMIACAIQADAKgCAKIgCAUIAAATIAAAUIAAABIgBABIAAAAgAgZhsQgDAAgDgCQgCgCAAgEQAAgEACgCQADgCADAAQAEAAACACQACACAAAEQAAAEgCACQgCACgEAAIAAAAgAgdh4QAAAAgBABQAAAAAAABQAAAAgBABQAAAAAAABQAAABAAAAQABABAAAAQAAABAAAAQABABAAAAQABAAAAABQAAAAABAAQAAABABAAQABAAAAAAQABAAAAAAQABAAAAgBQABAAAAAAQABgBAAAAQABAAAAgBQAAAAAAgBQABAAAAgBQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAAAgBgBQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAAAgBAAQgBAAAAABQgBAAAAAAQAAABgBAAg");
	this.shape_1.setTransform(0.3,15.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(0,0,0,0.6)").s().p("AAPGgIgFAAIgJAAIgBAAIAAgBIAAgBIABAAIADAAIAGAAIAFAAIABAAIAAABIAAABIgBAAIAAAAgAgCGgIgHAAQgiAAgXgXQgYgYAAgiIAAguQgPgIgEgKQgBgDAAgFQAAgDABgEIAAAPIAAABIABAAIABAAIABAAQAEAIANAHIAAAAIABAAIAAABIANAFIAAABIABAAIAAAAIAQAFQAXAGAdABIAAAAIACAAIAIAAQAiAAAbgGIATgHIAFgCIAAAAQAcgMAAgQQAAgOgYgMIAAgBIAAgBQAaAMAAAQQAAASgcANIAAApQAAAigXAYQgVAUgcADIgBgBIgBAAIAAgBIAAAAIACgBIAAAAIALgCQANgDALgIIAMgKQAXgXAAggIAAgoIgEABIgFABIgBABIgOAEQgLADgNABIgBABQgRACgTAAIgHAAIgBAAIgCAAIgBAAIgPgBIgDgBIgOgBIgDgBIgBAAIgPgEIgBAAIgDgBIgNgEIgBAAIgBgBIgLgFIAAAtQAAAgAXAXQARARAVAFIAJABIAJABIAHAAIABAAIAAABIAAABIgBAAIAAAAgABBEEIAAAAIgBAAIAAgBIAAgEIAAgBIABAAIABAAIAAABIAAAEIAAABIgBAAIAAAAgAhqEBIAAgCIgBAAIgBAAIgBAAQAFgKAQgIIAAABIAAACQgOAIgEAJgAhWDtIAAgBIACgBIABAAIAAAAIABAAIAAABIgBABIAAAAIgCACIgBgCgABaDsIAAAAIgGgCIgDgBIgBAAIAAgBIAAgBIAAAAIABgBIABAAIADABIAAAAIAGADIAAABIgBABgAgpiEQgZgCgUgEIAAAAIgCAAIgBAAQgigIAAgKQAAgLAigIIABAAIAAAAIABABIAAABIgBAAIAAAAQggAHAAAKQAAAIAfAHIABAAIADABQATAEAZACQATABAWAAIAigBQAZgBAVgEIADAAIADgBQAjgHAAgJQAAgKgjgHIAAAAIAAgBIgBAAIAAgBIABgBIABAAQAlAIAAAMQAAALglAHIgDABIgBAAIgCABIAAAAIgCAAQgVADgYACIgiABQgWAAgTgCgAhZjIIgBAAIAAgBIAAiFQAAgiAYgYQAXgXAiAAIADAAIABAAIAAABIAAABIgBAAIgDAAQggAAgYAYQgXAXAAAgIAACFIAAABIAAAAIgBAAIAAAAgAA5mNQgPgLgRgDIAAAAIgBgBIAAgBIABgBIABAAQASADAOAMIABABIAAAAIAAABIgBAAIAAAAIgBAAg");
	this.shape_2.setTransform(0,5.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,0,0,0.2)").s().p("AgDAEQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQgBgBAAAAg");
	this.shape_3.setTransform(-2.3,3.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,0,0,0.498)").s().p("AA5CQIABgPIAAgBIAAglIgBieIABhaIAAgDIAGgDIADgCIAHgBIAIgDIAAAAIAAACIAAE0IAAACIAAAAIgBABIABABIAAABIAAAAQAAALgDAJIgLACIgBgBIgBAAIgBAAIAAABIgGABIgEABIACgagAhLCnIgFgCIAAAAIAAgBIgBgDIAAgHIAAgEIAAAAIABgBIAAgBIgBAAIAAAAIAAgYIABgCQAEgIgCgKIgCgSIgBgTIAAgUQABgKgBgLIAAgRIAAgFIAEgSQABgKgEgMIgBgBIAAAAIAAgBIABAAIAAgBIAAgUIAAgUIABgTQACgKgDgKIgBgIIAAgOIACgNIAAgEIADADIAGACIAEACIgCAYIgEB7IAAAbIAABJIABArIACAcIAAAAIAAABIgGgCgAhRBeIABALQABAHgCAHgAhRgfQACAJgBAIIgBAKgAhRhyQABAHgBAIIAAACg");
	this.shape_4.setTransform(-0.1,14.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#FFFFFF","#000000"],[0,1],367.9,260.7,367.9,260.7).s().p("AAOA8IAAgBIgBAAIgFAAIgGAAIABgBIAFAAIABAAQABAAABAAQAAABABAAQAAAAABgBQABAAAAAAIABAAIABAAIABAAIgBAAIgBABIAAAAIAAABgAgdA5IgFgCIgDgCQgCAAgFgEIgDgDQgEgCgBgDQgFgDAAgFQgEgDgCgGIAFAHQADAEAMALIAJAHQAFADAJACIgJgBgAAlAzIATgTQAFgHAEgKQAGgNADgMIACgJIAAgHQAEgNAAgIQAAgFgCgBIgBgDIABgBIADABQABAKgBALIgCAUIgDAPIgBAAIgCAGIgBABIgDAJIgEAKQgEAJgJAKQgLAIgNADIAJgFgAgcArIACABIACACIgEgDgAgRAnQgJgLgDgFIgHgSIgDgVQgCgOAAgIIABgBIAAAFIABAMIABAAQAAAGABAIIADAOIABABIABAHIACABQgCADAEADIABADIABABIAEAGQADACACADQABAAAAABQABAAAAAAQAAABABAAQAAAAAAABIABAAIABACIACACIgHgEgAgDAiIADAFIABABIgBABgAgEgEIAAgEIgBgCIAAgEIgCgPQgCgIAAgIIABAAIABAAIACAAIAAABQAAAAgBAAQAAABgBAAQAAAAgBABQAAAAAAABQgBACABADIALA9QAAAFgCAEIAAACgAg5APIgDgEIgBgEIgEgoQgBgOACgHIADABIAAAAIADAkQAAAJABAHQABAKACAEIABAEIAEAIIgIgKgAAVAUIABgDQACgFAAgFIAAgBIANg1IACgBIABABIgBAAIgCAFIgHAqQgCAGgFALIgCAFgAgWAIIgEgVIgCgiIADABIABABIgBACIgCAEIAAAKIACASIAFAagAAKAIIABgjIAAgEIABgEIABAVIgBAIIgBAFIAAAMgAg9AKIgEgKIgDgNIAIAXgAA2gqIAAAAIgBAKIAAABgAhKgqIABABIAAAFgAAMgtIACAAIgBADIgBgDgAA3gvQAAAAAAgBQAAAAAAgBQAAAAABAAQAAAAAAAAIADgBIgCACIgCADgAgsgxIACABIAAABIgCgCgAhPg5IgBABIAAgDIAAAAIABABIACAAIAAACIgCgBg");
	this.shape_5.setTransform(0.2,41.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.2)").s().p("AABASIAAgBIgBgBIgBgCIgBgCIgCgCIAAAAIgCgbIADAAIAAALIABABQAAADACAEIACACIAEAFQABADgBAGg");
	this.shape_6.setTransform(-6.7,30.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#FFFFFF","#7B7B7B","#313131","#000000"],[0,0,0.137,1],-11.4,-0.6,11.3,-0.6).s().p("AgJAlIgCAAIAAAAQgdgBgXgHIgPgFIgBAAIAAAAIgBAAIgMgGIgBAAIgBAAIAAAAQgMgIgEgIIACgBIABABIAAABIABAAIABgBIAAgCIgCAAIgEAAIAAgMQAEgJAPgIQABAHADAFIAAABIABAAIABgBIAFACIAGADIAAgBIAAABIACABIAAACIACACIAAABQAJAHAVACQAIADAOAAIAuAAQAWABAHgJIAEgGIAAAAIABgBIAAgBIAAgDIALgCQAEgJAAgMIADABIAGACIAAABIABAAIgBAKIgEATIAAABIABAAIABAAIABgBQADgPAAgEIABgJQAYALAAAPQAAAPgbAMIgBAAIgFACIgTAGQgbAHghAAIgJAAgAhageIACgBIAAADIAAAIIgCgKg");
	this.shape_7.setTransform(0.5,32.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#FFFFFF","#000000"],[0,1],-7,2.5,7,2.5).s().p("AAlCtIguAAQgOAAgIgCQgVgCgJgIIAAgCIACACIAAABIAFAAQAAgHgBgDIgEgEIgBgDQgDgFAAgDIgCAAIABgLIgDgBIgCgrIAAhJIABgbIAEh7IACgYIgEgCIACABIAKACIAPAGQASAFAbgGIA4gNIgBBaIABCeIAAAlIgiABIAHABIAbgBIgBAPIgDAaIAFgBIAGgBIAAAEIAAABIABAAIgEAGQgGAJgTAAIgEAAgAgLh0QADgDAAgDQAAgEgDgCQgCgCgEAAQgDAAgDACQgCACAAAEQAAADACADQADACADAAQAEAAACgCgAhBCaIAAgBIACADIgCgCg");
	this.shape_8.setTransform(-0.5,16.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#FFFFFF","#7B7B7B","#313131","#000000"],[0,0,0.137,1],-12.2,-0.3,12.3,-0.3).s().p("AgpATQgZgCgTgEIgDgBIgBAAQgfgHAAgHQAAgKAggHIAAACQAQAKAlABQBFADAigFQAMgCAGgEIAAgFIAAAAQAjAHAAAKQAAAIgjAHIgDABIgDAAQgVAEgZABIgiABQgWAAgTgBg");
	this.shape_9.setTransform(0,-9.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAAGeIgBgBIgBAAIgHAAIgIAAQgKgDgEgDIgKgHQgMgLgDgEIgEgGQACAFAEADQAAAFAFADQABAEAEABIADAEQAEADADAAIACACIAGACQgWgEgQgRQgXgXAAghIAAgsIAKAEIgBAAIAAADIABAAIADAAIAAgBIAMAEQgBAHABANIAEApIAAAEIAEAFIAHAJIgDgHIgCgFQgBgEgBgKQgCgIAAgJIgCgjIAPADIACAAIACACIAAgBIAOACIABAhIAEAXIACAHIgEgbIgCgSIAAgKIABgFIABgBIAAgCIAQABQgBAIACAIIACAPIAAAEIABACIAAAEIAGAqIAAgCQABgFAAgFIgLg9QgBgEABgCQABAAAAgBQAAAAABgBQAAAAABAAQAAgBABAAIgBgBIAHAAQATAAARgCIgNA3IgBAAQAAAGgBAFIgBACIgBADIADgGQAFgKABgIIAIgqIACgEIABgBIgCAAQANgCAMgCIAOgFIAAADQACACAAAFQAAAHgDANIgBAHIgBAKQgEAMgFAOQgEAJgGAHIgTATIgJAGIgKACIgBgBIgCAAIAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAQAAAAgBgBIgCAAIgEAAIgCABIgDAAIgBAAIAAABIAAAAIAAAAgAgWGQIgBgBIgDgBIAEACgAgIGNIgCgCIgBgCIgBAAQAAAAAAgBQAAAAAAAAQgBgBAAAAQgBAAAAgBQgCgDgDgBIgEgHIgBgBIgCgDQgDgDABgCIgBgBIgCgHIgBgBIgCgQQgCgHABgHIgCAAIgBgMIAAgEIAAABQgBAHACAOIAEAXIAHARQACAFAKALIAGAEgAADGMIAAgCIgBgBIgDgFgAAOFCIgBAFIAAAkIAAACIABgNIABgFIAAgIIAAgVgAg+FiIAEAKIAAABIgHgZgAA3FDIABgCIABgKIgBAAgAhGE9IgBgFIAAAAgAAPE3IABgCIgBAAIAAACgAA7EwQAAAAgBAAQAAAAAAABQAAAAgBAAQAAABAAAAIABACIABgDIACgCIAAAAIgCABgABDF9IAFgLIADgIIABgBIABgHIABAAIADgQIACgUQABgKgBgLIgDAAIAFgCIAEgBIAAAoQAAAhgXAXIgLAJQAIgJAEgJgAAXDXIAiAAIAAAAIgbABIgHgBgAgsg5IgPgFIgKgDIgCAAIgGgDIgDgCIgCgZIgDgrIgBAAIAAAAIABAAQATAEAZACQATABAWAAIAigBQAZgBAUgEIAAABIAAABQgBAYABAMIACARIgIACIgHACIgDACIgGADIAAACIg4ANQgOAEgMAAQgLAAgIgDgAgjigQglgBgQgLIAAgBIAAAAIABgBIAAgBIAAgBIgBAAIAAgZIABAAIABAAIgBAAIAAiGQAAggAXgXQAXgXAgAAIADAAIABALIAcABQAAgDACgIIABAAQARADAOALIABABQABAJgBALIARAAIACAJIABADIAAACQgBAPAEAdIAAAeIgBBoIABAGQABAEADAAIABAAIAAABIAAAAIAAAFQgGAFgLABQgXAEgnAAIgqgBg");
	this.shape_10.setTransform(0,6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#FFFFFF","#7B7B7B","#313131","#000000"],[0,0,0.137,1],-4.3,-0.4,5.2,-0.4).s().p("AAWBNQABgLgBgJIAAAAIABgBIAJAMIAGAKgAgqA0IAAgLIABAAIAAgBIAAgBIgBAAIABgRIABgOIABg6IAAgOIABgEQAFgJAOAAQAHAAAMADIAAABQANAGAIAMIAFAJIABAFIADATIABAEIAAAFIABAoIgKgFQABgVgJgTIgCgEIgEgHQgGgHAAgEIgHgHIgCAAQABACgDAGIgBAIIABA+IgBAJIgBAAIAAABIAAABIABABQgDAIABACgAAqAzIABAAIAAABIgBgBg");
	this.shape_11.setTransform(3.6,-39.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.CFishtankheater, new cjs.Rectangle(-13.2,-47.4,26.5,95.8), null);


(lib.squareco2machine = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,0,0,0.8)").s().p("AAWAxQgJgCgKgEQgRgGgHgGQgGgGgFgJIgJgQIgTgkIgDgGQAAgEADgCQADgCADADQADADABAEIAJAQIAFAJIACAGIAFAIIAEAHQAHAQAKAFIALAEIAOAGQAIADAMAAIAUAAQAGABAAADQABAEgEABIgFABg");
	this.shape.setTransform(10.3,50.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(0,0,0,0.8)").s().p("AgTAEQAAgEAFgBIAJgBIAJgCIAKgDIAEABQADACgCADQgCACgDACQgFADgHABIgOABQgGAAgBgEg");
	this.shape_1.setTransform(2.6,46.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,0,255,0.8)").s().p("AASAtQgDgBgCgCQgHgFgHgVIgLgZQgJgSgBgGQAAgGABgBQACgEADABQADABABAJQABAFAIAMQADAHADAIIAHARQADALAGAGQAGAHgCADQgBAAAAABQAAAAgBAAQAAAAgBABQAAAAgBAAIgBAAg");
	this.shape_2.setTransform(6.2,50.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,0,255,0.8)").s().p("AgLAHIgFAAQAAAAgBgBQAAAAgBAAQAAgBAAAAQgBgBAAAAQAAgEAEgBIAFgBIAOAAIADgBIAEgCIABgBQAGAAACAEQAAACgEADQgCADgDABIgFAAg");
	this.shape_3.setTransform(2.6,46.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,0,255,0.8)").s().p("AgEAcQAEgJgCgNIgCgKQgEgOACgIQAAgDADgCQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAABIAAAJIADAKQADAHAAATIgCAIQgBAEgEABIgBAAQgDAAgBgEg");
	this.shape_4.setTransform(2.6,50.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,0,255,0.8)").s().p("AAHAHIgLAAIgDgBQgDAAgCgDQgDgDACgDQABgEAEABIAFADIAEABIAHABQABAAABAAQABAAAAAAQABAAAAAAQABABAAAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABAAAAQAAABAAABQAAAAgBABQAAAAAAAAQgBABAAAAIgEABIgCAAg");
	this.shape_5.setTransform(2.6,47.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,0,255,0.8)").s().p("AAAALQgCgBgCgEQgDgFAAgGIABgDQACgDADAAQACAAABADIABAHQAAABADAEQADAEgDADIgDABIgDgBg");
	this.shape_6.setTransform(2.4,47.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,0,255,0.8)").s().p("AgOALQgCgDACgDQADgFADgBIAGgCIAEgEQADgDADAAIABgBQAFAAACAEQAAACgDADIgHAFIgIAEIgGAEIgDABIgDgBg");
	this.shape_7.setTransform(12.3,56.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,0,255,0.8)").s().p("AAiAJIgzgEQgNgBgFgDQgHgEADgEQACgCAFABQAcAHAhAAQAGAAADABQACABABADQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAIgDABIgCAAg");
	this.shape_8.setTransform(11.5,55.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,0,255,0.8)").s().p("AAWApQgMgHgJgTIgLgdQgFgMgGgEQgJgDgEgEQABgDAEgCQADgBAEABQAMACAIARQAEAKAIAUQAIATANAHIAEAEQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAQAAAAgBABQAAAAgBAAQAAABgBAAIgBAAQgEAAgDgDg");
	this.shape_9.setTransform(5.1,50.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,0,255,0.8)").s().p("AgLAvQgEgDAFgIQAOgWAAgOIgCgPQgCgMgHgQQgBAAAAgBQABAAAAgBQAAAAAAAAQABgBABAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQACACADAFQALAVgBAWQgCAYgNAQQgEAFgDAAIgDgBg");
	this.shape_10.setTransform(2.7,51.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,0,255,0.8)").s().p("AAFAUIgEgHIgIgNIgFgFIgDgHIgBgGQABgDACgBQAEgBACAEQABABABAEQACAFAFAHQAHAGACAEIADAFIADAFQAAAFgFABQgEAAgDgEg");
	this.shape_11.setTransform(5.9,52.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,0,255,0.8)").s().p("AAHAUIgEgEQgDgNgEgEIgGgHIgDgGQAAAAgBgBQAAAAAAAAQAAgBAAAAQABAAAAgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQAAgBAAAAQADAAADACIAGAKIADAFIAHAOIACAEQAAAEgCABIgDABIgDgBg");
	this.shape_12.setTransform(3.6,49);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,0,255,0.8)").s().p("AAAAGIgDgCIgCgBIAAgCIgBgBIAAgDIADgDQACgBAEADQADADAAABQADAFgFABIgBABIgDgBg");
	this.shape_13.setTransform(2.6,47.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,0,255,0.8)").s().p("AABARQgCgCgBgDIgEgKIgBgDIgBgKIACgFQAAAAABAAQAAgBABAAQAAAAAAAAQABAAABAAQAAAAABAAQAAAAAAAAQABAAAAABQAAAAAAAAIACAHQAAAIAEAGIADAGQABADgDADIgDABIgDgBg");
	this.shape_14.setTransform(-7.3,62.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(0,0,0,0.8)").s().p("AgyAYQgFgBgBgDQADgEALgCQAtgHAogYQgBgGAHgBQAFgBADAGQgOASgLADIgOAGIgKAGIgJADIgYAGIgOACIgLgBg");
	this.shape_15.setTransform(7.5,59.1,1.583,1.583);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(0,0,0,0.8)").s().p("AAWA7QgCgIAAgPQABgRgBgHQgFgPAAgJIABgKQAAgFgCgEQgDgEgLgEQgHgCgUgLQgJgFACgFQADgHALAIQAQAKAOAFQALAFACADQADAFAAAHIgBANIADANIADAMIgBAWQgBAOAFAHIABADIgBABQgGADgDAEIgDgHg");
	this.shape_16.setTransform(-3.1,69,1.583,1.583);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(0,0,0,0.8)").s().p("AgWBBQgFgBgCgCQgCgDAAgGIABgkQAAgYgBgHIgEgVQgCgNACgJQAAgDACgCQABgBAAAAQABAAAAgBQABAAAAAAQABAAAAABQAGAZACAZIAABBQAdgFAdAKQgGADgDAEIgDAAQgMgDgGAAIgOACIgMACIgDAAg");
	this.shape_17.setTransform(-3.7,69.4,1.583,1.583);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(0,0,0,0.8)").s().p("AguBNQgEgCgBgDQAageAlgUIAPgKQAJgGADgGQAFgIAAgVIgCglQAAAAAAABQgBAAAAAAQgBABgBAAQAAAAgBAAQgBAAgBAAQAAAAgBgBQAAAAgBAAQAAgBAAAAQgCgDACgDQAHAAAEgCIACgCQAEACABAFIgCAiIAAAXQAAAIgDALIgBADIgCADIgHAHIgCABIgMAHIgLAFQgKAGgLALIgCABIgDADIgBABIgFAEIgIAJQgHAHgEACIgEAAIgDAAg");
	this.shape_18.setTransform(9.1,65.9,1.583,1.583);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(0,0,0,0.8)").s().p("AgGAEIgBgBIgBgBIAAgBIAAgBIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQAAAAAAABIAAgBIAIAAIACABIADADIgDADIgBAAg");
	this.shape_19.setTransform(2.4,46.4,1.583,1.583);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(0,0,0,0.8)").s().p("AglAoQACgDAIgEQAPgFALgGQAJgEAFgGIAJgMQAFgLgBgFIgCgIIgFgIQgCgEAAgDQACgFAEABQABAAADADQAKAMAAAMQAAAHgDAIQgHAPgFAHIgJAHQgMAIgRAGQgGACgFAAQgGAAgEgEg");
	this.shape_20.setTransform(-2.7,52.8,1.583,1.583);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(0,0,0,0.8)").s().p("AgCAfIgOgHIgHgEIgEgGIgEgHIgHgSQgDgIAAgDQABgIAFAAQAFAFAFAPQAEAKADAGIABABIAAABQgBAAAAAAQAAAAAAABQAAAAAAAAQAAABAAAAIADAFQAGAEAHADQAFABAMAAIAUABQAHgBAAAFQgBADgGAAIgXABIgOgBg");
	this.shape_21.setTransform(9.8,50.7,1.583,1.583);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(255,0,255,0.8)").s().p("AgzBZIAAiDIAGgKQADgJABgNIgBgNIAPgCIgBAAQAAABAAAAQgBABAAAAQAAABABAAQAAABAAABIABABIACAPIAEAMQACADAFAEIAAADIADAEQAGAFAGACQAFACANgBIANAAQAGABAEgCIAKgBIAAACIgCAkIgBAXQAAAIgDAMIgCAHQgDADgGAEIgUAMQgNAFgJAJIgFAEIgBABQgcgCgKABg");
	this.shape_22.setTransform(9.2,59.8,1.583,1.583);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(255,0,255,0.8)").s().p("AgXBoQgYgBgIABIAAiAQAogSAKgZQAEgKABgNIgBgMIAMgCIABAAIgBAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIACACIACAPIADAMQACADAGAEIAAACIACAFQAHAFAHACQAEABAKAAIAABoIgBABQgNAFgJAJIgGAEIgIAIIgEAFIgbASIgLgBg");
	this.shape_23.setTransform(2.8,62.2,1.583,1.583);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,0,255,0.8)").s().p("AghBYIAAh8IAHgDQAqgRAKgbIACgFIAGAAIgBCoIgOAJg");
	this.shape_24.setTransform(-2.3,64.7,1.583,1.583);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#000000","#888888","#B0B0B0","rgba(233,233,233,0.298)","#FFFFFF"],[0,0,0,0.89,1],210.1,201.6,210.1,201.6).s().p("AgQA4QgGgDgCgIQgBgGABgIIAEgfIAFgRIASgNIAXgLQAAAGgEAJQgPAfgBAMIAAAOIgCANQgCAHgFAEQgEACgEAAIgFgBgAABg0QAEgDAFgBQAGgBAEACIADADIgTAJIgLAHQAEgLAEgFg");
	this.shape_25.setTransform(-14.3,-62);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["#000000","#888888","#B0B0B0","rgba(233,233,233,0.298)","#FFFFFF"],[0,0,0,0.89,1],215.3,196.9,215.3,196.9).s().p("Ag5B+QgHAAgEgGQgCgEgBgJQgDghAAgRQAAgSACgIIAFgCIATgNIAbgNIAFgDIgCAUQgCAOgHAZIgJAoQgDASgFAFQgFAEgGAAIgCAAgAg5gGIAKgSIAJgOQAhgsAXgPQAIgEADgDIAGgMQAFgGAMgCQAMgCAFAFQAFAEABAKQABAQgIAfQgEAPgFAGQgKALgKgGQgJgEgBgSIgkAiQgEAFgCAHIgDgBQgBgBgFADIgZAMIgVANIALgWg");
	this.shape_26.setTransform(-9.1,-66.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["#000000","#888888","#B0B0B0","rgba(233,233,233,0.298)","#FFFFFF"],[0,0,0,0.89,1],215.9,193.3,215.9,193.3).s().p("Ag/BKIACgJIABgJIAGgEIAKgFIgDAIQgEAIgBAJQgBAGgEABIgCAAQgDAAgBgFgAg1AjIAHgQIAHgLIAHgLIAGgGQAEgEADgIQAKgTAMgOIAGgGQALgJAbgIIAHgBQAFABACACQAFAFgDAFIgFAEQgEAEgEAJQgEAMgCAJQgBAFgCABIgFABIgGACQgFABgFgIQgBACgEABIgHACIgEADIgGAJQgNALgFAHQgEAJgEAEIgFAFIgUALIgCABIACgFg");
	this.shape_27.setTransform(-8.5,-70.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["#000000","#888888","#B0B0B0","rgba(233,233,233,0.298)","#FFFFFF"],[0,0,0,0.89,1],215.3,194.4,215.3,194.4).s().p("AhKBaIgBgYIAAgKIABAAQACAAAEgCIAGgDQgDAHAAAGQAAAJADAEIACAFIgDAFQgFAEgDAAIgDgBgAhDAiQAmhBAogdQAQgKAPgIIAUgKQAHgDAEACQADABAAADQAAABAAABQAAABgBAAQAAABAAAAQgBABAAAAQABAFgGADQgCACgIABQgbAEgOAWQgEAHgDACQgDABgDgBQgDgBAAgDQgHAFgLAOIgGAGIgLANIgKAPIgIANIgCAEIgSALIAEgJg");
	this.shape_28.setTransform(-9.1,-69.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgCBCQgDgBgBgHIgDgmIgCgaQACgcAJgZQACgFAEgBQAGAAAAAGIgDAIIgJAHIgFAGIAAAEQAAABABAAQAAAAAAABQABAAAAAAQAAABABAAQACAAADgCQgDAQAAARQAAAPAEAnQAAAFgBADQgCAEgCAAIgBAAg");
	this.shape_29.setTransform(-16.2,-60.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AglBXQgCgCABgHQgBgYABgMIABgRQADgLAGgUIAJgZQAHgDACgEQACgCgBgDIgCgDIANgUQAFgIAFgEIALgIIAHgEQAEgBAEADQACACAAAEQAAADgCACIgIACQgJABgIAMIgQAXIgGAMQgFAIgEAQQgFAPgDANQgDAQAAAaIABAMQACAIgCACIgEACQgCAAgDgEg");
	this.shape_30.setTransform(-9.4,-63.2);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AhUBNIAAgBIADgDQACgDACgGIABgHIAthAIAVgeQALgQAOgIQAHgFARgHIAOgEQAGgBAIACQAIABAFADQADAEABAFQABAFgBACQgCAEgDgBQgCgBgDgGQgEgIgQACQgcAGgSATQgKAJgNAUIg0BMIgGAEIgGAGIAAAEIgCAAIgDgBg");
	this.shape_31.setTransform(-8.9,-71.7);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#000000").ss(1,1,1).p("AAZrAIAAVnQAAAKgHAIQgIAHgKAAQgKAAgHgHQgIgIAAgKIAA0m");
	this.shape_32.setTransform(-3.5,-7.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["#000000","#888888","#B0B0B0","rgba(233,233,233,0.298)","#FFFFFF"],[0,0,0,0.89,1],-2.5,-2.2,2.6,-2.2).s().p("AgRK5QgIgHABgLIAA0lQACgBADgEQAEgFAAgEIABgGIACgFIACgLIADgIIAAgEQAUgKALgGIABgBIAAVmQABALgIAHQgIAHgKAAQgJAAgIgHg");
	this.shape_33.setTransform(-3.5,-7.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AAEATQACgRADgHQADgNAFgMIADgHIAHgNIAAgEIACgHIAFgFIACgCIAAAAIABABIAAACIABAAQABAGgBAFIgDAKIgGAIIgEAAIAAAAQgGAMgBAMIgEAWIgDAYQgBAOAGAJQgCAIgHAEQgHgRAEghgAglgJIAAgHIABgIIABgEIABgEIACgHQADgEACgBQACgCADABQgDADAAAFIgBADIgBAEIgBAFIAAADIgBAEIgGAKg");
	this.shape_34.setTransform(-13.6,-61.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#CCCCCC").s().p("AgeAyIAAgFIgDgBIABgDQABgMALgPIADgEIALgMIAWgtQADgFABAEQgDANgMAUIgCAEIACAAIABAAIAAABIABAAIACAAIABAAIADgBIAFgDIACgCIABgBQADgDADABIABABIAAAEIACgCIABAAIADAAIgBADIgCABIgEAFIgDAHIAAADIgHANIgDABIAAgFIgDAEIgEAHQgDAEgBAAIgBAAIgDABQgGABgDAGIgCgBIAAgBIgBABIgMAQgAAGAMIACgBIABgCIgDADg");
	this.shape_35.setTransform(-13.4,-66.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.lf(["#000000","#888888","#B0B0B0","rgba(233,233,233,0.298)","#FFFFFF"],[0,0,0,0.89,1],-13.5,-66.1,-13.5,-66.1).s().p("AgeAcIAAAAIABgDIAAgDQADgKAGgIQADgEACACIgBABIgDAFQgKAOgCAMQgBgDACgDgAgMAbIABgBIAAACIADABQACgHAGAAIAEgBIgCACQgEAGgEgBQAAAAABgBQAAAAAAgBQAAAAABgBQAAgBAAAAQgDAIgHABIACgGgAANAQIAAgHIADgEIgBAGIADgCIgDAHgAALADIgBABIgCABIADgCgAAMgSIgBABIgDAAIgBAAIAAAAIgBgBQAEgDACABIAAABQACgGADgFQACgEADABIgCAJIgBADIgEAEIgEAAIABgBgAAegZIgCAAQgCgCgDADIACgDQACgEACABIACACIABAAIAAAFIAAAAIgCACg");
	this.shape_36.setTransform(-13.5,-66.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.squareco2machine, new cjs.Rectangle(-17.5,-79.5,35,159.1), null);


(lib.squareco2bubbles = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AANAAQAAAGgEADQgEAEgFAAQgFAAgEgEQgDgDAAgGQAAgEADgEQAEgEAFAAQAFAAAEAEQAEAEAAAEg");
	this.shape.setTransform(6.1,26.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.6)").s().p("AgIAJQgEgDAAgGQAAgEAEgEQAEgEAEAAQAGAAADAEQAEAEAAAEQAAAGgEADQgDAEgGAAQgEAAgEgEg");
	this.shape_1.setTransform(6.1,26.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.6)").s().p("AgIAAIgDAAIADAAIAIAAIAIAAIAEAAIgEAAIgIAAIgIAAg");
	this.shape_2.setTransform(6,27.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAGAAQAAADgCABQgBACgDAAQgCAAgCgCQgBgBAAgDQAAgCABgBQACgCACAAQADAAABACQACABAAACg");
	this.shape_3.setTransform(-2.4,-27.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.6)").s().p("AgEAEQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQABgBAAAAQAAgBAAgBQABAAABAAQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAAAQABABAAABQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAgBgBg");
	this.shape_4.setTransform(-2.4,-27.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAIAAQAAADgDACQgCADgDAAQgCAAgCgDQgDgCAAgDQAAgCADgDQACgCACAAQADAAACACQADADAAACg");
	this.shape_5.setTransform(-8.1,-23.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.6)").s().p("AgEAFQgCgCAAgDQAAgCACgCQACgDACAAQADAAACADQADACgBACQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_6.setTransform(-8.1,-23.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AALAAQAAAEgDAEQgEADgEAAQgDAAgEgDQgDgEAAgEQAAgDADgEQAEgDADAAQAEAAAEADQADAEAAADg");
	this.shape_7.setTransform(-9.5,-16.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.6)").s().p("AgHAIQgDgDAAgFQAAgEADgDQADgCAEAAQAEAAADACQADADAAAEQAAAFgDADQgDACgEAAQgEAAgDgCg");
	this.shape_8.setTransform(-9.5,-16.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAPAAQAAAGgFAEQgEAFgGAAQgFAAgEgFQgEgEAAgGQAAgFAEgEQAEgEAFAAQAGAAAEAEQAFAEAAAFg");
	this.shape_9.setTransform(-5.6,-17.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.6)").s().p("AgKAKQgEgEAAgGQAAgFAEgEQAFgFAFAAQAGAAAEAFQAFAEgBAFQABAGgFAEQgEAFgGAAQgFAAgFgFg");
	this.shape_10.setTransform(-5.6,-17.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAIAAQAAADgDACQgCADgDAAQgCAAgCgDQgDgCAAgDQAAgCADgDQACgCACAAQADAAACACQADADAAACg");
	this.shape_11.setTransform(9.9,-18.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.6)").s().p("AgEAFQgCgCAAgDQAAgCACgDQACgCACAAQADAAACACQADADgBACQABADgDACQgCACgDABQgCgBgCgCg");
	this.shape_12.setTransform(9.9,-18.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAOAAQAAAGgEAEQgEAEgGAAQgFAAgEgEQgEgEAAgGQAAgFAEgEQAEgEAFAAQAGAAAEAEQAEAEAAAFg");
	this.shape_13.setTransform(3.5,-18.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.6)").s().p("AgJAKQgEgEAAgGQAAgFAEgEQAEgEAFAAQAGAAAEAEQAEAEAAAFQAAAGgEAEQgEAEgGAAQgFAAgEgEg");
	this.shape_14.setTransform(3.5,-18.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAKAAQAAAEgDACQgDADgEAAQgDAAgDgDQgCgCAAgEQAAgDACgDQADgDADAAQAEAAADADQADADAAADg");
	this.shape_15.setTransform(7.4,-23.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.6)").s().p("AgGAGQgCgCgBgEQABgDACgDQADgDADAAQAEAAADADQACADAAADQAAAEgCACQgDADgEABQgDgBgDgDg");
	this.shape_16.setTransform(7.4,-23.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AARAAQAAAHgFAEQgFAFgHAAQgGAAgFgFQgEgEAAgHQAAgGAEgFQAFgFAGAAQAHAAAFAFQAFAFAAAGg");
	this.shape_17.setTransform(-1.3,-9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.6)").s().p("AgLAMQgFgFABgHQgBgGAFgFQAFgFAGABQAHgBAFAFQAEAFAAAGQAAAHgEAFQgFAEgHAAQgGAAgFgEg");
	this.shape_18.setTransform(-1.3,-9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAMAAQAAAFgEADQgDAEgFAAQgEAAgDgEQgEgDAAgFQAAgEAEgDQADgDAEAAQAFAAADADQAEADAAAEg");
	this.shape_19.setTransform(-7.4,8.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0.6)").s().p("AgHAIQgEgDAAgFQAAgEAEgDQADgEAEAAQAFAAADAEQADADABAEQgBAFgDADQgDADgFABQgEgBgDgDg");
	this.shape_20.setTransform(-7.4,8.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AANAAQAAAFgEAEQgEAEgFAAQgEAAgEgEQgEgEAAgFQAAgEAEgEQAEgEAEAAQAFAAAEAEQAEAEAAAEg");
	this.shape_21.setTransform(-8.1,1.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(255,255,255,0.6)").s().p("AgIAJQgDgEgBgFQABgEADgEQAEgDAEAAQAFAAADADQAFAEAAAEQAAAFgFAEQgDADgFAAQgEAAgEgDg");
	this.shape_22.setTransform(-8.1,1.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAIAAQAAAEgCACQgDACgDAAQgCAAgDgCQgCgCAAgEQAAgDACgCQADgCACAAQADAAADACQACACAAADg");
	this.shape_23.setTransform(-7,-5.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(255,255,255,0.6)").s().p("AgFAGQgCgDAAgDQAAgDACgCQACgCADAAQAEAAACACQACACAAADQAAADgCADQgCACgEAAQgDAAgCgCg");
	this.shape_24.setTransform(-7,-5.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAIAAQAAADgDACQgCADgDAAQgCAAgCgDQgDgCAAgDQAAgCADgDQACgCACAAQADAAACACQADADAAACg");
	this.shape_25.setTransform(7.2,-10.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(255,255,255,0.6)").s().p("AgFAFQgBgCgBgDQABgCABgDQADgBACAAQADAAACABQADADAAACQAAADgDACQgCACgDAAQgCAAgDgCg");
	this.shape_26.setTransform(7.2,-10.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAHAAQAAADgCACQgCACgDAAQgCAAgBgCQgDgCAAgDQAAgBADgCQABgCACAAQADAAACACQACACAAABg");
	this.shape_27.setTransform(7.8,-4.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(255,255,255,0.6)").s().p("AgDAFQgBgBAAgBQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAABAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAgBABAAQAAgBABAAQAAAAABAAQAAgBAAAAQABAAAAABQABAAAAAAQABAAAAABQABAAABABQAAAAAAABQABAAAAABQAAAAAAABQABAAAAAAQAAABgBAAQAAABAAAAQAAABgBAAQAAABAAABQgBAAgBAAQAAABgBAAQAAAAgBAAQAAABgBAAQAAAAAAgBQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_28.setTransform(7.8,-4.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AARAAQAAAHgFAFQgFAFgHAAQgGAAgFgFQgFgFAAgHQAAgGAFgFQAFgFAGAAQAHAAAFAFQAFAFAAAGg");
	this.shape_29.setTransform(-1.3,-0.9);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(255,255,255,0.6)").s().p("AgLAMQgFgFAAgHQAAgGAFgFQAFgFAGAAQAHAAAFAFQAFAFAAAGQAAAHgFAFQgFAFgHAAQgGAAgFgFg");
	this.shape_30.setTransform(-1.3,-0.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AANAAQAAAGgEADQgDAFgGAAQgFAAgDgFQgEgDAAgGQAAgFAEgDQADgFAFAAQAGAAADAFQAEADAAAFg");
	this.shape_31.setTransform(3.5,-1.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0.6)").s().p("AgIAKQgFgEAAgGQAAgEAFgEQAEgFAEAAQAFAAAFAFQADAEAAAEQAAAGgDAEQgFADgFAAQgEAAgEgDg");
	this.shape_32.setTransform(3.5,-1.8);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAGAAQAAADgCABQgBACgDAAQgCAAgBgCQgCgBAAgDQAAgCACgBQABgCACAAQADAAABACQACABAAACg");
	this.shape_33.setTransform(7.2,1.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.6)").s().p("AgDAEQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAABAAQgBABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBgBAAAAg");
	this.shape_34.setTransform(7.2,1.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAIAAQAAAEgCACQgDACgDAAQgCAAgDgCQgCgCAAgEQAAgDACgCQADgCACAAQADAAADACQACACAAADg");
	this.shape_35.setTransform(7.7,6.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.6)").s().p("AgFAGQgCgCAAgEQAAgCACgDQACgCADAAQADAAADACQACADAAACQAAAEgCACQgDACgDAAQgDAAgCgCg");
	this.shape_36.setTransform(7.7,6.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAQAAQAAAGgFAFQgEAFgHAAQgGAAgFgFQgEgFAAgGQAAgFAEgFQAFgFAGAAQAHAAAEAFQAFAFAAAFg");
	this.shape_37.setTransform(-1.4,14.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.6)").s().p("AgKALQgFgEAAgHQAAgGAFgEQAFgFAFAAQAGAAAFAFQAFAEAAAGQAAAHgFAEQgFAFgGAAQgFAAgFgFg");
	this.shape_38.setTransform(-1.4,14.7);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAGAAQAAADgCABQgBACgDAAQgCAAgBgCQgBgBAAgDQAAgCABgBQABgCACAAQADAAABACQACABAAACg");
	this.shape_39.setTransform(2.7,8.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.6)").s().p("AgDAEQAAAAgBgBQAAAAAAgBQAAAAAAgBQgBAAAAgBQAAAAABAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBgBAAAAg");
	this.shape_40.setTransform(2.7,8.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAFAAQAAACgCACQgBABgCAAQgBAAgBgBQgCgCAAgCQAAgBACgBQABgCABAAQACAAABACQACABAAABg");
	this.shape_41.setTransform(2.6,4.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(255,255,255,0.6)").s().p("AgCAEQgBgBAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAAAAAAAQAAAAAAgBQABAAAAgBQAAAAABgBQAAAAAAAAQABAAAAgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAABABAAQAAAAABAAQAAABAAAAQAAABABAAQAAABAAAAQAAAAAAAAQAAAAAAABQAAAAAAABQgBAAAAABQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAgBgBAAQAAAAAAAAg");
	this.shape_42.setTransform(2.6,4.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAHAAQAAADgCACQgCACgDAAQgCAAgCgCQgCgCAAgDQAAgCACgCQACgCACAAQADAAACACQACACAAACg");
	this.shape_43.setTransform(5.4,13.3);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.6)").s().p("AgEAFQgCgCAAgDQAAgCACgCQACgCACAAQADAAACACQACACAAACQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_44.setTransform(5.4,13.3);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAJAAQAAAEgDACQgDADgDAAQgDAAgDgDQgCgCAAgEQAAgCACgDQADgDADAAQADAAADADQADADAAACg");
	this.shape_45.setTransform(3,19.2);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.6)").s().p("AgGAGQgCgDAAgDQAAgDACgDQADgCADAAQADAAADACQADADAAADQAAADgDADQgDADgDAAQgDAAgDgDg");
	this.shape_46.setTransform(3,19.2);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAPAAQAAAGgFAFQgEAEgGAAQgFAAgFgEQgEgFAAgGQAAgFAEgFQAFgEAFAAQAGAAAEAEQAFAFAAAFg");
	this.shape_47.setTransform(3.6,24.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.6)").s().p("AgKAKQgEgEAAgGQAAgFAEgFQAFgEAFAAQAGAAAFAEQAEAFAAAFQAAAGgEAEQgFAFgGAAQgFAAgFgFg");
	this.shape_48.setTransform(3.6,24.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.squareco2bubbles, new cjs.Rectangle(-11.6,-28.7,23.3,57.4), null);


(lib.squareco2machine_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(0,0,0,0.8)").s().p("AAWAxQgJgCgKgEQgRgGgHgGQgGgGgFgJIgJgQIgTgkIgDgGQAAgEADgCQADgCADADQADADABAEIAJAQIAFAJIACAGIAFAIIAEAHQAHAQAKAFIALAEIAOAGQAIADAMAAIAUAAQAGABAAADQABAEgEABIgFABg");
	this.shape_37.setTransform(10.3,50.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(0,0,0,0.8)").s().p("AgTAEQAAgEAFgBIAJgBIAJgCIAKgDIAEABQADACgCADQgCACgDACQgFADgHABIgOABQgGAAgBgEg");
	this.shape_38.setTransform(2.6,46.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,0,255,0.8)").s().p("AASAtQgDgBgCgCQgHgFgHgVIgLgZQgJgSgBgGQAAgGABgBQACgEADABQADABABAJQABAFAIAMQADAHADAIIAHARQADALAGAGQAGAHgCADQgBAAAAABQAAAAgBAAQAAAAgBABQAAAAgBAAIgBAAg");
	this.shape_39.setTransform(6.2,50.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,0,255,0.8)").s().p("AgLAHIgFAAQAAAAgBgBQAAAAgBAAQAAgBAAAAQgBgBAAAAQAAgEAEgBIAFgBIAOAAIADgBIAEgCIABgBQAGAAACAEQAAACgEADQgCADgDABIgFAAg");
	this.shape_40.setTransform(2.6,46.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,0,255,0.8)").s().p("AgEAcQAEgJgCgNIgCgKQgEgOACgIQAAgDADgCQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAABIAAAJIADAKQADAHAAATIgCAIQgBAEgEABIgBAAQgDAAgBgEg");
	this.shape_41.setTransform(2.6,50.9);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(255,0,255,0.8)").s().p("AAHAHIgLAAIgDgBQgDAAgCgDQgDgDACgDQABgEAEABIAFADIAEABIAHABQABAAABAAQABAAAAAAQABAAAAAAQABABAAAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABAAAAQAAABAAABQAAAAgBABQAAAAAAAAQgBABAAAAIgEABIgCAAg");
	this.shape_42.setTransform(2.6,47.2);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,0,255,0.8)").s().p("AAAALQgCgBgCgEQgDgFAAgGIABgDQACgDADAAQACAAABADIABAHQAAABADAEQADAEgDADIgDABIgDgBg");
	this.shape_43.setTransform(2.4,47.9);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,0,255,0.8)").s().p("AgOALQgCgDACgDQADgFADgBIAGgCIAEgEQADgDADAAIABgBQAFAAACAEQAAACgDADIgHAFIgIAEIgGAEIgDABIgDgBg");
	this.shape_44.setTransform(12.3,56.7);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,0,255,0.8)").s().p("AAiAJIgzgEQgNgBgFgDQgHgEADgEQACgCAFABQAcAHAhAAQAGAAADABQACABABADQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAIgDABIgCAAg");
	this.shape_45.setTransform(11.5,55.2);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,0,255,0.8)").s().p("AAWApQgMgHgJgTIgLgdQgFgMgGgEQgJgDgEgEQABgDAEgCQADgBAEABQAMACAIARQAEAKAIAUQAIATANAHIAEAEQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAQAAAAgBABQAAAAgBAAQAAABgBAAIgBAAQgEAAgDgDg");
	this.shape_46.setTransform(5.1,50.8);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,0,255,0.8)").s().p("AgLAvQgEgDAFgIQAOgWAAgOIgCgPQgCgMgHgQQgBAAAAgBQABAAAAgBQAAAAAAAAQABgBABAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQACACADAFQALAVgBAWQgCAYgNAQQgEAFgDAAIgDgBg");
	this.shape_47.setTransform(2.7,51.6);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,0,255,0.8)").s().p("AAFAUIgEgHIgIgNIgFgFIgDgHIgBgGQABgDACgBQAEgBACAEQABABABAEQACAFAFAHQAHAGACAEIADAFIADAFQAAAFgFABQgEAAgDgEg");
	this.shape_48.setTransform(5.9,52.6);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,0,255,0.8)").s().p("AAHAUIgEgEQgDgNgEgEIgGgHIgDgGQAAAAgBgBQAAAAAAAAQAAgBAAAAQABAAAAgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQAAgBAAAAQADAAADACIAGAKIADAFIAHAOIACAEQAAAEgCABIgDABIgDgBg");
	this.shape_49.setTransform(3.6,49);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,0,255,0.8)").s().p("AAAAGIgDgCIgCgBIAAgCIgBgBIAAgDIADgDQACgBAEADQADADAAABQADAFgFABIgBABIgDgBg");
	this.shape_50.setTransform(2.6,47.7);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,0,255,0.8)").s().p("AABARQgCgCgBgDIgEgKIgBgDIgBgKIACgFQAAAAABAAQAAgBABAAQAAAAAAAAQABAAABAAQAAAAABAAQAAAAAAAAQABAAAAABQAAAAAAAAIACAHQAAAIAEAGIADAGQABADgDADIgDABIgDgBg");
	this.shape_51.setTransform(-7.3,62.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(0,0,0,0.8)").s().p("AgyAYQgFgBgBgDQADgEALgCQAtgHAogYQgBgGAHgBQAFgBADAGQgOASgLADIgOAGIgKAGIgJADIgYAGIgOACIgLgBg");
	this.shape_52.setTransform(7.5,59.1,1.583,1.583);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(0,0,0,0.8)").s().p("AAWA7QgCgIAAgPQABgRgBgHQgFgPAAgJIABgKQAAgFgCgEQgDgEgLgEQgHgCgUgLQgJgFACgFQADgHALAIQAQAKAOAFQALAFACADQADAFAAAHIgBANIADANIADAMIgBAWQgBAOAFAHIABADIgBABQgGADgDAEIgDgHg");
	this.shape_53.setTransform(-3.1,69,1.583,1.583);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(0,0,0,0.8)").s().p("AgWBBQgFgBgCgCQgCgDAAgGIABgkQAAgYgBgHIgEgVQgCgNACgJQAAgDACgCQABgBAAAAQABAAAAgBQABAAAAAAQABAAAAABQAGAZACAZIAABBQAdgFAdAKQgGADgDAEIgDAAQgMgDgGAAIgOACIgMACIgDAAg");
	this.shape_54.setTransform(-3.7,69.4,1.583,1.583);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(0,0,0,0.8)").s().p("AguBNQgEgCgBgDQAageAlgUIAPgKQAJgGADgGQAFgIAAgVIgCglQAAAAAAABQgBAAAAAAQgBABgBAAQAAAAgBAAQgBAAgBAAQAAAAgBgBQAAAAgBAAQAAgBAAAAQgCgDACgDQAHAAAEgCIACgCQAEACABAFIgCAiIAAAXQAAAIgDALIgBADIgCADIgHAHIgCABIgMAHIgLAFQgKAGgLALIgCABIgDADIgBABIgFAEIgIAJQgHAHgEACIgEAAIgDAAg");
	this.shape_55.setTransform(9.1,65.9,1.583,1.583);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(0,0,0,0.8)").s().p("AgGAEIgBgBIgBgBIAAgBIAAgBIACgCQAAgBAAAAQABAAAAAAQAAAAABAAQAAAAAAABIAAgBIAIAAIACABIADADIgDADIgBAAg");
	this.shape_56.setTransform(2.4,46.4,1.583,1.583);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(0,0,0,0.8)").s().p("AglAoQACgDAIgEQAPgFALgGQAJgEAFgGIAJgMQAFgLgBgFIgCgIIgFgIQgCgEAAgDQACgFAEABQABAAADADQAKAMAAAMQAAAHgDAIQgHAPgFAHIgJAHQgMAIgRAGQgGACgFAAQgGAAgEgEg");
	this.shape_57.setTransform(-2.7,52.8,1.583,1.583);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(0,0,0,0.8)").s().p("AgCAfIgOgHIgHgEIgEgGIgEgHIgHgSQgDgIAAgDQABgIAFAAQAFAFAFAPQAEAKADAGIABABIAAABQgBAAAAAAQAAAAAAABQAAAAAAAAQAAABAAAAIADAFQAGAEAHADQAFABAMAAIAUABQAHgBAAAFQgBADgGAAIgXABIgOgBg");
	this.shape_58.setTransform(9.8,50.7,1.583,1.583);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,0,255,0.8)").s().p("AgzBZIAAiDIAGgKQADgJABgNIgBgNIAPgCIgBAAQAAABAAAAQgBABAAAAQAAABABAAQAAABAAABIABABIACAPIAEAMQACADAFAEIAAADIADAEQAGAFAGACQAFACANgBIANAAQAGABAEgCIAKgBIAAACIgCAkIgBAXQAAAIgDAMIgCAHQgDADgGAEIgUAMQgNAFgJAJIgFAEIgBABQgcgCgKABg");
	this.shape_59.setTransform(9.2,59.8,1.583,1.583);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,0,255,0.8)").s().p("AgXBoQgYgBgIABIAAiAQAogSAKgZQAEgKABgNIgBgMIAMgCIABAAIgBAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIACACIACAPIADAMQACADAGAEIAAACIACAFQAHAFAHACQAEABAKAAIAABoIgBABQgNAFgJAJIgGAEIgIAIIgEAFIgbASIgLgBg");
	this.shape_60.setTransform(2.8,62.2,1.583,1.583);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,0,255,0.8)").s().p("AghBYIAAh8IAHgDQAqgRAKgbIACgFIAGAAIgBCoIgOAJg");
	this.shape_61.setTransform(-2.3,64.7,1.583,1.583);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.lf(["#000000","#888888","#B0B0B0","rgba(233,233,233,0.298)","#FFFFFF"],[0,0,0,0.89,1],210.1,201.6,210.1,201.6).s().p("AgQA4QgGgDgCgIQgBgGABgIIAEgfIAFgRIASgNIAXgLQAAAGgEAJQgPAfgBAMIAAAOIgCANQgCAHgFAEQgEACgEAAIgFgBgAABg0QAEgDAFgBQAGgBAEACIACADIgSAJIgLAHQAEgLAEgFg");
	this.shape_62.setTransform(-14.3,-62);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["#000000","#888888","#B0B0B0","rgba(233,233,233,0.298)","#FFFFFF"],[0,0,0,0.89,1],215.3,196.9,215.3,196.9).s().p("Ag5B+QgHAAgEgGQgCgEgBgJQgDghAAgRQAAgSACgIIAFgCIATgNIAbgNIAFgDIgCAUQgCAOgHAZIgJAoQgDASgFAFQgFAEgGAAIgCAAgAg5gGIAKgSIAJgOQAhgsAXgPQAIgEADgDIAGgMQAFgGAMgCQAMgCAFAFQAFAEABAKQABAQgIAfQgEAPgFAGQgKALgKgGQgJgEgBgSIgkAiQgEAFgCAHIgDgBQgBgBgFADIgZAMIgVANIALgWg");
	this.shape_63.setTransform(-9.1,-66.7);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.lf(["#000000","#888888","#B0B0B0","rgba(233,233,233,0.298)","#FFFFFF"],[0,0,0,0.89,1],215.9,193.3,215.9,193.3).s().p("Ag/BKIACgJIABgJIAGgEIAKgFIgDAIQgEAIgBAJQgBAGgEABIgCAAQgDAAgBgFgAg1AjIAHgQIAHgLIAHgLIAGgGQAEgEADgIQAKgTAMgOIAGgGQALgJAbgIIAHgBQAFABACACQAFAFgDAFIgFAEQgEAEgEAJQgEAMgCAJQgBAFgCABIgFABIgGACQgFABgFgIQgBACgEABIgHACIgEADIgGAJQgNALgFAHQgEAJgEAEIgFAFIgUALIgCABIACgFg");
	this.shape_64.setTransform(-8.5,-70.3);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.lf(["#000000","#888888","#B0B0B0","rgba(233,233,233,0.298)","#FFFFFF"],[0,0,0,0.89,1],215.3,194.4,215.3,194.4).s().p("AhKBaIgBgYIAAgKIABAAQACAAAEgCIAGgDQgDAHAAAGQAAAJADAEIACAFIgDAFQgFAEgDAAIgDgBgAhDAiQAmhBAogdQAQgKAPgIIAUgKQAHgDAEACQADABAAADQAAABAAABQAAABgBAAQAAABAAAAQgBABAAAAQABAFgGADQgCACgIABQgbAEgOAWQgEAHgDACQgDABgDgBQgDgBAAgDQgHAFgLAOIgGAGIgLANIgKAPIgIANIgCAEIgSALIAEgJg");
	this.shape_65.setTransform(-9.1,-69.2);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AgCBCQgDgBgBgHIgDgmIgCgaQACgcAJgZQACgFAEgBQAGAAAAAGIgDAIIgJAHIgFAGIAAAEQAAABABAAQAAAAAAABQABAAAAAAQAAABABAAQACAAADgCQgDAQAAARQAAAPAEAnQAAAFgBADQgCAEgCAAIgBAAg");
	this.shape_66.setTransform(-16.2,-60.4);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AglBXQgCgCABgHQgBgYABgMIABgRQADgLAGgUIAJgZQAHgDACgEQACgCgBgDIgCgDIANgUQAFgIAFgEIALgIIAHgEQAEgBAEADQACACAAAEQAAADgCACIgIACQgJABgIAMIgQAXIgGAMQgFAIgEAQQgFAPgDANQgDAQAAAaIABAMQACAIgCACIgEACQgCAAgDgEg");
	this.shape_67.setTransform(-9.4,-63.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AhUBNIAAgBIADgDQACgDACgGIABgHIAthAIAVgeQALgQAOgIQAHgFARgHIAOgEQAGgBAIACQAIABAFADQADAEABAFQABAFgBACQgCAEgDgBQgCgBgDgGQgEgIgQACQgcAGgSATQgKAJgNAUIg0BMIgGAEIgGAGIAAAEIgCAAIgDgBg");
	this.shape_68.setTransform(-8.9,-71.7);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#000000").ss(1,1,1).p("AAZrAIAAVnQAAAKgHAIQgIAHgKAAQgKAAgHgHQgIgIAAgKIAA0m");
	this.shape_69.setTransform(-3.5,-7.4);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.lf(["#000000","#888888","#B0B0B0","rgba(233,233,233,0.298)","#FFFFFF"],[0,0,0,0.89,1],-2.5,-2.2,2.6,-2.2).s().p("AgRK5QgIgHABgLIAA0lQACgBADgEQAEgFAAgEIABgGIACgFIACgLIADgIIAAgEQAUgKALgGIABgBIAAVmQABALgIAHQgIAHgKAAQgJAAgIgHg");
	this.shape_70.setTransform(-3.5,-7.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.squareco2machine_1, new cjs.Rectangle(-17.4,-79.5,34.8,159.1), null);


(lib.squareco2bubbles_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AANAAQAAAGgEADQgEAEgFAAQgFAAgEgEQgDgDAAgGQAAgEADgEQAEgEAFAAQAFAAAEAEQAEAEAAAEg");
	this.shape_49.setTransform(6.1,26.3);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.6)").s().p("AgIAJQgEgDAAgGQAAgEAEgEQAEgEAEAAQAGAAADAEQAEAEAAAEQAAAGgEADQgDAEgGAAQgEAAgEgEg");
	this.shape_50.setTransform(6.1,26.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0.6)").s().p("AgIAAIgDAAIADAAIAIAAIAIAAIAEAAIgEAAIgIAAIgIAAg");
	this.shape_51.setTransform(6,27.7);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAGAAQAAADgCABQgBACgDAAQgCAAgCgCQgBgBAAgDQAAgCABgBQACgCACAAQADAAABACQACABAAACg");
	this.shape_52.setTransform(-2.4,-27.1);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(255,255,255,0.6)").s().p("AgEAEQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQABgBAAAAQAAgBAAgBQABAAABAAQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAAAQABABAAABQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAgBgBg");
	this.shape_53.setTransform(-2.4,-27.1);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAIAAQAAADgDACQgCADgDAAQgCAAgCgDQgDgCAAgDQAAgCADgDQACgCACAAQADAAACACQADADAAACg");
	this.shape_54.setTransform(-8.1,-23.1);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.6)").s().p("AgEAFQgCgCAAgDQAAgCACgCQACgDACAAQADAAACADQADACgBACQABADgDACQgCACgDAAQgCAAgCgCg");
	this.shape_55.setTransform(-8.1,-23.1);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AALAAQAAAEgDAEQgEADgEAAQgDAAgEgDQgDgEAAgEQAAgDADgEQAEgDADAAQAEAAAEADQADAEAAADg");
	this.shape_56.setTransform(-9.5,-16.6);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.6)").s().p("AgHAIQgDgDAAgFQAAgEADgDQADgCAEAAQAEAAADACQADADAAAEQAAAFgDADQgDACgEAAQgEAAgDgCg");
	this.shape_57.setTransform(-9.5,-16.6);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAPAAQAAAGgFAEQgEAFgGAAQgFAAgEgFQgEgEAAgGQAAgFAEgEQAEgEAFAAQAGAAAEAEQAFAEAAAFg");
	this.shape_58.setTransform(-5.6,-17.9);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.6)").s().p("AgKAKQgEgEAAgGQAAgFAEgEQAFgFAFAAQAGAAAEAFQAFAEgBAFQABAGgFAEQgEAFgGAAQgFAAgFgFg");
	this.shape_59.setTransform(-5.6,-17.9);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAIAAQAAADgDACQgCADgDAAQgCAAgCgDQgDgCAAgDQAAgCADgDQACgCACAAQADAAACACQADADAAACg");
	this.shape_60.setTransform(9.9,-18.4);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0.6)").s().p("AgEAFQgCgCAAgDQAAgCACgDQACgCACAAQADAAACACQADADgBACQABADgDACQgCACgDABQgCgBgCgCg");
	this.shape_61.setTransform(9.9,-18.4);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAOAAQAAAGgEAEQgEAEgGAAQgFAAgEgEQgEgEAAgGQAAgFAEgEQAEgEAFAAQAGAAAEAEQAEAEAAAFg");
	this.shape_62.setTransform(3.5,-18.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("rgba(255,255,255,0.6)").s().p("AgJAKQgEgEAAgGQAAgFAEgEQAEgEAFAAQAGAAAEAEQAEAEAAAFQAAAGgEAEQgEAEgGAAQgFAAgEgEg");
	this.shape_63.setTransform(3.5,-18.5);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAKAAQAAAEgDACQgDADgEAAQgDAAgDgDQgCgCAAgEQAAgDACgDQADgDADAAQAEAAADADQADADAAADg");
	this.shape_64.setTransform(7.4,-23.7);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.6)").s().p("AgGAGQgCgCgBgEQABgDACgDQADgDADAAQAEAAADADQACADAAADQAAAEgCACQgDADgEABQgDgBgDgDg");
	this.shape_65.setTransform(7.4,-23.7);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AARAAQAAAHgFAEQgFAFgHAAQgGAAgFgFQgEgEAAgHQAAgGAEgFQAFgFAGAAQAHAAAFAFQAFAFAAAGg");
	this.shape_66.setTransform(-1.3,-9);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.6)").s().p("AgLAMQgFgFABgHQgBgGAFgFQAFgFAGABQAHgBAFAFQAEAFAAAGQAAAHgEAFQgFAEgHAAQgGAAgFgEg");
	this.shape_67.setTransform(-1.3,-9);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAMAAQAAAFgEADQgDAEgFAAQgEAAgDgEQgEgDAAgFQAAgEAEgDQADgDAEAAQAFAAADADQAEADAAAEg");
	this.shape_68.setTransform(-7.4,8.2);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.6)").s().p("AgHAIQgEgDAAgFQAAgEAEgDQADgEAEAAQAFAAADAEQADADABAEQgBAFgDADQgDADgFABQgEgBgDgDg");
	this.shape_69.setTransform(-7.4,8.2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AANAAQAAAFgEAEQgEAEgFAAQgEAAgEgEQgEgEAAgFQAAgEAEgEQAEgEAEAAQAFAAAEAEQAEAEAAAEg");
	this.shape_70.setTransform(-8.1,1.9);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.6)").s().p("AgIAJQgDgEgBgFQABgEADgEQAEgDAEAAQAFAAADADQAFAEAAAEQAAAFgFAEQgDADgFAAQgEAAgEgDg");
	this.shape_71.setTransform(-8.1,1.9);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAIAAQAAAEgCACQgDACgDAAQgCAAgDgCQgCgCAAgEQAAgDACgCQADgCACAAQADAAADACQACACAAADg");
	this.shape_72.setTransform(-7,-5.3);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("rgba(255,255,255,0.6)").s().p("AgFAGQgCgDAAgDQAAgDACgCQACgCADAAQAEAAACACQACACAAADQAAADgCADQgCACgEAAQgDAAgCgCg");
	this.shape_73.setTransform(-7,-5.3);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAIAAQAAADgDACQgCADgDAAQgCAAgCgDQgDgCAAgDQAAgCADgDQACgCACAAQADAAACACQADADAAACg");
	this.shape_74.setTransform(7.2,-10.1);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0.6)").s().p("AgFAFQgBgCgBgDQABgCABgDQADgBACAAQADAAACABQADADAAACQAAADgDACQgCACgDAAQgCAAgDgCg");
	this.shape_75.setTransform(7.2,-10.1);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAHAAQAAADgCACQgCACgDAAQgCAAgBgCQgDgCAAgDQAAgBADgCQABgCACAAQADAAACACQACACAAABg");
	this.shape_76.setTransform(7.8,-4.8);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.6)").s().p("AgDAFQgBgBAAgBQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAABAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAgBABAAQAAgBABAAQAAAAABAAQAAgBAAAAQABAAAAABQABAAAAAAQABAAAAABQABAAABABQAAAAAAABQABAAAAABQAAAAAAABQABAAAAAAQAAABgBAAQAAABAAAAQAAABgBAAQAAABAAABQgBAAgBAAQAAABgBAAQAAAAgBAAQAAABgBAAQAAAAAAgBQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_77.setTransform(7.8,-4.8);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AARAAQAAAHgFAFQgFAFgHAAQgGAAgFgFQgFgFAAgHQAAgGAFgFQAFgFAGAAQAHAAAFAFQAFAFAAAGg");
	this.shape_78.setTransform(-1.3,-0.9);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.6)").s().p("AgLAMQgFgFAAgHQAAgGAFgFQAFgFAGAAQAHAAAFAFQAFAFAAAGQAAAHgFAFQgFAFgHAAQgGAAgFgFg");
	this.shape_79.setTransform(-1.3,-0.9);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AANAAQAAAGgEADQgDAFgGAAQgFAAgDgFQgEgDAAgGQAAgFAEgDQADgFAFAAQAGAAADAFQAEADAAAFg");
	this.shape_80.setTransform(3.5,-1.8);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.6)").s().p("AgIAKQgFgEAAgGQAAgEAFgEQAEgFAEAAQAFAAAFAFQADAEAAAEQAAAGgDAEQgFADgFAAQgEAAgEgDg");
	this.shape_81.setTransform(3.5,-1.8);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAGAAQAAADgCABQgBACgDAAQgCAAgBgCQgCgBAAgDQAAgCACgBQABgCACAAQADAAABACQACABAAACg");
	this.shape_82.setTransform(7.2,1.9);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("rgba(255,255,255,0.6)").s().p("AgDAEQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAABAAQgBABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBgBAAAAg");
	this.shape_83.setTransform(7.2,1.9);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAIAAQAAAEgCACQgDACgDAAQgCAAgDgCQgCgCAAgEQAAgDACgCQADgCACAAQADAAADACQACACAAADg");
	this.shape_84.setTransform(7.7,6.7);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0.6)").s().p("AgFAGQgCgCAAgEQAAgCACgDQACgCADAAQADAAADACQACADAAACQAAAEgCACQgDACgDAAQgDAAgCgCg");
	this.shape_85.setTransform(7.7,6.7);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAQAAQAAAGgFAFQgEAFgHAAQgGAAgFgFQgEgFAAgGQAAgFAEgFQAFgFAGAAQAHAAAEAFQAFAFAAAFg");
	this.shape_86.setTransform(-1.4,14.7);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.6)").s().p("AgKALQgFgEAAgHQAAgGAFgEQAFgFAFAAQAGAAAFAFQAFAEAAAGQAAAHgFAEQgFAFgGAAQgFAAgFgFg");
	this.shape_87.setTransform(-1.4,14.7);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAGAAQAAADgCABQgBACgDAAQgCAAgBgCQgBgBAAgDQAAgCABgBQABgCACAAQADAAABACQACABAAACg");
	this.shape_88.setTransform(2.7,8.7);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.6)").s().p("AgDAEQAAAAgBgBQAAAAAAgBQAAAAAAgBQgBAAAAgBQAAAAABAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBgBAAAAg");
	this.shape_89.setTransform(2.7,8.7);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAFAAQAAACgCACQgBABgCAAQgBAAgBgBQgCgCAAgCQAAgBACgBQABgCABAAQACAAABACQACABAAABg");
	this.shape_90.setTransform(2.6,4.6);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.6)").s().p("AgCAEQgBgBAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAAAAAAAQAAAAAAgBQABAAAAgBQAAAAABgBQAAAAAAAAQABAAAAgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAABABAAQAAAAABAAQAAABAAAAQAAABABAAQAAABAAAAQAAAAAAAAQAAAAAAABQAAAAAAABQgBAAAAABQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAgBgBAAQAAAAAAAAg");
	this.shape_91.setTransform(2.6,4.6);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAHAAQAAADgCACQgCACgDAAQgCAAgCgCQgCgCAAgDQAAgCACgCQACgCACAAQADAAACACQACACAAACg");
	this.shape_92.setTransform(5.4,13.3);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0.6)").s().p("AgEAFQgCgCAAgDQAAgCACgCQACgCACAAQADAAACACQACACAAACQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_93.setTransform(5.4,13.3);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAJAAQAAAEgDACQgDADgDAAQgDAAgDgDQgCgCAAgEQAAgCACgDQADgDADAAQADAAADADQADADAAACg");
	this.shape_94.setTransform(3,19.2);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(255,255,255,0.6)").s().p("AgGAGQgCgDAAgDQAAgDACgDQADgCADAAQADAAADACQADADAAADQAAADgDADQgDADgDAAQgDAAgDgDg");
	this.shape_95.setTransform(3,19.2);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("rgba(255,255,255,0.6)").ss(1,1,1).p("AAPAAQAAAGgFAFQgEAEgGAAQgFAAgFgEQgEgFAAgGQAAgFAEgFQAFgEAFAAQAGAAAEAEQAFAFAAAFg");
	this.shape_96.setTransform(3.6,24.1);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(255,255,255,0.6)").s().p("AgKAKQgEgEAAgGQAAgFAEgFQAFgEAFAAQAGAAAFAEQAEAFAAAFQAAAGgEAEQgFAFgGAAQgFAAgFgFg");
	this.shape_97.setTransform(3.6,24.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.squareco2bubbles_1, new cjs.Rectangle(-11.6,-28.7,23.3,57.4), null);


(lib.window = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AAAurIAAM5IM5AAIAAQeIs5AAIs4AAIAAweIM4AAIAAQeAM5urIAAM5As4hyIAAs5");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.window, new cjs.Rectangle(-83.4,-94.9,167,190), null);


(lib.TC_TObject__CBackgroundSun = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().ls(["#FFFFFF","#000000"],[0,1],-1.3,-11.7,82.2,-37.8).ss(1,1,1).p("AAAclMAAAg5J");
	this.shape.setTransform(-274.9,-16.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(255,255,102,0.6)").ss(14.3,1,1).p("AI/AAQAABggbBUQgpB+hkBkQhVBVhnArQgbALgcAIQhOAWhWAAQjtAAioipQhlhkgph+QgbhUAAhgQAAjtCpipQCoioDtAAQBWAABOAWQAcAIAbALQBnArBVBUQCoCpAADtg");
	this.shape_1.setTransform(-108.8,-134.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("As4hyIByAAILGAAIGAAAIG5AAIAAQeIs5AAIs4AAIAAweIAAs5AAAurIAABcIAALdIAAF0IAAKqAM5urIAAM5");
	this.shape_2.setTransform(-92.4,-105.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#FFFFFF","#000000"],[0,1],-41.4,-20.1,40.8,-45.8).s().p("AmXbYMAAAg5KQBjgBBhgHQAIAAAEgEQEvABEwAAMAAAAuNIsvNvg");
	this.shape_3.setTransform(-234.2,-9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFF00").s().p("AmWGWQhkhkgph+QgbhUAAhgQAAjtCoioQCpipDtAAQBWAABOAWQAcAIAbAMQBnAqBVBVQCoCoAADtQAABggbBUImAAAIAArcIAALcIAAF1QhOAWhWAAQjtAAipipgACkC0IrHAAgACkC0IGAAAQgpB+hkBkQhVBVhnAqQgbAMgcAIgACkC0g");
	this.shape_4.setTransform(-108.8,-134.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__CBackgroundSun, new cjs.Rectangle(-275.9,-200.9,267,383.8), null);


(lib.table = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EAmdABaIAAgOIAAimIDaAAIAACmIAAALAieBOIAAgCIAAimIDkAAIAACmIAAAJEgp2ABVIAAgFIAAiqIDyAAIAACgIAAAQ");
	this.shape.setTransform(-7,44.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(1,1,1).p("EAm+gBTICBAAEghQABTIiSABIkRgBEgo+gBTMAjnAAAAhzhTMAlXAAA");
	this.shape_1.setTransform(11.5,43.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("EgnzABTIhHgGIgEAAIAAigMAjnAAAIAACmIgMAAQg6gDhBgBQhDAAh5ACIAAACI0AAAIAAgDIi2ADIiSABgEAm+ABTIAAimICAAAIABCmgAhzBTIAAimMAlWAAAIAACmg");
	this.shape_2.setTransform(11.5,43.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("EAlWAIGIAAimMglWAAAIjkAAMgjmAAAIjzAAIAACrIAAirIDzAAIAACgIAAAQIjzgBIAAgEIgKAAIgCwfMBWTAAAIAANuIgYAAIAAAGIiBAAIjbAAIDbAAIAACmIAAALIgPAAIjMAEgAivIMIg1gFIAAgBIAAimIDkAAIAACmIAAAJIhRgBIAAAGIhegIgEglYAIKIgogEIERABIiSAEIglAAIgygBgAAAFgg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.table, new cjs.Rectangle(-276.2,-53.2,552.4,107.5), null);


(lib.sun = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(255,255,102,0.6)").ss(14.3,1,1).p("AI/AAQAADuioCpQipCojuAAQjtAAipioQioipAAjuQAAjtCoipQCpioDtAAQDuAACpCoQCoCpAADtg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF00").s().p("AmWGXQioipAAjuQAAjtCoipQCpioDtAAQDuAACpCoQCoCpAADtQAADuioCpQipCojuAAQjtAAipiog");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.sun, new cjs.Rectangle(-64.6,-64.6,129.3,129.3), null);


(lib.CTable = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EAmdABaIAAizIDaAAIAACwAieBOIAAinIDkAAIAACuEgp2ABVIAAiuIDyAAIAACv");
	this.shape.setTransform(267.9,97.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(1,1,1).p("EAm+AAAICBAAEgo+AAAMAjnAAAAhzAAMAlWAAA");
	this.shape_1.setTransform(286.5,88.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("EAlQAFfMglWAAAIjkAAMgjnAAAIjyAAIMwttIAAgGMBJXAAAIAANuIgZAAIAAAFIiAAAIjbAAIDbAAIAACyIgPAAIjMADgAi2ILIg0gDIAAipIDkAAIAACwIhRgBIAAAGIhfgJgEgrDAIPIAAiwIDyAAIAACygEgrDAFfg");
	this.shape_2.setTransform(275.6,53.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTable, new cjs.Rectangle(-1,0,552.2,107.5), null);


(lib.CAlgaeSmall = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#336600").s().p("AgBACQgDgBgBgDQAFAFAFgDIABAAIgCABQAAAAAAABQgBAAAAAAQgBAAAAAAQgBABAAAAIgBAAIAAAAIgBgBg");
	this.shape.setTransform(9.6,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgLAsIgBAAIgCAAIAAgBIgCAAIAAAAQAAAAgBgBQAAAAAAAAQAAAAAAgBQAAAAAAgBIABgCIABgBIAAAAIABgBIABAAIAAAAIAEAAIAEAAIACABIABAAIABACIAAABIAAABQAAAAAAABQAAAAAAAAQgBABAAAAQAAAAgBAAIAAAAIgBAAIgFABIgCAAgAgNAoIgBgBIAAAAIABABIABAAIgBgBIgBAAQgBAAAAAAQAAAAAAAAQAAAAABABQAAAAABAAIAAAAgAgGAoIAAAAIABAAIgCgCIABACgAicAmIgCAAIgCAAIAAgBIgBAAIgBAAIgBgBIAAgBIgBgBIABgCIABgBIACgBIABAAIABAAIAFgBIAHABIABAAIABAAIABAAIABABIABADIgBABIAAABIgBABIgBAAIgCAAIABAAIgIABIAAAAIgDAAgAidAiIAAAAIAEAAIAGAAIgGgBIgEABgAiRAhIAAAAIAAAAgAifAhIgBgBIAAABIAAAAIABAAgAA6AeIgBgFIgCgFIgCgDIgEgEIABAAIAAgBIABAAIABAAIADgCIACgBIABAAIABAAIABABIACACIACACQAAAEADABIACAAIAAABQAAAGgDACQgEACgEAAIAAAAgAA5AUIABAAIACAAIgBAAIAAAAIgBgBIAAAAIgBABgABegLIABgCIAAAAIABAAIAAAAIACgBIABAAIgCACIgBACIgBABIAAAAQAAAAAAAAQgBAAAAAAQAAgBAAAAQAAAAAAgBgAgvgLIgBAAIAAgBIAAgBIAAgCIAAgDIAAAAIAAgBIABAAIABAAIABAAIAAABIgBAAIABADIAAACIAAAAIAAABIgBABIAAAAIAAAAIgBAAgAiCgPIgFgBQACgDgDgEQgCgDgCAAIABgDIAGAAIABAAIADADIgBAAIAAABIgBAAIAAAAIABABIAAAAIACAAIAAgBIAFABIAEAAIAAAAQAAADgDADIgDACIgFABIAAAAgAg7gQIgCgCIAAgBIgCgDQgEgDgEACIgCABIAAAAIgCgBIgEgEIAAAAQAAgGADgDIABgBQAEgDAFAAQAFAAAEADIADAEQgDAEADAFIABABIgCAEIgCABIABAAIgBABIgCABIAAAAgAhCgbIAAABIABgBIgBgBIAAABgAClgTIAAABIgBAAgACQgVIgCAAIgEAAIgDgCIgBgBQgDgEAAgEIABgGQADADADAAQAEAAAEgDIAAAAQAEgCABgDIACABIABAAQAEAEAAAFQgCAAgDACQgHAFADAGIgCAAIgDgBgACQggIAAAAIAAAAIABAAIgBgBgAAJgbIAAgBIABgBIACgDIAAgBIABAAIAAAAIACACIABABIACABIgBABIAAAAIgBAAIgDABIgBAAIAAAAIgDAAg");
	this.shape_1.setTransform(2.7,-1.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#009933").s().p("AhaBhIgBgEQgHADgFgIQgFgJAIgEQAEgCADABIADABIAEADQADADAAACQAHgCADAGQADAIgHAFQgDACgDAAQgEAAgDgFgAArBMQgDgEABgDQAAgDAFgDIABAAIABgBQAHgDAFAGQAGAHgIAGQgEADgDAAQgEAAgEgFgAAXBDIgCgCIgCgCIgBgBQgCgDACgDIAAgBIgFgBIgDgEIAAgCQgEgJAJgEIABAAIACgBQAEAAADACIACADIAAAAIADgFIACgCIADgCIgBgCIgBgCIAAgEIAEgEQAEgDAEAEIABABIABACQABAEgFAEIgCABIACADIADgBIAAAAQAAgEAEgCIABAAIACgBQAEgBAEAEIACgBIACAAQAFgBAEAFQAEAIgHAEQgGAEgFgDIgFABIgCAEIgDABIgDACIgCAAQgDAAgDgCIgCgCIgBAAIAAABIABABQAAADgBACIgBAAIAAABQABAEgCADIgDACIgFABIgDAAgAhJAxQgFgJAHgEQAHgEAFAIQAFAIgHAFQgDACgCAAQgEAAgDgGgAh7AtIgEgEIgBgBQgDgBgCgFQgDgHAGgDIACgCIAAAAQAIgDADAFIACABIAEADIABABQAFAHgFAFIgDADQgEACgDAAIgDgBgAimAdQgHgJALgDQAMgDACAHQAEAHgHAFQgCABgDAAQgFAAgFgFgAgPAZQgEgGAGgEQAHgFAEAHQADAHgGAEIgFABQgDAAgCgEgACgAVQgIgMALgHQALgGAHALQAHALgKAIQgEADgEAAQgGAAgEgIgAhRAaIgFgDQgEgEAAgDIAAgBQAAgEAEgCQACgCADABQAJgFAIAIQAHAIgKAGQgEACgEAAIgGgBgABpAVQgDgJAGgFQAFgFAFAGIACgBQAGgFAEAHQAEAHgHAEQgFADgDgDIgDADQgDACgDAAQgDAAgCgEgAhmAWIgCgCQgCgDACgCIABgCQABgBABAAQAAAAABAAQAAgBABAAQABAAAAABQAAAAABAAQAAAAABAAQAAABAAAAQABABAAAAQACAEgBACIgCACIgEABIgCgBgABDAWIAAAAIAAAAQgGgBgDgGIgBgCQgDgFACgEQABgEAGgDIAAAAIAGgDIAFAAIADABIAEAEIACACIACAFIAAAFQgBAGgHADIgHACIgDAAgAi5AJQgGgIAJgDQAJgFAFAGQAFAFgIAGQgDADgDAAQgEAAgEgEgAgTADQgCgEABgEQABgDACgCIAAAAIABgBIADgBIgCgEIAAAAIAAgBIgBgCIgBgBQgBgFADgDIAEgDQgEgHAGgGIACgBIABgBIAAAAIACgBIAAgEIgFADIgEACIAAAAQAAADgDACQgFAFgEgGIgBgBQgEgFAEgEIABgBQgDgIAJgEQAFgCAEABQAEABACAEQADADAAADIADgEIABgBIgCgCIgBgEIAAAAIgBgDQgHgJAIgDQAHgEAFAHQACADAAACIABACIABAAQAGgDAFACQAHgGAFAIQAEAIgFAEIAAABIACACIAAgCQgBgDAEgCQAGgEAEAHIAAAAQABAFgBADIgBABIgBABQgDACgCgBIgCgBIgCgBIgBgCIAAAAIgBgCIAAACIAAABIgDADIgBABIABABIAAABQACAEgBAEIgBABIACACIAAACIACgCIABAAQAGgEAEAHIABADIAAAAQABAFgFADIADADIABACQACAFgFACQgGABgEgFIAAgBIgCABIgBAAIgDAEQABAAAAAAQABAAABAAQAAABABAAQAAABABAAQAAABAAAAQABABAAABQAAAAAAABQAAAAgBABIgCACQgFADgCgDIgBgBIAAAAIgBAAQgBgDADgDQgHACgHgIIgBgBIgCgCIgBABIgFAEQgFACgCABIgDABIgBAAQADAEgBADQgBADgDACQgEADgCAAQgEAAgDgGgAANgnIgCABIAAADQAEABADAEIABABIAAAAIABAAIAAAAIACgEIgDgEIgCgFIgEADgABbgEIgBgCIgCgCIgBgDIAAAAQgBgFAFgDIABgBIACgBIABAAIAEABIADADIAAAAIAAAAIABgBQAGgEACAFIABADIAAACQAAAAAAABQAAAAgBAAQAAABgBAAQAAAAAAABIgEABIAAABQgBACgCACIgBABIgEABQgEAAgDgDgAingJIgEgDIgBABQgHAFgDgIIgCgEQgBgFAFgBIACgBIACAAIAFADIAAAAIAAAAIADgCQAIgEADAIIAAAAQADAIgFACIgBABIgDABIgBAAIgDgBgACBgNIgDgEIgDgFQgBgDABgDIAAAAIABgBIABgCIACgCIABAAIACgBIAEgBQAGAAAEAHIABACQABADAAADQAAADgCACIgBABIgCABQgDADgDAAQgDAAgDgDgABBgTQgFgIAEgDIABgBIACgBQAFgCAEADIABAAIADADIABABIABAEQABAEgFAEIgFABQgFAAgDgFgACmgRIgCgBIgDgEQgHgIAGgFIADgDIAAAAIADgCIAEAAIACAAIADABIACACIABACIABACIABACIABADQACAIgGADIgGACIgFgCgAhMgXQgFgLAKgFIAHgBQAAgDAEgCQAFgDAEACIAEAEIABABIABAAIACgBQAEgCAEADIACADIAAABIABACIABAAQABADgCADIgBACIgEACIgBAAQgJADgCgHIgBgCQgEABgDAAQAAAFgFAFQgEADgDAAQgEAAgDgGgAjCgbQgDgEACgDIgBgBIAAAAIAAAAQgIAGgHgJQgFgIAGgFIAEgCIABAAQAHgEAFAEIAAgBIAFgBIAAgDQABgEAFgBQgGgIAIgFQAIgFAGAIIAAABQADADAAACQAAAEgEADIgCABIABABIABADIACgDQADgCACACIACACIABACQAAABAAAAQAAAAgBABQAAAAAAABQAAAAAAAAIgCABQgDACgDgCIgBgBIAAAAIAAgBIAAABQgBAEgGACIABAGQAAAEgDADIgDABIgBADIgCADIgCABIgDABIgBAAQgEAAgCgEgABkgZIAAAAIgEAAIgCgCIgCgBIgDgDQgGgFABgEIgEgHQgHgPAMgGQAMgGAGAMQAEAIgEAHQAEACACAEQADAEAAADQAAAFgFADQgDABgCAAIgCAAgADJgiQgFgJAGgFIACgBIADAAQADAAADAEQAEAHgGAGQgDADgCAAQgDAAgCgFgAh5ghQgBAAAAgBQAAgBgBAAQAAgBAAAAQAAgBAAAAIABgDIADgEQAEgCADABQACAAACADQACAEgBADIgCADIgCABQgDACgCAAQgDAAgCgEgACxgnIgBAAIAAAAQgCgGAHgFQACgCADAAQADAAADAFQACADgBADIgBADIAAAAIgEACIgFACQgFAAgBgFgAhggrIgEgBIAAAAIgBAAIAAgBIgEgDIgBAAIgGAAQgEgCgDgFQgIgLALgFQADgBAEAAQADAAADACIADACQAHgFAHAMQAHALgHAFIgDABIgCABIAAAAIgEAAIgBAAgAiPg5IgBgBQgBABAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgDgBgCgEIAAgBQgDgEABgEIAEgDQAGgEAFAGQALgFAEAKQAEALgHAFIgDABIgCAAQgFAAgFgHgACgg5IgBgCQgFgJAHgKQAIgJAHAMQAFAHgCAGQgCADgDACIAAAAQgFADgDAAIAAAAQgEAAgCgDgAgvhDQgEgFAFgCQAFgDADAEQADADgFAEIgDABQgBAAAAAAQgBAAAAAAQgBgBAAAAQgBgBAAAAgADEhJQgEgIAHgGQAGgGAGAJQAGAJgJAFQgEACgCAAQgEAAgCgFgAhzhXQgGgJAIgEQAIgEAFAHQAFAHgIAGQgCACgDAAQgEAAgDgFg");
	this.shape_2.setTransform(-0.1,0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(102,255,0,0.298)").s().p("AhXBGIAAgGIgQgBIgGAAIgEAAIgPgCQgGAAgGgCQgBgFAEgEIAUgIQAEACAGgEIAEgCIAAAAIABACIADADIACABIACABQALAHAIAAIADACIAEAAQAFADgDAIIgGADIgFACIgGABIgDgBgAhvAuIgIAEIgGACIgDACIACAAIABAAIAPABIADAAIACAAQAKABAGgBQgGgBgHgGIgCgCIgBgBIgDgBIgDACgAAtA8IgFAAQACgDgBgEIADAAIgCgBQABgCAAgDIAJAEIABAAIgBABIABAHIgBABQgEACgBAEIgCAAQgBgDABgDgAASA6IgIgCQgBgEADgDIADgCIABgBIAEAEIgDACIACAAIABAAIAEAAQgBADABAEIgGgBgAAfAhIgBgNQABAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAgBIABAIIAAADIAAAGIgCgCgAATAVIACAAIABABIACAIIAAABIgCAAgAA7AXIgEgDIgCgCIgBgCIgBgBIAAgCIABgNIgBgEIAAgBIABABIAAgCQABAAAAABQAAAAABAAQAAAAAAABQAAAAAAABIAEACIAEABQgCAFADAFIgCAAIgBAAIgFAAIAAABIADAEIABABIAGAGIAEADIgCABQgEgEgEABgAA2AEIADgBIgDgBgAhtAVIAAgHIABAAIAAgBIABgCIgCgDIAAAAIgBgBIgBAAIgEgHIgLADIACAEIgBAAIgBAAIgCABQgCgFABgDIABgBQACgFAHgBIgDgGQgEgFgDgCIgBgBIgLgCIgKAAQgDgIgIAEIgDABIAAAAIgFgCIgCgCIgCgBIABgDIADgCIAAAAIACABIADABIABAAIAJACIADABIADAAQAEABABgBIgFgDIgCgBIgEgCIgDAAQAAAAAAgBQAAAAAAAAQAAgBgBAAQAAAAAAgBIgDgBIgEgCIgBgFQAFgCABgFIABABIAAAAIABABQACACgBADIABABIAJAFIAHAEIANAFIALADIAHABIAFABIgHgEIgCgBIgFgBIgHgDIgKgGIgHgFIgDgFIgFgEIgBgDIgCgBQgBgEABgDIABgCIABADIAHAJIAEACIADAEIAJAGIAIADIAEACQAAABAAAAQAAABABAAQAAABAAABQAAAAABABQAEAGAGgFIACgBIAEACIACADQABAEgBACIABABIAeALQAGADABACQACABAAAFQAAABAAABQgBAAAAAAQAAAAAAAAQgBAAAAAAIgEACQgMAAgMgCIgDgBIgEAAIgDgCIgGgBIgCAAIgFABIgCACQAHAIAAAPIAAACIgEgDgAhagMIgEAEIAIABIAFABIANAAIgVgHIgBABgAh4gRIADAEIACADIABAAIABgBIAAgCIgBgEIgDAAIgDAAgAhugPIAFACIABAAIADAAIACAAIAAgCIgCAAIgBAAIgBgBIgHgBgAh+APIACAAIACABIABADIgBAAIgCABgAAUASQgBAAAAgBQgBAAAAAAQAAAAAAgBQAAAAABAAIABABIABAAIgBAAIgBAAIAAAAIABABgAAaAQIACABIgBAAIgBAAIAAgBgAAfAPIgBgBIgCAAIgCgGIgHADIABADIgBAAIgBAAIgBABIAAgHIAAgBQACgEAFgBIgCgCIAAgBIgFgGIgBgBIgHgBIgBAAIgGgBIADgBQAEAAAEgCIAGgEIACABIABAAQAHAJAHgCQgDACABAEIAAgBIgEAAIAAABIADABIAAABIACAAIABAAQACABAFgCIADgCIABACIgDAAIgBAAIAAABIgBAAIgDACIgBACIgBACIgDAAIgBAAIgDABIgCABQADAEABAFIgBgBgAAcAAIAAAAIAAgBIgBgEIgEAAIACAEIABABIABAAIAAAAIABAAgAh3AMIgEgBIAAAAIAEAAIAGAAIgFABIgBAAgAhwALIABAAIAAAAgAh+ALIAAAAIAAgBIABABIgBAAgAAvAHIAAAAIAAABIgBgBIgBAAIgBABIgCgBIgBAAIABgCQAEgBABADIABACgABbgBIABgBIAAAAIABAAIAAAAIABAAIgCABIgBAAgACBgEIgGgDQgBABAAAAQAAAAgBAAQAAgBAAAAQgBAAAAgBIgEgBIgEgCIAAAAIAEgCQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAAAgBIADABIAFACIACABIAAAAQgBgCAAgDIgBgLIAAgCIgBgBIgCgFQgBgDABgCIADAEIAAgCQABAAAAAAQABABAAAAQAAAAAAABQABAAAAABIAAABIAAAAIgBACQAAAAAAABQAAAAAAAAQAAAAAAABQABAAAAAAQgBACABAEIACAIIAEABQAGAFAGgFIACgCIAGADIAAAAIABAAIAAAAIABgDIABgEIgFgBIgBAAQABgDgCgDIADAAIAEABIABAAIABABIABAAIAAACIAAAGIgCAFIABABIADACIgTAFIAAAAIAAgEIgDAAIgKgBIACABIABAAIADACIACABIABACIgHABIgDAAIgBAAgABMgJIgCgCIAAgBIgDgDIgBgCIgGAAIgBgCIABgEIgFAAIgDAAQAEgDgBgFIABAAIgBgBIgBgCQgEgHgGADIgDgCIgBgBQABgDgCgFIAEADIABAAIAEACQAJAGAJAEQgEAEAFAHQAGAJAHgFQAFgDgBgFIAJADIABABIgBAAQgFADABAFIgCAAIgCgBIAAAEIgEACIAAgDIABgEIgBAAQgDgBgDACIgBABIACAFIAAABIgEAAgAgKgPIgBgCQgDgEAAgDIABgDIAAgBIgKgDIgCgCQABgCgBgDIACgCIACAAIADgBIAEAAIAAABIAAACIAAACIAAABIAAABIABABIABgBIAAAAQABAAAAABQAAAAABAAQAAAAAAAAQABAAAAgBIAAADQgDADABAFIABAAIAAABIABABIAAABIAAABIACADIgDABIAAAAgABWgfIgDgDIACgEIgIgCIgNgBQAAAAAAAAQgBgBAAAAQAAAAAAAAQAAgBAAAAIABgFIAOABIAGABIADAAIABACIABAAIAAACIAAAIIgCAEIgBgBgAC+gkIgDgBIgDgBIgBgCIAAgBIAAgCIAAABQADAHAIgEIAEgCIgBAAIgFAFIgBABgAgMgkIABgCIgBgCIAAAAIAAgBIABAAIABADQAAAAAAABQAAAAAAAAQgBABAAAAQAAABgBAAgADIgsIAAAAIAAABIgCABIACgCgAhggvIgBgBIAAAAIABAAIAAAAIABAAIABAAIAAAAIAAAAIAAABIgCAAIAAAAgAgggyIAAAAIABAAIgBABIAAgBgACyg2IAAgBIAAgBIABABIgBABgAjHg5QAAAAABgBQAAAAAAAAQAAAAABgBQABAAAAAAIABgBIAHgBIAEgBIACAAIAAADIgEACIgBAAQgFgDgHADg");
	this.shape_3.setTransform(-0.7,0.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(51,51,0,0.298)").s().p("Ah8BRQgBgCABgDIACgIIAEAAIgDAHQADABAAADQABABAAAAQAAABAAAAQgBABAAAAQAAABgBAAIgBAAQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAAAgBgBgAhVBPQgBAAAAAAQAAAAgBgBQAAAAAAAAQAAgBAAgBIAAgBIAFgBIABADQAAABgBAAQAAABAAAAQAAAAgBAAQAAAAgBAAIgBAAgAARBLIAAgFIABgDIACABIgBACQABAAAAAAQABABAAAAQAAAAAAABQABAAAAABIgBADIgBABQAAAAgBgBQAAAAAAAAQgBAAAAAAQAAgBgBAAgAArA5IABAAIgBgBIgJgEIgBgBIADABQADADADAAIACABIAAgCIADgBIADgCIgFANIgBABIgBgIgAh0A8IgDAAIAFgKIABABIACACIgDAHgAhVA5QgIAAgLgHIgCgBIABgGQAFgGABgEIAAgBIgCAAQgEABgBACQgGgDAAgDQAAgEAEgBIgDgIQgGgJgCgFIAFgBIAHAOIAAABQgCADACADIACACIAAABQAGAAAFgCIgDgCQABgCgCgDQAAgBAAAAQgBgBAAAAQAAAAgBAAQAAgBgBAAIAAgBIACgJIADABIgBAFQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQABACADABIAAACQAAADAEADIAFAEIgCACIgMACQACAAABAFIAAAAIgCADIgEAHQgBAAAAABQAAAAAAABQAAAAAAABQAAAAAAAAIADACIAKADQAFABACADIgDgCgAhvAuQABgFACAAQAAABABABQAAAAAAABQAAAAAAABQAAAAAAABIgBACIgDgCgAAZAgIgBgCIAAgDIABgGIgEgKIADgBIACAFIACgEIABgDIABgCIADgDIABAAIABAAIADAAIgBgDQAAAAAAAAQAAgBAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAQgBAAAAgBQgBAAAAAAQgBAAAAAAIACgEIABgBIADAGIAEAFIAAAAIABAEIgBAPIAAACQgDgFgFAEIgDAEIgBgEIABgCIACgDIAAgBIAAgBIACAAIABAAIABAAIABAAIAAAAIAAAAIABABIgBgCQgBgDgEABIgBACIgCAEIAAAAIgCAFIAAABIACAGIAAAAIABACIABACIgDABIgCADIgCgEgAAmAgIACgBQAGgDgCgFIACACIABAEQgEACAAADIAAABIgCAAIgDgDgAA4AcIgGgHIAAgDQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAABIACABIAEABIAEADIACADIgDADIgCAAIgEgCgAAaADIAAgBIABABIgBAAgAAYADIgDgCIAAgBIAEABIAAAAIABAAIgCACgAAQADIgCgDIAEAAIABADgAgFADQABgDgDgFIABAAIAGABIAAAAIAHABIABABIAFAFgABygCIAGACIABABIgDAAIgEgDgACDAAIgBgCIACACIgBAAgACEgFIADAAIAAAEQgBAAAAgBQgBAAAAgBQAAAAAAgBQgBAAAAgBgAAvgGQAFgCgCgFIAPAHIACACIgHACIAAABgAhngDIAEgEIABAAQACACABADgABHgEIAAgBIAAAAIAEACIgBAAIgDgBgAgXgEQgCgBAAgDIAAgGIgBAAIgMgHIgCgBIAAgBIAAAAIAEgCIAAAAIANAGQAAADADAEIABACIgCABIABAAIAAABQgCACgBACgAiqgHIAEABIgCAAIgCgBgABQgLIACABIACAAIAAABIAAABIAAABIgBAAIgBAAIgCAAIAAgEgABHgKQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAgBAAAAQADgCADABIABAAIgBAFQgDAAgCgDgAhugKIACAAIAAACIgCABIAAgDgAhygIIgFgCIAAgCIAHABIABABIgCADIgBgBgAh+gHIgDgFIAGAAIABAFgAiigIQAFgDgDgHIAAAAIAKABIALACIABABQADABAEAGgAChgMIAAgEIACABIAAABIAAADIAAAAIgCABgACSgKIAAAAIgDgCIgCgBQACgCAAgDIABAAQABAAABABQAAAAAAABQABAAAAABQAAAAAAABIABABIgBADIAAAAIgBAAgABtgLIAAgCQABABAAAAQABAAAAABQABAAAAABQAAAAAAAAIgDgBgAAygSIAFAAIgBAEQgDgCgBgCgABjgPIABAAIgBAAgAgTgQIAAgBIABACIgBgBgAi7gQQgCgCgBgDIAEgCIABAAIACgDIACABIACACIgCAAIgCAAQgFACACAFIgBAAgABYgTIABgEIAAgDIACABIAAAGIgCABIgBgBgABcgTIABgDIAAgBIAAgBIAEABIAAAAIgBACIAAACIgEAAgAhqgUQABgCgBgDIABgBIAFgHIADgCQADgDAAgDIACgBIADgBIgBACQgCAGgGAHIgHAJgACOgYIgBgCQgEgHgGAAIABgDIAKAEIACACIABADIAAABIAAADIgDgBgAh+gZQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIAAgBIAFABIAAABIAEAEIgHgCgACxgdIADABIgCACIgBgDgAAygaIAAgBIABABgAikgaIAAgGIAEACIACABIgDADIAAAAIgDAAgAgSgdQAAABgBAAQAAAAAAAAQgBAAAAAAQAAAAgBgBIAAgBIAAAAQABAAAAgBQAAAAABAAQAAgBAAAAQAAgBAAAAIAAAAIACABIAAgBIABgCIABgGIAAgDIAAAAIADgCIAGgEIgBAEIgCABIAAABIgBAAIgBgBIgBAAIAAADQgGAFAEAIIgEADIAAgDgAAQgcIgBAAIACABIgBAAgAA4ggQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBIANACQAEACABACQgEgCgFACIgCABgAB4gfQAAAAgBgBQAAAAAAgBQAAAAgBAAQAAgBgBAAIAAACIgDgEQgBACABADIgDgBIgCAAQAAgDgDgFIAPAFIAGADIgCAAIgBABIgBAAIgCAAIAAAAIgBABIAAgBgAAkggIgCgDIABAAIABABIADACIgBAAIgBABIgBgBgAidglIACgBIABgBIgMgDIgBgBQABgDgCgCIgBgBQADADADgCIACgBIAGABIADAFIAHAFIgCACIgDADIgHgEgAjHghIAAAAIAAAAgACegnIABAAIABADIgDACIABgFgAgfgjIgBAAIABgBIABAAIADABIgDAAIgCAAIABAAgAiCgmIgDgCQgFgEgEgBIgFgCIgDgDIgBgCIAAgEQAAAAABAAQAAABABAAQAAgBABAAQAAAAABAAIABABQAGAJAGgCIABAAQAFAEADAFIgBADIgEgCgAC/gnIAAAAIAAABgAAwgmIgFgHIgBgBIABAAQACAAADgBIABgBIABACIAKgBIgJgCIgBgBQACgCgCgFIAAAAIAAgBIAOAHIAEACIABADIAAABIAAADIgOgBIgBAFgAAngpIgBAAIAAgDIADgBIAAgBIAAACQAAADACACIgEgCgADIgxIgBgDIABgEIAAgEIACgBIACAAQAAAAABABQAAAAAAAAQABABAAAAQAAABAAAAIAAACQAAABAAAAQAAABAAAAQAAABgBABQAAAAgBABIADABIgDACIgDABIgBgCgAiqgyIAAAAIAAAAIABABgAAlgyIAAgCIABACIAAAAIgBAAgAAjg4IACABIAAACIgCgDgAgGg7QgDgEgEgBIACgCIACAAIAHACIABAEIACACIgBABIgEAEQAAgDgCgDgAjOg4IABgFIAHADIAFABIgEABIgHABIgBABIgBgCgAifg+IgCAAIgBgDIgBACIgDgCQAAgDgCgCIAAgBIABgFIAAgEIADgCIADAAQADACABADIAAACQAAADgEACIAEABQgCADADAFIgDgBgAhwhGIAAgBQAAgBAAgBQAAAAABgBQAAAAABAAQAAgBABAAQAAADADADQgDgBgDAAg");
	this.shape_4.setTransform(0.2,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.CAlgaeSmall, new cjs.Rectangle(-21.3,-9.9,42.8,20.5), null);


(lib.CAlgaeLarge = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#336600").s().p("ABuAJQgCgEgDgBIABgCIABgBQABgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAIABAAIAAAEIACAEIAEADIgBACIgCACIgBABIgBAAIgBAAQABgDgDgEgAFwAKIgDgBIAAAAQgFgCADgJIABgCIABgBQABAAAAAAQABAAAAgBQABAAAAAAQABAAAAABIADABIAAABIABADIABAAIABAAQAAABAAAAQABABAAAAQAAABAAAAQAAABAAAAIgBADIAAABQgBAAAAABQgBAAAAAAQgBAAAAAAQgBAAAAAAIgBABIgCAAgAlygBIgDgBQAAAAAAAAQgBAAAAgBQAAAAgBAAQAAAAAAgBIAFgCQAGgDgCgGIABABIABADIAAAAQgBAEADAEIgBAAQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAIgBAAIgBAAgAgFgFIAAgBIgFgDIAAAAIAAAAIABgDIAAgBIABABIAAACIgBAAIAEACIABACIAAABIAAABIgBgBg");
	this.shape.setTransform(2.7,-2.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AB9BQIgCgCIgBgBIgBgDIABgBQABgCgBgDIAEgCQAEgDABgDIAAgBIADAAIAEABIADAAIACACIAAAAQAEADABAGIgBAFIgEAEQgDADgGAAQgGAAgDgDgACJBIIABAAIAAgBIgBgBIAAAAIgCgBIgBAAIgCAAIAAAAIgBACIgBAAIABABIABAAIACABIADgBgAHfBJIgEgCIAAgBIgBAAIgBgCIAAgEIAAgBIAAgDIACgDIAAgBIACgBIACgBIABgBIADAAIADAAIABABIACABIACABQACADAAAEIAAABIgBABIgBABIgCABQgDADACADIgFABIgEgBgAHjA/IgBABIABAAIAAAAIAAgBIAAAAIAAAAgAj5A2QgFgGgEADIgCACIgBACIAAABIgBAAIgBgCIgBgDIgBAAQAAgEACgCIABgBIADgCIABAAIADACIABAAIAFABIACgBQADADAAAFIgBAEIgCADIAAABIgCgGgADWA5IABgBIADABIgDAAgAHZAzIgCgBIgBgBIgBgCIABgCIABAAIADgBIACABIAAAAIABAAIABACIAAABIgBABIAAAAIgBABIAAAAIgCABgAHYAvIAAAAIAAABIABAAIABAAIABAAIAAgBIAAAAIgBAAIgBAAIgBAAgAkJAnIgCAAIgBgBIgBgCIABgCIABgBIADgBIABADIgBAAIgBABIAAAAIAAAAIABAAIAAAAIABAAIABABIAAABIABAAIAAABIgDAAgAE/AeIgCAAIgCAAIAAAAIgCgBIAAAAQAAgBgBAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAAAABgBQAAAAAAAAIABgBIABgBIABAAIABAAIAEAAIAGAAIABABIACAAQAAABAAAAQABABAAAAQAAAAAAABQAAAAAAAAIgBADIgBAAIAAAAIgBABIgBAAIABAAIgHABIAAAAIgCgBgAE/AaIACABIAEgBIgEAAIgDAAIAAAAIAAAAIABAAgAE9AaIAAAAIAAAAgAhvAeIgFAAIgBgBIgDAAIgBAAIgBgBIgBgBQAAAAgBAAQAAgBAAAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQABAAAAgBQAAAAAAAAQABAAAAgBIABAAIACgCIABAAIABAAIAAAAIAHAAIAIAAIABABIAAAAIABAAIABAAQABABABAAQAAABAAAAQAAABABAAQAAAAgBABQABAAAAAAQgBABAAAAQAAAAAAABQgBAAAAABIgBAAIgBAAIgCABIgIABIAAAAgAh3AZIACAAIABAAIAFABIAHgBIAAAAIABgBIgBAAIgHAAIgHAAIAAAAIgBAAIAAABIAAAAIAAAAgAHsAXIgCAAIgCAAIAAAAIgDgCIgBgBIgCgEIAAgDIAAgDIABgBIAAgCIABgBIAAgBIABAAIABgBIADgBIACgBIABAAIAAAAQAEABADACQACADAAADIAAACQAAAEgCADIgCACQgDABgCAAIAAAAgAHsAMIAAAAIAAgBIAAgBIAAAAIAAACgAHtAJIAAABIAAgCgAHjAJIAAgBIAAAAgAmjATIgBAAIgCgBIgBAAIgBAAIgBgBQAAAAAAgBQAAAAAAAAQgBAAAAgBQAAAAABAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAABgBIAAAAIABgBIABAAIABAAIAFgBIAGABIAAAAIABAAIABABIAAAAIABADIAAAAIAAACIAAAAIgBABIgBAAIgBAAIAAAAIgBABIgCAAIgDAAIAAAAIgDAAgAmjAPIADAAIAEgBIgEAAIgEABIABAAIAAAAIAAAAgAmlAOIABAAIgBAAgADvAOQgCgDgDgCIgBAAIAAAAIABAAQAEAAACADQADACAAADIgDABIgBgEgACYANIgBgBIACAAIAFgBIABgBIAAABIgBAEIgCACIgDABQABgCgCgDgAj5AMIgBgBIgDgCIAAAAIgBgBQABgDgBgDIgBgCIgBAAIABAAIAAgCIABgBIAAgCIABAAIAAgBIABgBIAEgBIACAAIAAAAIABAAQADAAADADQACACABADIAAABQAAAFgDADIgCABQgCACgDAAIgBAAIgBAAIgBAAgAj2ABIABgBIAAAAIAAAAIAAgBIgBACgAj1gCIAAABIABgBgAj+gCIAAAAIAAgBgACGAJIAAgBQAAgBABAAQAAgBAAgBQAAAAAAgBQABAAAAgBIABACIADACQAAAAABAAQAAABABgBQAAAAABAAQABAAAAgBIABACQgDgBgCACIgCAAIgBABIgCACIgBgDgACRgDIABAAIABAAIgBABIgBgBgABPgSIgBgCIgBgBIABgBQAEACADgCIABgBIABADIAAABIgCADIgBABIgFgDgADBgbIAAAAIgBAAQAAgBgBAAQAAAAAAgBQAAAAgBAAQAAAAABgBQgBAAAAAAQABgBAAAAQAAAAAAAAQABgBAAAAIAAAAIABAAIAAAAIADgBIADABIAAAAQABAAAAAAQABABAAAAQAAAAAAABQABAAAAAAIgBACIgBABIgBAAIgCAAIgBAAIAAAAIgDAAgAARgeIgBgBIAAAAIAAgCIAAAAIABgCIgBgDIAAgBIAAgBIABAAIABAAIABABIAAAAIAAAEIAAACIAAABIAAABIgBAAIAAABIgBAAIAAAAgAHDghIgBgBIAAAAQAAAAgBgBQAAAAAAAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQABAAAAAAQAAgBAAAAQABAAAAAAIAAgBIABAAIAAAAIABAAIACAAIADAAIAAAAQABABAAAAQABAAAAAAQAAABAAAAQABAAgBABIgBACIAAAAIgBAAIgCABIgBAAIAAAAIgDAAgAmUgkQgDgDAAgEQAAgDACgDQgBADADACIABABQAEADAGgCIABAAIACgBIABgBIAAABIAAAAQAAAEgDADIgCACIgBAAIgEABIAAAAQgDAAgDgDgAgFgkIgDAAQgEgBgDgCIgBgBQgEgEAAgGQAAgGAEgEIABAAIAFgDQADABADgCQAFABADADIAAAAQgBAEADAHIACAFIgCADIgCACIABgBIgEADQgCABgEAAIAAAAgAhTgkQgFAAgDgEIAAABQgEgEAAgEIAEgBIABAAQAEgCACgDIABgDIABgCQAEAAADADQAFADgBAFIAAACQAAADgEADIABgBIgCACQgDACgEAAIAAAAgAhVgwIgBABIABABIAAAAIACABIACgBIABAAIAAgBIAAgBIgDgBIAAAAIgCABgAETgkIAAgBIgBgBIAAgBIABgBIAAgCIgBgCIAAgBIABgBIABgBIAAABIABABIAAAAIAAADIAAADIAAABIAAAAIgBABIAAABIgBAAIAAAAgAD8gqIgDAAQgEgBgDgDIgBAAQgEgEAAgGQAAgGAEgEIABgBQAEgDAGAAQAHAAAEAEIgBgBQAEAEABAEIgCgCQgHgKgJAGQgGAEABAFIAEAGQAFAFAFAAIAEgBIgDADIgHABIAAAAgAnOgwIgBgBIAAAAIAAgCIAAAAIAAAAIAAgCIAAgBIAAgCIAAgBIAAgBIABAAIABAAIAAAAIAAABIAAAAIABAEIgBACIAAABIAAABIAAAAIgBABIAAAAIAAAAgABVgzIgBAAIgCgCIAAAAQAAgBAAAAQAAAAAAgBQAAAAABAAQAAAAABgBIABAAIABAAIAEgBIAEABQABAAABAAQAAABABAAQAAAAAAABQABAAgBABQABAAAAAAQgBAAAAABQAAAAAAAAQAAAAgBABIAAAAIgCAAIgCABIgCAAIAAAAIgFgBgABXg1IADAAIACAAIABAAIAAAAIgDgBIgDABgAnwg5IgBgBQgEgEABgGQAAgGADgEIABAAQAFgEAFAAQAHAAAEAEIAAAAIAAAAQgBADADAEIADAEQgBAFgDADIgCACIABgBIgDACIgBgDIAAAAQgDgDgGACQgEADACADIgGgDgAi3hAIAAgBIAEADIAAABIgEABIAAgEg");
	this.shape_1.setTransform(-2.4,-1.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#009933").s().p("ACwCEQgFgKAJgFQAIgFAFAIQAFAIgIAHQgEADgDAAQgEAAgDgGgABnBrQgDgFAFgDQAEgCAEAFQADAEgFADIgDACQgDAAgCgEgAEZBoQgEgGAIgFQAIgFAEAHQAEAHgIAEIgGACQgEAAgCgEgAC2BoQgFgHAHgFIABgBIAFgCQAEgBAEAFQAGAHgJAFQgEADgDAAQgEAAgCgEgABIBoQgDgFADgDQgEgIAIgFQAJgEAEAHIABAEIACgBQAGgDAEAGQADAGgHAEQgHADgCgFQgBADgEACQgEACgDAAQgDAAgCgDgAB0BiQgGgKAKgEIAHgCQAFAAAEAEIABACQAEAGgJAHQgEADgEAAQgFAAgDgGgAG9BbQgEgHAIgFQAHgFADAIQAEAIgIAEIgFACQgDAAgCgFgAj0BXQgFgGACgFQgEAAgDgGIgBgEIgCACQgIAGgIgJIgCgDQgJADgDgIQgCgDABgEIgBgBIgDACIgDABQgJACgHgKQgJgNAOgHQAFgCAFAAIADAAIAEACIACABIADADIABABIABACIABACIABAAIABgBIAAgCIACgBQAFgEAEAHIACAFQAAADgCACIgBABIgCABIAAACIACACIABABIAAABIABgBIABAAQAEgCADABQAEABACAEIABACIACgBQAEgDAEABQADABADAEIABACQACAFgDAEQAIgBAEAIQAFAKgJAGQgDADgDAAQgFAAgFgHgAIaBYQgEgFAGgFQAHgFADAIQADAJgFACIgDAAQgEAAgDgEgAC3BaQgEAAgCgEQgGADgEgGIAAgBQgEgGAFgFIAAAAIgBAAIgEACQgHACgCgIIgBgEQAAgEACgEIABgBIAAgFQABgEAEgDIACgCQAKgIAGALIAAABIAEABQADABADADIABAAIADAFQABAEgCACIgCACIgCABIgDAAIAAAEIADABQADABADAFQAEAJgJAFIAAAAQgDACgDAAIAAAAgAhwBTQgDgGADgGIgBgBIgBgEQgBgGAFgCIACgBIAAAAQgBgEADgDIACgDIAFgCIAFADIABACQAEAIgGAFQACACAAACIAAAEQADAJgIAFQgEADgDAAQgEAAgDgFgADRBTQgIACgFgIQgFgHAGgHQgCgEABgDIABgCIgBgCIAAgEIAAgBQAAgEACgCIABgBIADgCIAEgBIADAAIABABIAEACIAAAAQADAAADAEIAAABIABAAIADgDIACgCIAHgDIACgBQAHgBACAJQACAGgBAFQgBAFgFADIgBABQgEACgEgBIgBACQgDADgCgBQAEAIgIAGQgDADgDAAQgDAAgCgDgAHLBPIgCgEIAAAAQgEADgDgBQgJADgFgJQgEgIAEgFQgBgGAGgEIAAAAQAEgDADABQABAAABAAQAAAAABAAQAAABABAAQAAABABAAIADAAIABAAIADADIAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABgBAAIgBABIgDABIgBAAIgCAFQAEAAADADIABACIAAAAIABgBIABAAQAEgCACABIACAAQADABACADIACAFQAAAFgFADQgDACgDAAQgEAAgEgFgADlBNQgFgIAIgCIAGAAQAEABADADQACAEgBACQAAADgEACIgFABQgFAAgDgGgAHrBHQgFgIAIgHIABgBIABAAIAFgCIADAAQAEAAACAEQADAFgCAFIgEAFIgBABQgEADgEAAQgEAAgDgFgAA/BFIgBgBQgGACgEgGIgBAAIgBgDQgBgEAEgEIADgCIAAAAIAFgCQAFgCADADIACgCIABgBIACgBIADgCIAEgCIADgBIACgCIABgBIABAAIgBgBIgBAAQgDgBgBgDQgCgEAAgEIABgDIACgEIABAAIACgCQAEgBADACIACgBQAFgCAFAIIABAAIABADQADABABADIABAFIAAADIAAABQgBADgDACIgFACQABAEgBACIgBABIgEACIAAAEQgBAEgDACIgFAEIgCABIgFABIgCACIgCACQgEACgCAAQgGAAgDgHgAmYBDQgDgHAHgDQAGgDADAGQAEAGgIAEIgEABQgEAAgBgEgAjlA+IgBgBIgBgBQgCgDAEgDIABgBIABAAIgCgCQgDgEAFgDQAFgCADAEQADAEgFACIgEABIADADQADAEgEADIgCAAIgBABIgDgCgAECA5QgEgJAHgEQAHgFAFAHQAFAGgHAHQgEADgDAAQgDAAgDgFgAIWA2QgBgDAAgDQgFABgDgDQgEgFAHgIQAIgHAEAJIACAEQAFgBADAHQAEAJgIAEIgFACQgEAAgDgGgAHXA2IgCgDQgCgEADgDIACgBIABgBIACgBIAEgBIABAAIADgDIAAAAQAFgDADACIACADQACADgBADIgBADIgBABQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAIgBABIAAAAIgCAEIgBAAIgFABQgEAAgEgDgAE6AwIgBgBIAAAAIgBgCIgCAAQgFABgFgEIgEgEIAAgBQgHgLALgFIABAAIACgBQAEgBAEAAIACABQAFACADAEIABACIACAFQABACgCADIAAAAIgCACIACADIACgEIAAAAIABAAQAEgEADAFIABACIABACQAAAAAAABQgBABAAAAQAAABgBAAQAAAAgBABQgEACgDgDIAAAAIAAAAQAAABAAAAQgBABAAAAQAAABgBAAQAAABgBAAIgDABQgDAAgCgEgAg1ArQgGgIAJgFQAJgGAEAKQADAJgHAEIgFACQgEAAgDgGgAiIArIAAgBQgEgFAHgGIABgDIACgCIACgCQAEgBABAEIAAACIACAAIAAABIAEAEQADAGgCADQgCACgDABIgBAAIgFABQgGAAgDgEgAhyAlQgGgKAHgHIACgCIACgBQALgIAGAMIAAABQAGALgKAIIgDABIgDABIgCABQgGAAgEgHgAjpAqQgBAAAAAAQgBAAAAAAQgBgBAAAAQgBgBAAAAQgCgEADgCIACgCQAFgEADAFQADAFgFADIgFABIAAAAgAC4AqQgFgBgEgGIgCgEQgGAAgDgFQgFgIAJgEIAAAAIADgBIABgBQAEgBAEAEIACgBIAEgCIACAAIAAAAIACAAQADABACACIABACIAAgBQADAAACADIABABQAAABABAAQAAAAABAAQAAABAAAAQABABAAAAQACADgBADIgDAEIgCABIgBAAIgBAAIgDAAIAAABIgDADIgCACIgEACIgCAAIgBAAgADvAiQgIgMAMgGIABgBIAFgBQAHgBAEAJQAFAMgJAGQgDACgDAAQgGAAgFgIgAHuAjIgDgBIgBgBQgBgBAAgBQAAAAAAgBQAAAAAAgBQAAgBABAAQgEAAgCgEQgDgEACgFIABgBIgBgBQgDgDAAgDIgBgBQAAgDACgDIAFgDQADgCAEAAQADAAADADIACACIACADQADAIgBAEIABAAQAEgBADAEQAFAFgHAEQgGAEgEgGIgBgCIgDADIABAAIACACQADAEgFACIgEABIAAAAgAhOAeQgEgGAGgDQAGgDADAFQADAGgGAEIgEABQgDAAgBgEgAAsAhQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAgBAAAAQgCgEACgCIABgBIABgBIgCgBQgEgBgDgFQgJgLALgFIAHAAIgBgCIgCgEQAAgDADgCIABgBIACAAIgBgCIgBgCIgBgBQgBgDABgCIgBgBQgEgFABgEIACgEIABgBQAAgCACgDIACgCIADgCIgCgDIgBgDQgCgGAGgFQADgCACAAIAEgEIABAAIAAgBQAEgCADgBQACAAACACIACgBIABAAIADgBIABAAQAFgBACAGIAAADIAAAEQgBAEgEACIAAABIgCAAIgCABIgDAAIAAAAIAAAAIgFACIABABQAAACgCADIgBAAQgDADgEgCIgBAAIABABIABACIAFADIABACIABAAIADABIACADQADADgDADIgCACIgDABIAAAAIgBABIgEADIAAAAQACAGgGAEIgCABIABADIgBACIgDADIAAAAIgBAAIgCABIAEAEIABAAQAEABACACQADAEgCADQgBADgEACIAAABIgBABIgDABIgFAAIgBAAIACACQACAEgCACIgCABIgDABIAAAAgAHUAfIgBAAIgDgBIgDABIgBgDIgBgBIAAgBIAAgBIgBgCIAAgDIABgDIADgEQADgDAEACQADABACADIACADQACAFgDAEIgDADIgCABIgCgBgAj3AaQgEACgCgBIgDgBIgEAAIgEgEIgBgBIgBABIgCABIgFgBIgBgBIgDgCIgDgDIAAgBIgBAAIgBgBIAAgBIgBgDIgBgBIgBgCIgBgDQgBgEABgCIABgBQgEgBgFgFIgBgCIgCgDQAAgBAAgBQgBAAAAgBQAAAAABgBQAAgBAAAAIAAAAIABgCIAAgCQABgDADgDIADgCIAEgBIAEAAQADABABAEIABACIABADIABAAIABACQABAEAAADIgBADIgDADQADABACAEIAAAAIABACIABAAIACAAIAEADIACgBQAFgDAEAFIAAADIACAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAABAAIACgBQADgCADABQAFAAAEAGIACACQAHAMgMAEIgFACIgBAAQgGAAgDgGgAm2AfQgDAAgDgEIAAgBQgFgJAHgEIAEgBIAAgEIADgDIACgBIAGgCIADAAIACABIADAEIACAEQABAEgDADIgCADIgBAAQgDACgDAAIgBAEQAAACgDABIgEACIgCgBgACJAZQgGgJAKgHIADgBIgDgFQgDgEABgFIACgFIAEgFIACgBIACgBIAEgCIgDAAIgEgEIgCgEIAAgDQAAgBAAAAQABgBAAAAQABAAAAgBQABAAABAAIACgBIAAAAIAHADIABABQACAFgDADIgBABIgDACQAFgBADABIgBgCQgBgDADgDIACgBIAEACIABABIgBgBIAAgBQgEgJAGgFIAEgDIAEgBIADAAQABAAAAAAQABAAAAAAQABAAABABQAAAAABAAIACACIACAEIAAABQADAKgIAFIgBAAIgBABQgJAEgFgIQADAFgEADIAAAAIAAAAIgDABIACADIAAAAQAEgBACAEQAEAFgGAEIgEACQgCADgEADIgGAEIACADQAFAIgFAFIgBABIgDACQgDACgDAAQgGAAgEgGgADfAUIgDACQgJAFgEgKIgCgDIAAgEIgCgBIgDgDIAAgBIgCgEQgBgDACgDIADgDIACgCIABAAIAEgDIADAAIACAAIABABQADABACAEIABAEIADgCIABAAQABAAAAAAQABAAAAAAQABAAAAAAQAAABABAAIADADQAEAFgFAGIAAAAIADAEIACAEQABAEgEADIgEABQgDAAgDgGgAEaAVQgGgGAIgFQAIgEAFAHIACADIABADQgBADgEACIgGABQgEAAgDgEgAjaAQQgIgKALgGQALgHAGANQAHANgJADIgFABQgHAAgGgHgAE7AQIgBgBIgCgDIgCgCIgBgDIABAAIAAAAIABgBIABgCQAAAAAAgBQAAAAAAAAQAAgBgBAAQAAgBAAAAIABgBIABAAIgCgDQgCgEAAgCQAAgFAGgDQAFgCAFACIADADIABAAIAAABQADAEgBADQgBADgDACIgBABIgBAAIADACQADAFgCAEIAAAAIgEAEQgDADgDAAIgEgCgAhbAOIgBgCIAAgDIACgDQADgFAEAGQADAGgEADIgDABQgBAAAAAAQgBAAAAgBQgBAAAAgBQgBAAAAgBgAk+AFQgEgFAHgHIAFgCQAAAAABgBQAAAAAAABQABAAAAAAQABAAAAAAIABACIACACIABAFQAAADgCACIgCACIgEACIgCAAQgDAAgCgEgAGeAAQgFgIAFgFQgDgGAHgFQADgCADAAQAEAAAEAEQAFAFgCAEIgCACIAAAAIABACQACAEgBAEQgCACgDADIgBAAIgDACIgEABQgFAAgDgHgAB2ADQgDABgCgEIgBgCQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAIABgCIABAAIABgCIACgBIABgBIACgBQADgBACAAIgBgBQAAAAgBABQAAAAgBAAQgBAAAAAAQgBAAAAAAIgDgDIgBgBQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAAAgBIADgCIAAgBIAEgBIACABIABABIABgBIABgBQAEgDAEABQADABACAEQACAEgBADIgCAEIgCABIgFACIgBAAIAAABQACACAAADQgBADgFACIgDACIgEAAIgEgBgAgPgFQgHgOAMgGIAGgCQAHAAAEAIIAAAAIACAGQABAGgEAFIgEACQgDADgEAAQgGAAgEgIgAG8gBIgCgDIAAgDQABgEAEgDIACgCQAGgDAEAGIABACQADAFgEAFIgDABIAAAAQgEACgCAAQgEAAgCgDgAihgGQgFgGAHgDQAHgDADAEQADAEgFAFQgDADgCAAQgDAAgCgEgAD8gIIgEgCIgBgCIgBgCIgEABQgFAAgEgEIgBAAQgFgHAIgFQAHgGAHAIIACADQAEgBAEAFQAFAHgGAEIgFACIgBgBgAjUgNQgEgIAGgHQAGgGAHAIQAHAIgJAGQgEADgDAAQgDAAgDgEgAASgOIgBgBQgDgFABgEIACgDQgDgBgCgDIgCgCIAAgDIgDACIgDACIgDABQgCABgDAAQgFgBgEgFIgCgEQgBgEACgDIABgBQgDAAgDgDQgEgEAFgEIABAAIACgBIAAAAQACAAADADQADAEgDADIABAAQAHgDAFADIACABQABgDAEgDIABgCIADgDIAAAAIAAgBIgBgCIgCgCIAAgDIAAgEIAAgBQABgDAEgDQAIgFAFAFIADAFIACAFQAHgEADAIQADAIgFAEIgCABQgHADgEgFQgDACgDgBIgBABQABAEgBADIAAAAIgBADIgBAAIABAAIAFADIAAABIABABQACADgBADQAEABAEAEQAFAGgBAEIgDADIgDACQgEACgDAAQgFAAgEgFgABfgVIAAAAQgEgGAEgDIACgCIACAAQAGgCAEAGQAEAHgEADIgBABIgBABIgEABQgEAAgEgGgAEMgTQgDgDABgDQgKAFgEgIQgDgGAEgGIADgDIABgBIADgCQAGgDAFAJIAAABQACAFgBADQAGgEAEAGIACABQACAFgBADQgBACgDABIgGACQgEAAgDgEgAlFgWQgEgFADgFQgCgBgCgDQgDgEABgEIABgEIAFgGIABgBIAFgDQgEgHAGgDIAEgBIABgCIACgDIABAAIADgBIAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAIADgDQAHgEAHAGIABACQADAEgDADIgDACIAAABIgFACIgDAAIgCgBIgBAAIAAACIgCACQACADAAADQgBACgCADIAAAAIgCACQABAEgBADIgBADIgCADIADAEIABAEQABAGgFAEQgDACgDAAQgFAAgEgFgAnsgaQgEgHAGgEQAGgEADAHQACAGgFAEIgDACQgDAAgCgEgAizgZIgEgDIgCgDIgDgDQgCgFACgEIAAgBIAEgEQAFgDAEABQAFABAFAFIADAFQADAGgHAFIgBABQgEADgEAAIgEgBgAlrgfIgCgEIgFgFIAAAAIgCABQgHAFgFgIQgFgJAJgEIAFgCQABgDAEgDQALgIAKAOIABACIABgBIAFAAIADABIAEAEIABADQACAGgGADIgFACIgDAAQAAAFgEAEQgDADgDAAQgEAAgDgGgAnaggQgBgDAAgDQAAgDACgDIAAgBIAFgGIABAAIADgCIABgBQAIgEAGAKQACAFAAADQAAAFgEAEIgFADQgFACgEAAQgGAAgDgGgAF5gfQgDgGAGgFQAHgEADAGQADAHgHAEQgDACgCAAQgDAAgBgEgAj9giIgDgFQAAgEACgDQACgDAEgDQANgIAFAMQAGANgLAFQgEADgEAAQgGAAgEgHgAEUglIAAgBIAAAAIgBgFQAAgDADgDIACgBIABgBIAFgBIACABQgDgCgCgEQgCgEABgDIACgEIADgDIgCgDIgCgDQAAgFAGgEQAJgGACAJQACAFgCAEQAFAAADAFIAAABQACgEAEgCIADgBQAEgBADAAQAEABADAEQADAEgBAEIAAADQAAAAAAABQAAAAAAABQAAABAAAAQAAABgBAAIABABIAAABQAFAJgHAGQgDACgDAAIgFgBIAAAAQgEgBgDgEIgBgBQgHgHAGgGIgBgBIgBgDQgCAEgEADIgDABIgCABIgBABQgEABgDgBIADAEIAAABIAAAGQgBADgDADQgDACgDAAQgEAAgDgFgADUglIgBgCIgCgCQgEAAgDgFIAAgBQgDgEACgEIAEgDQAIgEAFAIIABADIACAAIADABIADAEQADAHgEADIgDACIAAAAIgDAAQgFAAgDgDgACFgoIgBgBQgDgHAGgGIABgBQAHgFAEAHIABACQAEAJgHAFIAAAAQgDACgDAAQgEAAgCgFgAHWgqIAAAAQgCgEACgDQACgDADgCIAEgBIAEAAQACAAACADQAEAGgHAEIgCACQgEACgDAAQgDAAgCgEgAhFgzQgDgFACgEQgBAAAAAAQgBAAAAgBQgBAAAAgBQAAAAgBgBQgCgEABgDIgEgEQgHgJAJgHQAKgHAFAKQAFAIgGAHIABABQADADgCAEQACABACAEQAFAJgGADIgEABQgEAAgDgFgAGMgvIgDgDIAAAAIgBgBQgDgEACgDIgDgCIAAAAQgIgHALgIQALgHAIAIIAAAAIACADIABADIgBAEIgFAEQADAFgBADIgBAAIgDAEQgCACgDAAIAAAAIgEgBgAmag0IgCgFIACgBQADgDAAgEIAAAAIADgBQAGgCAFAFQAGAHgJAGQgDADgDAAQgFAAgDgFgAivgzQgDAAgDgEIgCgDQgBAAgBAAQAAAAgBAAQAAAAgBgBQAAAAAAgBIgBgBIgDADIgCACQgDACgEgCIgBAAQgFABgFgGQgDgDAAgCQAAgBAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBIACgCQgBgGAHgDIADgBIAEAAIADAAQADABACAEIACACQACAFAAAEIACgBQAEgDACACIACAAIAJACIABABIABACIABACQAAAEgEAEIgBABQgDACgDAAIAAAAgAkHg2QgDgEAEgDQADgCACABIABACQABADgBADIgBABIgDACQAAAAAAgBQgBAAAAAAQgBAAAAgBQAAAAgBgBgACbg6IgFgFIAAAAQgBACgDABQgDACgDgBIgCgCQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBIADgEIAEgBQABAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQgBgEAFgBQAIgCAGAHQACADAAADIgBADIgCACIgBABIgBAAIgEABQgCAAgCgCgAC0g6IgDgCIgDgDQgGgIAIgGQAIgFAFAIQAEAIgEAEIgCACIAAAAQgDACgDAAIgBAAgAG+g9IgCAAQgEgBgEgEIgCgCQgJgMALgHQAMgIAHANQAHAMgHAGIgCABQgDACgDAAIgBAAgAHShFQgFgLAHgEQAHgEAGAKQAEAKgEAEIgCACIgCAAIgDABQgEAAgEgIgAh/g9IgGgDIAAAAIAAAAIgBgCQgFgFAEgEIAEgCIADgBQgCgEAGgDIAEgCIADgCQAEgCADABIABgBIAEgCQADAAACAEIAAABQACAEgDAEIgBABIgBADQgBAEgEABIgBABIgFABIgBgBQgBADgEADQgDACgDABIgBAAIAAAAgAgKhDIgCgFQgDgGABgEQABgDADgCQgFgIAHgDQAHgCAFAHQAFAGgDAEIABACIAAAAQAGAJgGAFIgEACIgGACQgEAAgDgEgAmOhEQgFgGAHgGQAGgFAFAIQAFAIgHAEIgEACQgEAAgDgFgAmlhCIgBAAQgDgCABgDQABgCAEgDQADgCADAAQADABADADQADAFgDADIAAAAIgDABIgBABIgEABQgEAAgCgDgAlWhBIgDgCIgCgDQgFgIAHgJQAHgIAHAJIADADIADAHQABAIgHADIgGABIgFgBgAm4hEQAAAAgBgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgCADgCQAFgEADAEQADAFgFAEIgDACIgBAAQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAgBgBgBgAnShDIgBgBIAAAAIgBgDIAAgCIADgDIABAAIACgBQADABABACQAAABABAAQAAABAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAIgDACQAAAAgBgBQAAAAgBAAQAAAAAAAAQgBgBAAAAgADlhJIgEgFQgBgFAGgEQAJgHAHAKIACADQAEAHgHAFIAAAAIgCABIgDABIgBAAQgFAAgFgGgAn5hKIgCgBIgBgBIgBgBQgCgDAFgCQAFgDADAEIAAAAIABADIAAABIAAABIgCABIAAAAIgEACIgCgBgAjnhLQgDgBgDgEIgDgFQgCgEADgDIAGgFQAFgCAEAAQAGAAAEAHIABAEIABABQABAHgIAEIgEACIgDAAIgFgBgAAjhTIAAAAQgEgFAFgDQAFgDADAGQACAEgCACIgCABIgDABQgCAAgCgDgAA1hSIgDgEIgCgGQAAgFAGgDQAJgDAEAIQACAFgCADQgBADgDACQgCACgDAAQgCAAgDgCgAmshXQgFgIAHgEQAIgDAEAGQAEAFgDAEIgDADIgCABIgCABQgEAAgEgFgAjGhVIgEgCIgCgDQgFgHAFgFQgEAAgDgEQgIgHAKgIQAKgIAHAIQAIAIgKAHIADABIADgDQAFgEAEAHQACAEAAADIgCADQgDACgDgBQAAAFgFADQgDACgCAAIgBAAIgCgBgAgdhVIgEgEQgFgGAHgEQAHgEAEAGQAEAGgGAEIgBABIgEABIgCAAgAnphaIgDgDQgDgEABgDIAAAAIAAAAQABgDAEgDIADgBIgDgEQgFgIAJgEQAJgDAEAJQgEgLAKgGQALgHAHANQAGANgLAIQgKAIgHgOIgBAAQACAGgHACIABABQAGAGgJAGQgFADgDAAIgDgBgAD8heQgFgIAHgDQAEgBADABQAAgGAIgFQAKgHAEAJQAEAJgKAHQgHAEgEgBIgDADQgCACgDAAQgDAAgDgEgAiQhbQgFgBgEgFQgDgDAAgDQgHACgCgGQgEgHAJgGQAKgHAEAJQACADAAADQAGgDAFAHQAFAJgJAGIgCABIgDABIgBAAIgBAAgAC9hjQgHgKAMgGQAMgGAHAJQAIAJgNAHQgFADgEAAQgHAAgDgGgABEhkQgDgGAGgEQAFgEAEAFQAEAGgHAEQgDACgCAAQgDAAgBgDgAA1hyQgEgHAGgDQAGgEAGAHQAFAIgHADIgFACQgEAAgDgGgAolh4QgDgJAIgFQAIgFAFAJQAGAJgLAGQgEACgDAAQgFAAgBgHg");
	this.shape_2.setTransform(-0.5,0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(102,255,0,0.298)").s().p("AhgBVIgCAAQAAgDgCgCQAGgEgEgIIgBgDQAJAFAHAAIADACIAGABQAFADgEAKIgHAEIgGABIgKACQgCgDACgFgAB8BbQgDgBgCgCIgBgFIgBgDIgLgBIgHgCIgGgBIAAgFIAEgCIABADIABABIACACQADADAGAAQAGAAADgDIADgEIADABQADABgCAGIgDABIACABQACAAAEgBIACAAIADgCIADgCIADgBIgDgDIgJgKQgDgFgBgJQAAgGABgEQADACAAAEQABAIACADIAHAIIAGAHIAEACQgCAEAAAFIgDgCIAAABIgGAGIgFACIgHADIgDAAgAh8BTIgEAAIgTgCIgOgCQgCgHAFgFIARgHQAEAGAKgDIgJAEIgHADIgEACIADAAIABAAIASABIAEAAIACABIAFAAIAAABIgBAAQgGADABAGIgEgBgAFDBJIgNAAIgFgBIgDAAIgMgCIgKgBQgBgGADgEIAJgEIAAAAIAEAFIgDABIgDACIACAAIABAAIAMABIADAAIABABIAAAAIAAAAQAEAGAFgDQABAAAAgBQAAAAABAAQAAgBAAAAQABgBAAgBIAAAAQADADAEgCQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIACABIADABIADABQAEACgDAIIgEADIgEACIgHABQgBgDABgEgAHUBOIgDgCIgBgEIgBgDIgHAAIgBAAIAAgBIAEABIAEgBIADADQAGAGAHgEIAAAAIgBACIgDABIgFACIgCAAgAAsBOIgMgBIgKgCQgBgFADgEIAEgDIAPgHIgCgBIgCgEIADgBIACgBIABAAIADACIgBgLIADgBIAAADQgBAJACADIABACIADADIACABIABABIAIAFIgCACQgDgEgGACIgCgCIgCgCIgBgBIgCgBIgDACIgGAEIgFACIgDABIACABIABAAIAMABIABAAQgEADABAEgAHiBFIAAgBQABAAAAAAQABAAAAAAQABAAAAgBQABAAAAAAIACgBQACACAAADIABABIgBABIgCABIgGgFgAC8BIIAAAAIgEgFIAAAAIAAgDIAAgCIACgFIABgBIADgEIgDALIADADIABADIABACIgBACIgDgBgAmfA+IgNgBIgFAAIgDgBIgMgBIgJgCQgCgFAEgEIAEgDIACgBQADAEADABIgCABIgDABIACABIABAAIAMABIACAAIABAAQAJABAFgBQgFgCgGgFIgCgCIAAgBIgDgBIgCACIAAgEQAEABADgCIACACIACABIACABQAJAGAGABIACABIAEABQADADgCAIIgFADIgEABIgHACQgBgDABgEgABuBEIgDgBIgBAAIAAgBIAAAAIACgCIAAAAIACAAIABAAIACABIAAAAIAAABIAAABIgBAAIgCABIAAAAgAhzBBIgDgCIAAgBIgEgCQADgDgEgGIgDgEQABABAAAAQABAAAAAAQABABAAAAQABgBAAAAIgCgZIABAAQAAgBABAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAgBgBQAAAAgBgBIgBAAIgBAAIgFgLQgGABgHAEQABABABAEIgCAAIAAAAIgDACQgCgHABgFIABgBQADgFAIgCIgEgHQgEgGgEgCIgCgBIgNgDIgEAAIgDgFQgFgFgFgBIAEABIADAAQAGABABgBIgHgEIgBAAIAAAAQAFgEgBgFIAHAEIAQAGIANAEIAJACIAGABIgJgFIgBgBIgGgCIgJgEQgGgCgHgFIgIgGIgEgFIgHgHIAAgBQgEgHABgFIABgCQABABAAAAQAAAAAAABQABAAAAABQAAAAAAABIAJALIAEADIAEAEIALAHIAJAEIABAAIAGADIABABIAGACIAFABQAGADACACIADADQACAFgCADIACABIAkANQAHADACADQACACAAAFQAAABAAABQAAAAgBABQAAAAAAABQgBAAAAAAIgFACQgPAAgPgEIgEgBIgEAAIgEgCIgHgCIgCAAQgEAAgDACIgCACQAJAKAAATIAAAFQgHAHAGAJQAFAIAGgBIACABIABABIgEACIgDACIgDgCgAhkgJQgCADgDACIAJACIAHABQAFABAKgBIgZgJIgBABgAiJgPIADAFIADADIACABQAAAAAAAAQAAAAABgBQAAAAAAAAQAAAAAAgBIAAgCIgBgFIgEAAIgEAAgAh9gOIAAACIAGACIABAAIAEAAIADAAIgBgCIgCgBIgBAAIgBgBIgGAAIgDAAgAkRBBIAAgFIAAAAQABgDAAgCIABgBIACgDIAAAAQACACgBAEIgCABIABABQABAAAAAAQABAAAAAAQABAAAAgBQABAAAAAAIACAAIACgCIACgBIABgBIgBgCIgGgJIAAAAIADAAIADABIAAABIAEAFIAFAEQADACAAADQAAABAAAAQAAABAAAAQAAABgBAAQAAAAgBABIgHgGIAAABIgEAFIgDACIgBAAQgDgBgEACIgCgBgAG7A/QgCgCABgEIAAgCIACgFIABgGIACABIABABIgDAKIADADIABAEIABACIABAAIgEABQAAgBgBAAQAAgBgBAAQAAgBgBAAQAAAAgBAAgADXA+IgBgBQgCgEgBgHIABgHQABAAAAABQAAAAAAABQABAAAAABQAAABAAAAQABAHABACIADAEIgEACgAE7A6IADgDIACACIgCADIgDgCgAHKA7IAAAAIAAgBIABAAIAAAAIAAABgAHaA6IgCgDIgCgKQADgEgDgFQABABAAAAQAAABAAAAQABABAAAAQAAABAAABQABAGABADIAEAEIgDAEIgBAAgADEAzIAAAAIABgBIAEgEIAAABQABABAAAAQABABAAABQAAAAAAABQABAAgBABIgBABQgDAAgDgCgABrAzIgBgEQgCgEgCgBIgCgCIAAgBIACABIABAAQAGACACACQADADAAADIgCACIgFgBgAiQAYIADAAIABABQACAGAEAHIABAEIgCABIgCACgAHFAsIAAAAIABgBIAAACIgBgBgAHBArIAAAAIgBgBIAAAAIAAAAIABAAIACAAIAAAAIAAAAIgCABIAAAAgAknApIABgCIACgGIABAAIACABIgDAJIgDgCgAAkAoIACABIgBAAIgBABgAG7AlIgCgEIgDgDIgDgCIgBgFIABgOIAAgFQABAAAAAAQAAAAAAABQABAAAAABQAAAAAAABIAAACIAAADIAAADIABAGIACAEIABABIAEAGIAIAFIAAADIgBAAIAAAAIgDgBIgCABIgBAAIgDgDgAEmAkIAAgDIgDgIIACAAIABAAIAEALIAAABIgDABIAAABgAEyAkIgBgJIABADIACACIAAAEIAAABIgCgBgADBAdIABgBIAAgCIABgDIADADIgBADIAAABIgDAFQgBgCAAgEgABRAhIgDgCIgEgDQgCgDAAgDIACgRIgCgFIAAAAIACAAIAAgBQAAAAABAAQAAAAABABQAAAAAAAAQAAAAAAABIAFACQAFADABACQACABAAAFIAAABQAAABAAAAQgBAAAAABQAAAAAAAAQAAAAgBAAIgDACIgBAAIgFAAIAAAAIADAFIABABIAHAIIABAAIgCABQgEgCgDABgABMALIAEgBIgEgBgAkgAfIgBAAIAAAAIgBAAIABAAIABgBIABAAIAAABIgBAAIAAAAgACwAeIABgOIAAgGQABAAAAAAQAAABAAAAQABABAAAAQAAABAAABIAAAHIABAGIABADIgFABIAAgBgAkmAaIgDgEIgDgDIgCgDIgBgEIABgKIABAEIABADIACAEIABABIAFAHIAAAAIACAEIABACIAAAAIgCABIgBABIgCgDgAHDAWIABAAIAAgCIACgFQAEgEgDgFQAAgFgCgCIAAAAIgDgDIgBgCIgFAAIAAgCIAAgEIgDAAIgNgCQAAAAgBAAQgBAAAAAAQgBAAAAgBQAAAAgBAAQgBgCABgFIgCgNIAAgCIgBgCIgDgGQgBgEACgCIADAGIAAgDQABAAAAAAQABABAAAAQABABAAAAQAAABAAAAIABACQgBAAAAAAQAAAAAAABQgBAAAAAAQAAAAAAABQAAAAAAAAQAAABABAAQAAAAAAAAQABABAAAAIAAAAIABABIAEADIABABIADACQALAIALAFIABAAIABABIAAgBIABgEIABgEIgGgCIgKgBIgBgCIABgFIALABIAFABIACABIABABIAAAAIABABQgCADABAEIABABIgBABIgBAFIAAACIALAEIAEACIAEACIAMAGIADABIAGACQAEADgDADQgCABgDgCIgCgBIgTgIIgCAAIgGgDIgBABIAAABIgCgBIgCAAIAAADIgDACIAAgCIAAgEIAAAAQgDgBgCACIgBAAIABAFIABAFIgBADIABADIgBAFIgCAGIAAABIgDAFQgBgCAAgEgAGsgVIAJABIAFAAIgJgGIgEgDIgDgDIACALgABiAVIABgBIABgCIACgIIACgFIAAgEIAAgBQAEgEgEgGQgFgHgGACIgFAAIgBgCIABgFIgGAAIgGAAIgIgBIgEgBIgBAAIgBAAIAAgBIgBgDQADgCgBgDIAFABIACAAIAHAAIAHAAIgJgFIAAAAQADgDACgEQANAIAOAFIABAAIACABIAAgBIABgEIADgGIgKgCQgHgBgJAAQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAAAAAgBQAAgDABgDIARABIAIABIADABIABACIABAAIABADIgBAJIgCAHIABACIAKAEIAAAAQAFAJAHgFIAGACIgDAAQAAABgBAAQgBAAAAAAQAAABgBAAQAAABAAAAIgBAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAIgCACIAAgBIgFgBIAAAAIgBABIgBABIgDgBIgDgBIAAAFIgEACIAAAAIgBgDIABgFIgBAAQgEgBgDACIgBABIABAHIABAJIAAAHQgBAAAAABQAAABAAAAQAAABAAAAQAAABAAAAIgDAHIAAABIgEAGQgCgCAAgFgAm+ANIACABIABAAIADAJIgDACgAAtASIACAAIABAEIgDgEgAEpAWIgCgBIgBAAIgBAAIAEAAIAEAAIgDABIgBAAgAElAVIgBAAIABAAgAiMAUIgBAAIgCAAIgBAAIABgBIABAAIAAAAIAHAAIAHAAIABAAIgBABIAAAAIgHABIgFgBgAmwATIgBgGIABgBIABAAIAAgCIAAAAIgBgDIAAAAIgCgBIAAAAIgBAAIgDgHQgEABgEACIABAEIgBAAIgBAAIgBABIgBgIIABgBQACgFAFgBIgCgGIgGgHIgBAAIgCgBQAAgEgDgFQgFgKgIAEIgCAAIgCgBIgBgCIgCgCIgGgCIgCAAIAAADIAAABIAAABIABACIABABIAEACIAEABIgFAGIgFgEIgCgBQgDgFAAgFIACgDIAAgBIgNgEQgFgDAAgDIAAgBIABgCIABAAIABgBIAFgBIADgBIAGAAIAAABIAAACIAAABIAAACIAAAAIAAAAIAAACIAAAAIAAABIABAAIABgBQAAABABAAQAAAAAAAAQABAAAAAAQABAAAAAAIAFgCQAAAAABAAQAAAAABAAQAAAAABAAQAAABABAAIABADIAAAAIABABIgBABIABACIAHAEIAGAEIAKAFIAJADIAFACIAEAAIgFgEIgBAAIgEgCIgGgDIgIgFIgGgGIgCgDQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQgCgDgCAAQgDgFABgEIABgCIABADIAGAJIACACIADAEIAHAFIAHAEIAEACIAFACIADABIAFAEIACADQABADgBADIABABIAYAKQAFADABACQABABAAAFQAAABAAABQAAAAAAAAQAAABgBAAQAAAAAAAAIgDABQgKAAgKgCIgDgBIgCAAIgDgCIgFgBIgBAAIgEABIgCACQAGAHAAAOIgDAAgAmhgNIgDAEIAGABIAEABIAKAAIgRgHIAAABgAm6gSIADAEIABADIACAAIAAgBIAAgCIAAgEIgDAAIgDAAgAmxgRIAAABIADACIABAAIADAAIACAAIgBgCIgBAAIgBAAIgBgBIgDAAIgCAAgAEwASIgBgBIgDgIQgEABgFADIACAEIgBAAIgBAAIgBABIgBgIIAAgCQACgEAGgCIgDgEIgFgHIgBgBIgJgCIgCAAQgEgFgGADQABgDgCgEIACAAIACABIABAAIAAAAQAFAIAHgFQAEgDABgDIABABIAJADIAGABIAEABIgGgEIgBgBIgEgBIgGgDIgDgCIgBgCIgDgDQADABAEgCIAEACIAFADIAEACIACABIABABQAEADAEACIAAAAQABAEgCACIACABIAXALQAFACABABQACACAAAFQAAABAAAAQgBABAAAAQAAAAAAABQAAAAgBAAIgDABQgIABgIgDQABgDgDgEIAAAAIAEABIAKAAIgRgHIgBABIgBACQgEgCgGACQgFADAAAEIgBABQACAEACAFIgCABIgBAAgAEogGIACAEIACACIABAAIABgBIAAgBIgBgEIgCgBIgDABgAEwgGIAAACIAEABIABABIACAAIACgBIAAgBIgCgBIgBAAIAAAAIgEgBIgCAAgAAfAQIAAgBQACgDACgCIABAFIABABIgGACIAAgCgABEAPIgBAAIAAABIgBgBIgBAAIgCABIgBgBIgCAAIACgDQAEgBACADIABADgADxANIgCgBIgTgJIgCgBIgGgCIgBABIAAAAIgCAAIgCgBIAAAEIgDAAIAAgBIAAgDIAAAAQgDgBgCABIgBABIABAFIAAAAIgCACIgCgDIAAgBIgDgDIgBgBIgFAAIAAgCIAAgEIgDAAIgDAAQAIgFgDgJIAOAHIABAAIABABIAAgBIABgDIABgFIgGgBIgKgBIgBgCIABgFIAJABIABAAQADAFAEAAIABADIACABIgBADIgBAGIAAABIALAFIAEACIAEABIADACIAAAAQAEAEAFgBIADACIAEABIADADQACACgCADIgBAAIgEgBgAA0AMIAAAAIgBgEIABgBQAGgDgBgGIAAAAIAEgDIACABIAEAHIgEAAIAAAAIAAAAIgCABQgCABgCADIgBACIgBADIgDgBgAm4AKIgDAAIgBAAIAAAAIAEgBIAEAAIgEABIAAAAgAm9AJIAAAAIAAAAgAHUAFIAAABIAAABIgBAAIABgCgAAlAFIgBgCIgCgDQACgDgFgFQgEgFgFgBQACgCgCgEIAAAAIAJAEIADABQgBAEAEAFIABABQgBACABADIAAAAIAAAAIABACIABACIgBABIgCABgAHVAEIAAgBIAAACIAAgBgACrACIAAgBIgDgBIgFgBQADgDgCgFQAFAJAIgFIABABIACACQACACgDACIgBABIgCAAIgFgBgAkugHIABACIAAABIgBACgAjvgEIgCgBIgTgJIgBgBIgGgCIgBABIgBAAIgCAAIgCgBIAAAEIgDABIAAgCIABgEIgBAAQgDgBgCACIAAABIABAFIAAAGIAAAAIgCgCIAAgCQgCgFgCgBIgBgBIgBgCIgFAAIgBgCIABgEIgEAAIgMgBIgDgBQABgDgCgEIACgBIABgBIABADIAJAAIAEAAIgJgGIgDgCQABgDgDgDIACgBIABAAIACABIACACQALAIAMAFIAAAAIABABIAAgBIABgDIACgFIgGgBIgLgBIgBgCIABgFIALABIAFAAIACABIABABIABAAIAAADIAAAHIgCAGIABABIALAFIACABIACAGQAIAKAKgGIAHADQADACgCAEIgCAAIgEgBgAkNgFIAAAAIgBABIAAABIABgCgACYgFIAAAAQADgEgDgFIAAAAIAGACIABABIgCABQgDADABADIgDgBgAkNgHIABAAIgBABIAAgBgAAIgHIgBAAQgHgCgDgEIAAAAIADgCIACgCIAAABIADAAIABADQADADADAAIgCADIgCAAgACjgKIAAAAIABABIgBgBgAAhgUIgIgFIgFgFIAJABIABAAIAAAAIABAAIAAAAIAGAEIABAAIABAAQgCADAAADIgBAAgACkgdIAAgCIgBgBIgDgGIAAgDIACgCIACAEIAAgDQABABAAAAQABAAAAABQABAAAAABQAAAAAAABIABABQgBAAAAABQAAAAAAAAQgBAAAAABQAAAAAAAAQAAABAAAAQAAAAABAAQAAABAAAAQABAAAAABIAAAAIABAAIAEADIAAAAIgEACIgEACIgBgEgAEMgaIgDAAIAAgDIgDgBIgGgCIgBgBIgBADIAAACIgDACIgBAAIAAgEIABgEIAAAAIgMgFQgGgCAAgDQAAgBAAAAQAAgBAAAAQABgBAAAAQABgBAAAAIABgBIAFgBIAEAAIAFAAIAAABIABACIgBACIAAABIAAABIAAABIABABIABAAIAAgBQABAAAAAAQAAABABAAQAAAAABAAQAAgBABAAIAEgCQABAAABAAQAAAAABABQAAAAABAAQAAABABAAQAAABABAAQAAABAAAAQAAABAAABQAAAAAAABIABABIAGAFQgEACAAAEIgBgBgAjJgfIgCgCIgDgFIABAAQADABAEgBIAAAAIADABQAAABABAAQAAAAABAAQAAABAAAAQABAAAAAAIABAAIALACQgFAAgEADIgEAEQgFgCgDgDgAgPghIAAABQACgDgDgEQgCgDgCAAIAEgBIAEgBIAFAAIAAABIABADIgBACIAAAAIAAACIAAAAIABABIABAAIAAgBQABABAAAAQAAAAABAAQAAAAABAAQAAAAABAAIAAADQgGgEgIADgAEZgiIgDgDIgDgEIgFgGIAAgBQgCgFABgEIAAgBIABACIAGAJQgBAEACAEQACADADACIgBAAgAgEgmIAAgCIAAgEIAAAAIAAAAIABADQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAgAD9gsIAAgDIAAgDIAAAAIAAgBIABAEQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABgAjCg6IgBgDIADgBQAEAAADADQADACgBAEIABABIgBABQgDgDgEADIgBABQAAgEgDgEgAhtgzIAAAAIgBgBIABgBIACgBIADABIAAABIAAABIgBAAIgCABIAAAAIgCgBgAA2g1IgBgCIgBgBQgDgEgBgDIAAgCQAFAEAFgEIABACIAAACQAAABAAAAQgBAAAAAAQAAABAAAAQAAAAAAABIAAAAIACACIABABQgDAAgDADIgBAAIAAgBgAjgg3IgEgCIAEgBQAIgEgCgHIADgBIAIAAIAAABIAAAEIgDABQgHADAAAFIgBACgAk/g4QgBgEABgDIAEAGIgBABIgCACIgBgCgAnlg4IABgCIgBgEIAAAAIABAAIABADQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAgAk7g8IACACIAAABIgCAAIAAgDgABDg6IgBAAIgDAAIADgBIACABIAAAAIAAAAIgBAAgAjLhCIAAgBIACAAIAAABIAAABIgCgBgAj6hNQgDgDAAgDQAAgEADgDQAEgCAFAAQAFAAADACQAEADAAAEIAAABQgEAAgFADIgGAEIgGgCg");
	this.shape_3.setTransform(0.1,-1.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(51,51,0,0.298)").s().p("AC0BoQADAAAEgCIAAAAIAAABIgFACIgBABIgBgCgACFBkQgDgEgGAAIAAgCIgCgKQACACADABIABAHQAFADAAACIABABIAAABIgBgBgAiABfQgBgCABgEQAAgEADgGIAEABIgDAIQADABABADQABAEgDACIgBAAQgDAAgCgDgAD6BhQgCgCAAgDIgEgBIAAAAQABgDgDgDQgDgEgEgBIAAAAIABgCIABgBQAFgDABgFQABACAAADQgBAFgDACIACABIAFACIACAAIACAFIABADQABADgCACgACjBhQAAAAgBgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIAAgHIADgCIABgBIABABQgFAEADAHIABABgABoBYIgDgFIgGgDIgBgBIgCgBQADgDABgDIAGABIADAEIADAFQACACAEAAQAFABABACQACACgCAFQgLAAgFgGgABPBVIgBABIACgCIAFgCIAAAGQAAAEgEABIgCgIgAhQBcQgBAAAAAAQgBAAAAAAQAAgBAAAAQgBgBAAAAIAAgCIAGgCIABAEQAAABAAAAQAAABgBAAQAAABAAAAQgBAAAAAAIgCgBgAH8BaQgCgBAAgEIgBAAIADgEIABABIABADQABAEgCABgAAtBYQgBgCABgEIACgIIAAAAIACAEIgBADQAAABABAAQAAAAABABQAAAAAAABQAAABAAAAQABABAAABQAAAAgBABQAAAAAAABQAAAAgBABIgBAAQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAgBAAgAHaBTQgCgEgDAAIgBgHIADACIABAGIADAEIABAAIgBAEIgBgFgAEvBRQgBgCABgDIACgIIADABIgCAGQAAAAABABQAAAAABABQAAAAAAABQAAAAAAABQABABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAAAgBgBgAC3BRIAAgEIACgBIAAAFIgCAAgAHIBLIgCgDIgBgBIAEgBIABgBIABACIAEABIAEACIAAAEQgCAAgEACQgDgCgCgDgAFOBPQAAAAAAAAQAAAAgBgBQAAAAAAAAQAAgBAAgBIAAgBIAEgCIAAAEQAAABAAAAQAAABAAAAQAAAAgBAAQAAAAAAAAIgCAAgAjmBPIgBgDQAAAAABABQAAAAABAAQAAAAABAAQABAAAAAAIgBACgADABLIAAgBIgCgBQACgCgBgDIAAABIADABQgBACACAEIgDgBgAjrBJIgDgBIgBgBQgCgEgDgBIAAgEIABgDIABgCIADgCIgBgBIgCgDIgDgDIgCgDIgCgBIAAgEIAAgBQADAHAHgBIABACQgDADACAEQAAAAABABQAAAAAAAAQABABAAAAQABAAAAAAIAAAAQgBAFgDACIADABIAFACIACAAIgCABQgDAEACADIgCgBgAmyBGQgBgCAAgEIACgIIADABIgCAHQABAAAAAAQABAAAAABQAAAAABABQAAABAAAAQAAABAAABQAAAAAAABQAAAAAAABQgBAAAAABIgBAAQgBAAAAAAQAAgBgBAAQAAAAAAgBQgBAAAAAAgAh2BGIgEAAIAHgMIAAABIADACIgEAJgAhQBCQgHAAgJgEIgGgDIgBgBIgCgBIAEgBIAAACIADACIANAEQAGABACADIgDgCgAkpBBIADgBQAAABAAABQAAAAgBABQAAAAgBABQAAAAgBAAIAAgDgAmTBDQAAAAgBAAQAAAAAAAAQAAAAAAgBQgBAAAAgBIAAgBIAEgCIABADQAAABAAABQAAAAgBAAQAAABAAAAQAAAAgBAAIgBgBgAAxBDIAEgKIABABIACACIgCAEIAAAAIgEADIgBAAgAHxBBIgBgCIgDgDIgBgCQAAgCgBgDIgDgEIAAgCIAEACIAEAGQACACABACIABACQACACAAADIgEAAIgBgBgAkOA9IACABIgBABgAC1A6IAAgDIAEAAIAAADIAAAAIACgBIAAABIAAACIAAADQgDgDgDgCgACZA7IAAgPIABgEIABgBIABAAQACADgBAHIABAGIAAAAQgDAEgBAEgAG2A6QACgMgCgCQgEgFgEgBIgFgDQgCgDAAgEIABgIIADgCIAAAAIgBAEIAAAFQAAAAAAABQABAAAAABQABAAAAAAQABABAAAAIAFABQAAAAAAAAQABAAAAgBQAAAAAAAAQAAgBAAgBIAAgGIgCACIgBABIgCAAIgCAAIgBgFIABgCIABgBQABAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAIACgCIABAAIABABIAAgBIAAAAIABABIgBgCIgCgCQACgDgCgEIACAAIAAAAIgCgEQADgDgFgFQgEgEgEAAIgBgBQAAABgBAAQAAAAgBgBQAAAAgBAAQAAgBgBgBIgDgDQAAgBgFgDIAAAAIgIgBIgCgCQgBAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAIgBABIgFAAQgCgDACgFIACgFIACACIAAAEIAFAAIAFABIAIABQAIACAAAGQADAAAEADQAIAJADAJIABAFIgBANIABAFIADADIABAHIABASIACgBIAAABIAAACQAAAEABABQgDAAgEADIAAAAIgBgEgAG2AgIgBACIAAABIABABIABAAIAAgCIgBgIIgBgCgAA9A5IgBgBIABgGIAEgIIgBAAIgCgCIgCADQgFgEAAgDIgBgBIABgBQAEgDABgCIAAABIADABIADACIADgCIgEgEIgBgBIgCAAQgCgCAAgEQAAAAABgBQAAAAAAgBQAAAAAAAAQABAAAAAAIABgCIABgBIABgCIAAgCIABABIACgBIABAAIABABIAAgBIABAAIABACIgBgDQgCgCgEABIgCACIgCAFIgBAAIgBAGQgCgDgEgBIgCgFIADgDIACAFIACgGIABgDIABgCQACgCACgCIACAAIAAAAIAEAAIgEgIIgBgBIAAAAIACgBIADgDIABACIAEAHIAAABIACAEIgCARQAAADACADIAEADIABAEIgBABIgDAEIAAgBIgCADIABAAIABABQgBADACAEQACAEADABIAAABIgDADIgCAAIgBgDIgBgEIgJgFIAAABIAAABIgBACIgEAHIAAADIACACIAFACIgBABIgIgFgABMAcIABABIAAAAIgBgDIgBgCgABFAYIADABIAAABIAAgFIgDADgAE2A9IgDAAIABgDIACAAIABADIAAAAgAFOA6IgCgBIAAgBQAEABABACIgDgBgAA3A1IADgFQAAABABABQAAAAAAABQAAAAAAABQAAAAAAABIgBACIgDgCgAFBA0IAAgBIACACIAAAAIAAAAIgCgBgAB1AzIgEAAIgDAAIAAgEIAFABIACgCIABACIACAEIgDgBgADPAzIgDAAIgEAAIgCAAIgBgDIACgBIAAAAQADACADAAIABgBIABACIABABIgBAAgADmAuIABgDIABAAQACACgBAEIgDABgAmsAxIgCAAIAEgKIAAABIACACIgDAHgAmTAuQgGAAgJgHIgCgBIABgGQAEgFABgFIAAgBIgBABIgBAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAABgBAAIgBgEIgDgDQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAIgBgEIgBgEQgFgIgBgGIAEAAIAFANIACAKQAEAAAEgCIgEgEQgBgCAAgGIABgHIADABIgBAFIAAACQABADAEACIAFAEQABABAAAAQABABAAAAQAAABAAAAQAAABAAABQgBADgCABIgKABQABABAAAAQABAAAAABQAAAAAAABQABABAAABIAAABIgCACIgDAHIgBADIACACIAJADQAEABABACIgCgBgAFAApIADgHIAAgBIAAABIgCAAQAAAAgBAAQAAAAgBAAQAAABgBAAQAAAAAAABQgFgDAAgDQAFADAFgEIADgEIABAAIAAgBQACgEgEgEIgCgDIAAgBIACgBIAAADQABACAEACIAFAEQAAABABABQAAAAAAABQABAAAAABQAAAAgBABQAAADgCABIgKACQAAAAABAAQAAABAAAAQABABAAAAQAAABAAABIAAABIgBADIgDAFIgCgFgAHIAsIgBgDIABAAIABAAIAAABIACACIgCABgAmoAjIAAAAIADgDIAAADIgBACIgCgCgABpAlIgCgBQgFgIgFACIgBgBIgHgIIAAgDQABAAABAAQAAAAAAAAQABAAAAAAQAAAAAAAAIADACIAFACIAFAEQADAEABAFIABACgAkqAjIgBgDQgFgEgEgBIgFgDIAAgCIADgCIACgBIAEABQABAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBIABgHIgCACIgBABIgCgFIgBgDQAAAAABAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIADgCIABAAIAAABIAAgBIABAAIABABIgBgCQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAAAgBAAIgCAEQAAgBgBAAQAAAAgBAAQAAAAgBAAQAAAAgBAAIACgEIABgBIACgEQABAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAIABABIgFgKIgCgDIgCgFIACgCQAHAIACAJIACADQAAABgBABQAAAAAAABQAAAAAAABQABABAAAAIgBAJIABAEIACADIABAHIABAOIgDgBgAksAUIAAACIAAABIABABIABAAIAAgCIgCgIIAAgCgAheAjQgGgNgMAJIgBABIAAgBQAAgEAEgBIgDgKQgHgLgDgGQADgBAEAAIAIARIADAMQAFAAAEgBIABACQADAEAEgDQAEgDgDgFQgDgGgEAEIgCADIgDgCQgCgDABgHIABgKIAEABIgBAGQAAAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQACAEAGADIAHAEQADADAAADQgBAEgDACIgNABgAHAAcIgEgGIAAgDQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIABACIAEABIADAEIADAFIgBADIgIgGgAkaAhIAAgEIADAEIgBAAgADqAfIgCgEIgDgDIAAgBIADABIAAgGIAAAAIAAgCQAAgBABgBQAAgBAAAAQAAgBAAAAQAAgBAAAAIgFgEIgBAAIAAgBIAAADQgBgBAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAIABgEIAAgDIABAAIgDgBIgBAAIACAAIATAIIgDACIACADQABABAAABQAAABAAAAQAAABgBAAQAAABgBAAQAAAAAAAAQAAAAgBAAQAAAAAAgBQAAAAAAAAIgBABIACABIADABQAAAAABABQAAAAABAAQAAAAAAABQAAAAAAABIABAEIAAAAIgEACIACgBIgFgBQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAgADAAdIABAAIABABIgBAAIgBgBgAH0ARIgBgEIACABQAAAAABAAQAAAAABABQAAAAAAAAQAAABAAABIABADIAAAHIAAABIgBABQABgFgEgHgACpAaIABgBIABgBQABgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIACgCIABAAIABABIAAgBIAAAAIABABIgBgCQAAAAAAgBQgBAAAAAAQgBAAAAAAQgBAAgBAAIgDAGIAAACIgDABIAAABIAAgBQAAgGADgFIAAgBIADgEQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAIAAABQgDgKgIgFIABgBIAAAAIAFACIADACIAAAAQADAEACAFIABAEIgBAOIAAABIgBABQgEgDgFABgADIAZIABgCIACABIAAADgAB2AWIgBAAIgBgBIgCAAIgHgDIADgIIABADQACAEADAAQADACAEgCQACAEgCADIgBABIgCABIgCgEgAHRAWIAAAAIgBAAIgCgBIgEgDIACgGIADACIACABIAAgBIgBAAIAAgCIADACIAAAAIgBACIACACQACADgCADIAAABIgBABIgCgEgAjwATIgBgDQACgFADgBIgFgBQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAIgLgBIgCAAIgCgCIgEgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBIAAgEIACgBQADgCAAgFIAAgBQAAgBABAAQAAgBAAgBQAAAAAAgBQAAAAAAgBIABgDIAAAAIgCgBIgBgBIABAAIATAJIgCACIACADQAAABAAABQAAABAAAAQAAABAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAIAAAAIABABIADABQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABIABAEIgBAHIABACIABAAQABABAAAAQAAABABAAQAAABAAAAQAAABAAAAIgBAEQgFgGgEgBgAkAgCIgDAEQACABADACIAGABIAAgGIABAAIAAgBQAAgBAAgBQAAgBAAAAQAAgBABAAQAAgBAAAAIgFgEIgBAAIgBgBQAAAGgDADgADEAVIgBgCIABgFIACAFIAAAAIgBADgAHdAUQAAAAgBAAQAAgBAAAAQAAgBAAAAQgBgBAAAAIAAgEIACgCQADgCAAgFIAAgCQABAAAAgBQAAAAABgBQAAAAAAAAQAAgBAAAAIAAgDIABgBIgDgBIgBgBIACAAIATAIIgDADIACADQABABAAAAQAAABAAABQAAAAgBABQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAgBIAAABQgDgDgEAAIABgEIgFgEIgBAAIAAAAQAAAFgDADIgEAGIABAAQgCADAAACIAAACgAkhARIgFgHIAAgCQABgBAAAAQAAAAABAAQAAAAAAABQAAAAAAAAIACACIACABQgBADAAADIAAAAgAHGAPIgBgBIABgBIADgCIgCAFgABlANIgBgDIABgHIABAAIADADIgCAIgAkPAMIgBgBIgBAAIAAgBQgCgDgDgBIADgEIAAAAIACABIAAgBIAAAAIgBgCIADACIABABIgBABIACADQABADgBACIgBABIgBgBgAC3AAIgCAAIABAAQADgEgCgCIAPAHIACADIgDAEgAHJAAQgFgFgFADIgGgDIgHgFQgDgDADgEIAWAMQACADAAAEIgBgCgAHMgDIABAAIACABIgBACIAAAAIgBABIgBgEgAAHgBIgBgEIgBAAQgFgJgHABIAAgCIABgCQACABAEgBIAAAAIgDACQABAAADABIAFACIAFADIAAgBIACAAQgCAEAEAFIABABIgDAAIgBgBIAAABQAAAAAAAAQgBAAAAAAQAAABgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAAAAAAAQgBAAAAgBgAHOAAIAAAAIAAAAgADUAAIAAAAIgCAAIAAgCIACAAIACABIgBABIAAAAIgBAAgABvAAIgBgKIABAAIAEACQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAABQAAAAgBABQAAAAAAABIAAAAgADLgBIgBgBQACgDADABIAAAAIAAAEQgBAAAAAAQgBAAgBAAQAAAAAAAAQgBgBAAAAgAAjAAIACgDIACADgAFCgEIABgCIABABIACAFIgEgEgABogCIABgBIACgBIAAADgAApgEIAAAAIAAABgAHUgJIACABIACAAIgBABIAAABIgBAAIAAAAIgCABIAAgEgAC6gJIADAAIAAADQgBAAAAgBQgBAAAAgBQAAAAgBAAQAAgBAAAAgAHNgIIgBgBQACgCADABIAAAAIAAAEQgBAAAAAAQgBAAgBAAQAAgBAAAAQgBAAAAgBgAE6gIIACAAIAAABIgCABIAAgCgAE3gHIgEgBIAAgBIAGAAIAAABIgBACIgBgBgAEtgGIgCgEIAFAAIABAEgAEagGQACgDgDgFIgBgCIACAAIAJACIABABIAFAHgAhmgIQADgCACgDIABAAIADAHgADbgJIABgFIAAgBIABgEIAAgBIADgCIAAACQAAAGgCAEIAAACIABAAIAAAAIAAABIgEgCgABRgNIgHgDIgDgCQgBgBAAAAQAAgBgBgBQAAAAAAgBQAAAAAAgBIgBACIgEgBIAAgBIADgFIAEABIAAABIAHACIAOAHQgDADADAGgAkVgPIAAAAIACACIAAABIgBABIgBACIAAgGgAkTgMIAAABIgBABgAB9gLIgBAAIgCgBIAAgFIADAAIADABIgBACIAAABIgBACgAi2gLQgBgBAAAAQgBAAAAgBQgBAAAAAAQAAgBgBgBIAEAEgAmhgNIADgEIAAAAIADAGgAG8gQIADAAIAAAEQgBAAAAgBQgBAAAAgBQAAAAgBgBQAAAAAAgBgAHdgQIABgEIAAgBIABgFIAAAAIADgCIAAABQAAAHgCADIAAACIABAAIAAABIAAAAIgEgCgABvgQQAAAAAAAAQAAAAgBAAQAAgBAAAAQAAAAAAAAQADgDAEACIABAAIgBAEQgEAAgCgCgAhvgRIACABIABACIgDAAIAAgDgAh0gOIgGgCIAAgCIAJABIABAAIgDADIgBAAgAiDgOIgDgEIAIAAIABAEgAiogOQAHgFgDgHIAEAAIANADIACABQAEACAEAGgAkpgRIgGgFQgDgDACgDIARAJIgFACIgCACgADLgRIgBAAIgEgCIgHgEQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAgBIAKABQAEADAAACIABABIgBADIAAABIgBgBgACbgSIgHgDIAAAAIgGgCIABgBIACABIAIABQAHADABADIgGgCgAE9gRQACgDgBgEIAAAAIAFABIgEAGgACDgRIgBAAIAAgBIAFABIgEAAgAkOgUIACAAIACABIAAABIAAABIgBAAIgBAAIgCAAIAAgDgAkVgTIgBgBQACgDADABIABAAIgBAFQAAAAgBgBQgBAAAAAAQgBAAAAAAQAAgBgBAAgAmngUIABABIABABIgCABIAAgDgAmrgSIgDgBIAAgCIAFABIABAAIgCADIgBgBgAm0gRIgDgFIAGAAIAAAFgAnFgSQADgDABgFIACABIABAAIAGAIgAjAgVIgHgDIgGgBQgDgCAAgFIAAgGIAAgCIgDgBIgVgKIgEgCIgEgEQgEgEABgHIAAgBIABgCIACAEQADAEAEACIAFADIALAFQABADACADQAGAGAFgBIADAGIACABIgEACQACAAAFACIAFACQgCADACAFgABVgaIAGAAIgBAFQgEgCgBgDgAEtgXIgBgDIAAgBIAEABIAAABIADADIgGgBgAHNgXIgBAAIgEgDIgHgDQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAgBAAgBIAKABQAEADAAADIABABIgBADIAAABIgBgBgAkmgbIAEAAIgBADQAAAAgBgBQAAAAgBgBQAAAAAAAAQAAgBgBAAgAG4gYIgDgDIgBgDIAJAGgAEPgZIAAgEIABAAIABAEIAAABIgCgBgAnhgaIgEAAQgCgCAAgFIAAgEIAAgBIgCgCIgOgHIgCgCIgDgEQgDgCABgGIAAgBIADACIAAAAIABACIAAAAIABAAIABADIAEACQAJAGAGACQAAAEADAFIACABIgDACQABAAAEABIACABQgBAEgBADIgDgCgAAXgbIgDgCIAAAAIABgCIgBAAIAAgBQABgDgBgDIABgBQADAAADgCQAEAGAHgDIACgCIAEACIABADIACADIgDABIgCADIgBAAIgBgBIgCgCIgEgBIAAgBIgBAAIAAAAIgBAAIgJgBIAFAFIgBACIgCACIgCgCgAkEgbIAAgFIAAgBIACgEIgBgDQACgDgBgDIgBgCIAAgBIgCgEIAAgDIgBgDQgCgFACgGIABABIABAEIACAJIABADIABAEIAAALIAAAFQgCAEAAADIgCgBgAD6gbIgBgBIgOgHIgDgCIgCgEQgDgCABgHIAAgBIAAAAIADAAQAAAAAAABQgBAAAAABQAAAAABAAQAAABAAAAIAAACIABAAIAAAAIACACIADACQAKAGAGACIAAAFIgCADgAgWgdIgDgCIgCgEQgDgCABgGIAAgBIAAgBIADABQAAAAAAAAQgBABAAAAQAAAAABABQAAAAAAAAIAAACIABAAIAAAAIACADIADACIADACQgBADABAEgAhqgcQACgDgCgEIABgBIAIgLIACgBIgBAAQAEgDAAgDQAEgFgCgEQAAgDgEgDIgIgFIgBgCQgBgDgDAAQgGgHAAgFQAAgEAEgBQgBAFAHAGIAHAFQAGAEADAFIACAGQABAFgCAGQgDAHgHAJIgIAMgAmkgdQABgCgBgEIABgBIAEgHIABAAIACAFIgBABIgGAJgAC6gdIgDgCIgDgFIgBgBIABgBQABgBgBAAQAAgBAAAAQAAAAgBAAQAAgBgBAAIAAAAIgDgBIgDABIAAAAIgBAAIAAAAIgBgBQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAgBAAIAAACIgCgEIABgDIAGADIADABIADABIACABQAEADACAEIAHAAIgHgDQAAAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAIABgDIABgBIALAFIACACQgCADACAFIgJgBIgBAFgACwghIAAgCIACgBIABAAIgBABIABACIgDABgAEqgjIgCgCIgBgBIADgBIACgCIADAGIAAACIgFgCgAiDgjQAAAAAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAIAAgCIAGACIAAABIAEAEIgJgCgAm0gjIgBgCIAAgBIAEABIAAABIACADIgFgCgABvgjIgBAAIgGgDIgLgFQgCgCAAgDQAJAAAHACQAGACABADIAAACIgBAEIAAABIgCgBgAkVgjIAAAAIgEgCIgIgEQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBIALABQADADABACIAAABIgBADIAAABIgBgBgAlQgiIgCgDIgDgFIACAAIAEABIAHABIgFAGIgDAAgAABgkIAAgDQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAIABgBIAAgBQAAAAABAAQAAgBAAAAQAAgBAAAAQAAgBAAAAIAAAAIACAAIAAAAIABgDIACgGQAGgFgGgJIAAAAIAAgBIAFgBIAAgBIAAAAIAAgBQABAAAAgBQAAAAABAAQAAAAAAAAQABAAAAAAIACAAIAAgBIgDgBIgCAAQAAAAgBgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIgBgDQAAgBAAgBQAAAAABgBQAAAAAAgBQABAAAAAAIADAAIAPADIATADIACAGIADADIAAACIgEgBIgFgBQACgCgDgDQgDgHgEADQgFAEADAEIABABIgCAAIgBAAIgBADIgBAAIgBABQgFgFgIAFQgEACgBAEIgBAAIAAAAIABAFIAAACIgBAGIAAACIAAAAIAAACQgEADgBAEIgCgBgAG6gjIgEgIIgBAAIABgCQABAAgBgBQAAAAAAAAQAAgBgBAAQAAAAgBAAIAAAAIgDgBIgDAAIAAABIAAAAIgBAAIAAAAIgBgCQAAAAAAgBQAAAAgBgBQAAAAAAAAQgBgBgBAAIAAADIgDgGQgCACABAEIgDgBIgDAAIgGgBIABgDIgBgEIgBgCIAWAGIAEACQAEAEAEABIACADIAHAAIgHgCIAAgBQADAAAEgCIACgBIACABIADADIABACIAAABIAAADIgLgBIgBAGgAkpgjIgDgEIgCgDIAJAHgAGzgmIgBgBIAAgDIACgBIABAAIgBABQAAADACADIgDgCgABQgkIgEgEIAAAAIACgBIAJAFgABHgkIAAgDIAAgBIADABIgBADgAixgkIAAgBQADAAADgDIABAAIgDAEIAAAAIgEAAgADaglIAAgBIgBgDQgCgFACgGIABABIACAEIABAJIABACIgEgBgAEOgoIgBgBQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQgBgBAAgBQgBAAAAAAQgBAAAAgBQgBAAgBABIgEACQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBgBIABAAIAAgBQAAAAABgBQAAAAAAgBQAAAAABgBQAAAAgBgBIABAAIAUAGIADAEIADADIgFABgACFgpIgBABIAAgBIABgCIADgBIACgBQADABADgCQADgBAAgDIABABIAEAFIgCAAIgBAAIAAACIgBAAIgDADQgEgHgIAFgAnTgpIACAAIgCABgAFKgqIAAAAQAAgBABAAQAAgBAAAAQAAgBAAgBQAAAAgBgBIABgCIAAACIAAAHIgBgCgAnggrIAAgBIABADIgBgCgAHcgsIgBgDIAAgBIABgBIACgBIABAGIABACIgDAAgACggrIABgBIACAAIAAACIgDgBgAldgrIACgIIAAgCIADABIAAAJIgFABIAAgBgAnNguIABgBIABgCIgJgCIgBgCIABAAQACADAEgDQABAAAAgBQAAAAABAAQAAgBAAAAQABgBAAAAIACADIAGAGIgCACIgCACIgGgDgAingwIAAgCIABgBIABgBIgEgBIgKgCIgBgCQABgDgDgDQgDgDgEABIgDABQgCgEgEgBIAAgBIABAAIAfAIIAEAFIAIAGIgCACIgEAFIgHgEgAm3gvIgDgCQgEgEgDgBIgEgCIgDgEIAAgCIAAgFQgBgCgGgCIgBAAIgBgCIgBABIgDgDIgBgFIABgEIAAgFQAAAAAAgBQABAAAAAAQAAAAABAAQAAAAAAAAIADAAQACABABADIAAADQAAACgDACIAHADIAFAFQACAFgCADQAFABADADIAAAAQAAABAAABQABAAAAABQAAAAAAABQABAAAAABQACAEADgBIACAFIAAACIgEgDgAgTguIADgDIAAABIABgCIACABIAEACIgEAAIgEABIgBAAIgBAAgAiBgwIABAAIAAABIgBgBgAkngvIgDgGIAEgBIABgBIAHAAIgFgCQAEgEgDgDIAIADIADADIABADIAAABIgBADIgLgBIgBAFgAkugyIgCgBIAAgCIADAAIABAGIgCgDgABTgzIAAAAIgBgDQgBgGgFAAIgBAAQABAAAAgBQAAAAAAAAQAAAAAAgBQABAAgBAAQABgBgBAAQAAAAAAgBQgBAAAAAAQgBgBgBAAIgEAAIgFAAIAAAAIgCABIAAgDIgBgCQADgCABgCIAMAEQAGADACAFIAMAAIgLgDQgDgDAAgDQAAgDACgBIASAHIAEADIACADIAAACIgBAEIgRgBQgBACAAADgAiIgzIgDgCQgGgFgFgCIgGgCIgEgEIgBgDQgBgCACgDQgDgDgIgDIgCAAQAAgBAAAAQAAAAAAgBQgBAAAAgBQAAAAgBAAIgBACIgEgDQABgDgDgEIABgGIAAgGQABAAAAAAQABgBAAAAQABAAAAAAQAAgBABAAIAEAAQADACABAEIAAADQAAAEgEADIALADQAGAEACACQACAFgCAEQAHACAEAEIAEACIACACQgEADAEAGIACABgACGg1QAAgBABAAQAAgBAAAAQAAAAAAgBQABAAAAAAIAAAAIAAgBIgBgFIgCgDQgDgGADgIIACABIACAGIACAKIACAEIABABIgEACIgDAEgADug0IADgCIACgBIAAgBIABABIAEABIgEABIgFAAIgBABIAAAAgAmZg1QADgCgEgGQgCgDgDAAIgFgFIACgCIACgCIADACIAFAHIACAFIAAAGIgDABIAAgBgAEag3QgCgDgFgCIgCAAIgBgCIAAABIgDgCIgBgFIAAgEIAAgGQABAAAAAAQAAAAABgBQAAAAAAAAQABAAAAAAIACAAQADABAAAEIAAACQAAADgCACIAHADIAAAAIABADIADAEIgDADIAAgBgAA4g5IgBgDIABABIABACIAAABIAAABIgBgCgAnig5IAAgBIAAgBQABAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAIAAAAIAKACIAAACQgBAAAAAAQgBgBAAAAQgBAAAAAAQgBAAAAAAIgFACIgBAAIgCAAgABGg7IADgBIACAAIgBAAIgDABIgBABIAAgBgAk/g9IgDgBIgGAAIgDgHIgCgDIABAAIAYAGQgBABAAAAQAAABAAAAQAAABgBAAQAAABAAAAIgCgBIAAACIgEgGQgBADABAEIgDgBgAE5hFQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQAAAEAFAFIABABQgDgBgDABQgCgDAAgEgAnzg/IAAgBIADgDIgBABIACgCIABABIAEACIgDAAIgFABIgBABgAjXhKIADABIgDAAIAAgBg");
	this.shape_4.setTransform(-0.2,-0.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.CAlgaeLarge, new cjs.Rectangle(-55.6,-13.3,110.3,27.5), null);


(lib.calendarpin = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAPAAQAAAGgEAFQgFAEgGAAQgFAAgFgEQgEgFAAgGQAAgFAEgFQAFgEAFAAQAGAAAFAEQAEAFAAAFg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#FFFFFF","#000000"],[0,1],0,0,0,0,0,2).s().p("AgKALQgEgFAAgGQAAgFAEgFQAFgEAFAAQAGAAAFAEQAEAFAAAFQAAAGgEAFQgFAEgGAAQgFAAgFgEg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.calendarpin, new cjs.Rectangle(-2.5,-2.5,5,5), null);


(lib.calendarnew = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.498)").s().p("AgWAqQgCgCAAgDIAAhIQAAgDACgCQACgCAEAAQADAAACACQACACAAADIAAAIQALgQAPAAIABAAQADAAACACQACACAAADQAAAEgCACQgCACgEAAIgBAAQgIAAgGAEQgGAEgFAGIAAAzQAAADgCACQgCACgDAAQgEAAgCgCg");
	this.shape.setTransform(34.7,-49.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.498)").s().p("AgWAqQgHgEgDgFQgEgGAAgIQAAgMAKgHQAKgHASAAIAUAAIAAgBQAAgLgFgFQgGgFgLAAIgLABIgLADIgCAAQgBAAAAAAQgBAAgBAAQAAAAAAgBQgBAAAAgBQgBAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAgEAEgCQAOgHAOAAQAMAAAIAGQAIAEADAHQAEAIAAAJIAAAuQAAAEgCACQgCACgDAAQgEAAgCgCQgCgCAAgEIAAgEQgMAMgTAAQgHAAgGgCgAgVASQAAAGAEADQAFAEAJABQAHgBAGgEQAHgDAFgGIAAgNIgSAAQgZAAAAANg");
	this.shape_1.setTransform(25.9,-49.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.498)").s().p("AgUA5QgKgFgGgKQgFgKgBgOQABgNAFgKQAGgKAKgFQAJgFALgBQAPABAMANIAAgqQAAgDACgDQACgCAEAAQADAAACACQACADABADIAABsQgBAEgCACQgCACgDAAQgEAAgCgCQgCgCAAgEIAAgEQgMAMgPAAQgLABgJgGgAgSgDQgIAGAAAPQAAAPAIAIQAHAHALAAQAIAAAHgDQAHgEAFgFIAAgkQgFgEgHgEQgHgDgIAAQgLAAgHAIg");
	this.shape_2.setTransform(15.8,-51.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.498)").s().p("AAZAqQgCgCAAgDIAAguQAAgUgTAAQgHAAgHAEQgGAFgGAHIAAAyQAAADgCACQgDACgDAAQgDAAgCgCQgCgCAAgDIAAhIQAAgDACgCQACgCADAAQADAAADACQACACAAADIAAAHQAGgHAIgEQAHgEAJAAQAJAAAHAEQAHAFAEAHQADAIAAAJIAAAvQAAADgCACQgCACgEAAQgDAAgCgCg");
	this.shape_3.setTransform(5.7,-49.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.498)").s().p("AgbAhQgMgMAAgVQAAgLAFgKQAEgKAJgGQAJgGANgBQAMAAAJAHQAJAFAFAKQAEAJAAAMQAAACgCACQgCADgEAAIg4AAQACAMAHAGQAIAHAMgBQAHAAAGgBIAKgEIACAAQADAAADABQAAABAAAAQABABAAAAQAAABAAABQAAAAAAABQAAAEgEACIgNAGQgHABgKAAQgTAAgLgLgAgKgcQgFADgEAGQgEAFgBAIIAxAAQgBgIgDgFQgEgGgGgDQgFgCgFAAQgFAAgGACg");
	this.shape_4.setTransform(-4.2,-49.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.498)").s().p("AgEA8QgDgCAAgDIAAhtQAAgDADgCQABgCADAAQADAAADACQABACAAADIAABtQAAADgBACQgDACgDAAQgDAAgBgCg");
	this.shape_5.setTransform(-11.1,-51.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.498)").s().p("AgWAqQgHgEgDgFQgEgGAAgIQAAgMAKgHQAKgHASAAIAUAAIAAgBQAAgLgFgFQgGgFgLAAIgLABIgLADIgCAAQgBAAAAAAQgBAAgBAAQAAAAAAgBQgBAAAAgBQgBAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAgEAEgCQAOgHAOAAQAMAAAIAGQAIAEADAHQAEAIAAAJIAAAuQAAAEgCACQgCACgDAAQgEAAgCgCQgCgCAAgEIAAgEQgMAMgTAAQgHAAgGgCgAgVASQAAAGAEADQAFAEAJABQAHgBAGgEQAHgDAFgGIAAgNIgSAAQgZAAAAANg");
	this.shape_6.setTransform(-18.1,-49.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.498)").s().p("AgVA1QgNgHgIgOQgHgOAAgSQAAgRAHgOQAIgOANgHQAOgHAPAAQAMAAAJACQAJADAJAFQADACAAAFQAAAAAAABQAAABAAAAQAAABgBAAQAAABAAAAQgCACgDAAIgDgBQgIgEgHgCQgHgCgJAAQgOAAgKAGQgKAGgFALQgFAKAAAMQAAANAFALQAFAKAKAGQAKAGAOAAQAJAAAHgCQAHgCAIgEIADgBQADAAACACQAAABAAAAQABABAAAAQAAABAAAAQAAABAAABQAAAEgDACQgJAFgJADQgJACgMAAQgPAAgOgHg");
	this.shape_7.setTransform(-28.3,-51);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgBACIgBgCIABgBIABgBIACABIABABIgBACIgCABIgBgBg");
	this.shape_8.setTransform(50,-7.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAFAOIAAgQIgBgFQAAgBAAAAQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAABQAAAAgBAAIgCADIAAATIgEAAIAAgaIADAAIABADIAAAAIADgDIADgBIADABIACABIACAEIAAAEIAAARg");
	this.shape_9.setTransform(48.3,-9.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgEANQAAAAAAAAQgBAAAAAAQAAgBgBAAQAAAAAAAAIgCgEIAAgEIAAgRIAEAAIAAAQIABAFQAAABAAAAQABAAAAABQAAAAABAAQAAAAABAAIABAAIABgCIACgBIAAgCIAAgSIAEAAIAAASIAAAFIABADIgDAAIgBgDIAAAAIgDADIgDAAIgDAAg");
	this.shape_10.setTransform(46,-9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgFATIgEgCIACgDIADABIAEABQACAAACgCQAAAAABgBQAAAAAAgBQABAAAAgBQAAgBAAAAIgBgEIgDgDIgCgCIgEgCIgDgEIgBgEQAAgFADgCQADgCADAAIAFAAIADABIgBAEIgDgBIgEgBQgBAAAAAAQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAABQAAAAAAAAQgBABAAAAQAAABAAAAIABAEIADACIADADIADACIADAEIABAEQAAAFgDADQgDACgEAAIgFAAg");
	this.shape_11.setTransform(43.7,-9.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgBACIgBgCIABgBIABgBIACABIABABIgBACIgCABIgBgBg");
	this.shape_12.setTransform(39.7,-16.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AABARQgBAAAAAAQAAAAAAAAQgBgBAAAAQAAAAgBAAIAAgHIAAgPIgEAAIAAgDIAEAAIAAgGIACgBIAAAHIAGAAIAAADIgGAAIAAAPIAAAEIADABIACAAIABgBIABADIgDABIgDAAg");
	this.shape_13.setTransform(38.5,-17.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgGAMQgCgCAAgEIABgEIADgCIADgBIADAAIACAAIABAAIAAgDIgBgEQgBAAAAgBQAAAAAAAAQgBAAAAAAQgBAAgBAAIgCAAIgDABIgBgDIAEgBIADgBIAEABIACACIABACIAAADIAAAGIAAAFIAAAEIAAADIgCAAIgBgDIAAAAIgDADIgDABQgBAAAAAAQgBAAgBgBQAAAAgBAAQAAgBgBAAgAAAABIgBABIgCABIAAADIABADQAAAAAAAAQAAABABAAQAAAAABAAQAAAAAAAAIADgBIACgCIAAgGIgBAAIgCAAIgCAAg");
	this.shape_14.setTransform(36.6,-17.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgFATIgEgCIACgDIADABIAEABQACAAACgCQAAAAABgBQAAAAAAgBQAAAAABgBQAAgBAAAAIgBgEIgDgDIgCgCIgEgCIgDgEIgBgEQAAgFADgCQADgCADAAIAFAAIADABIgBAEIgDgBIgEgBQgBAAAAAAQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAABQAAAAAAAAQgBABAAAAQAAABAAAAIABAEIADACIADADIADACIADAEIABAEQAAAFgDADQgDACgEAAIgFAAg");
	this.shape_15.setTransform(34.5,-18.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgCADIgBgDIABgCIACgBIADABIAAACIAAADIgDABIgCgBg");
	this.shape_16.setTransform(25.9,-13.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgBAYIAAghIADAAIAAAhgAgBgRIgBgCIABgDIABgBIACABIABADIgBACIgCABIgBgBg");
	this.shape_17.setTransform(24.5,-15.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgGARIAAghIAEAAIAAAEIABAAIABgDIAEgBIADAAIgBAGIgDgBIgDABIgBADIAAAYg");
	this.shape_18.setTransform(23.1,-15.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgJAXIAAgtIATAAIAAAEIgOAAIAAARIANAAIAAADIgNAAIAAAVg");
	this.shape_19.setTransform(20.7,-15.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgBADIgBgDIABgCIABgBIACABIABACIgBADIgCABIgBgBg");
	this.shape_20.setTransform(12.1,-13.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgFARIgDgCIABgEIADABIAEABIADgBQAAAAAAgBQABAAAAAAQAAgBAAAAQAAgBAAAAIgBgEIgCgDIgCgBIgDgBIgDgEIAAgEQAAgEACgDQACgBADAAIAFAAIAEABIgCAEIgDgBIgDgBIgDABIgBAEIABACIACADIADACIADABIACADIABAFIAAADIgCADIgDADIgEABIgFgBg");
	this.shape_21.setTransform(10.4,-15.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgGARIAAghIADAAIABAEIAAAAIACgDIAEgBIADAAIgBAGIgDgBIgDABIgCADIAAAYg");
	this.shape_22.setTransform(8.6,-15.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgFARIgCgCIgCgEIgBgGIAAgVIAFAAIAAATIABAIQAAAAABABQAAAAAAAAQABABAAAAQABAAABAAIABgBIACgBIABgCIABgDIAAgWIAGAAIAAAXIAAAFIAAAEIgDAAIgCgEIgDADQgCACgDAAIgDAAg");
	this.shape_23.setTransform(6.1,-15.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AAGAXIAAgUIgBgGQgBgDgDAAQgBAAAAAAQAAAAgBABQAAAAgBAAQAAABgBAAIgCAEIAAAXIgFAAIAAgtIAFAAIAAAQIAAAAIADgDIAEgBIAEABIACACIADAEIAAAFIAAAVg");
	this.shape_24.setTransform(3.2,-15.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgBAXIAAgpIgMAAIAAgEIAbAAIAAAEIgMAAIAAApg");
	this.shape_25.setTransform(0.2,-15.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgBADIgCgDIACgCIABgBIACABIABACIgBADIgCABIgBgBg");
	this.shape_26.setTransform(-6.9,-13.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgIATQgDgEABgJQAAgHACgFQAEgEAEAAIADAAIADABIAAgOIAFAAIAAAiIAAAGIAAAGIgDAAIgBgEIgDADQgCACgCAAQgFAAgDgFgAgDgDQgDADAAAGIABAGIABAEIACACIACABQAFAAABgFIAAgSIgCgBIgDgBQgDAAgBADg");
	this.shape_27.setTransform(-8.9,-15.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgEAQIgDgEIgCgFIgBgHQAAgHADgFQADgFAFABIADAAIAEABIACAEIABAHIAAACIAAADIgQAAIAAAEIACAFIADACIACABIAEgBIADgBIABADIgDADIgGABQgCAAgDgCgAgDgKQgBACgBAFIAMAAQAAgFgCgCQAAgBgBAAQAAgBgBAAQAAAAgBAAQAAgBgBAAQgCABgCACg");
	this.shape_28.setTransform(-11.7,-15.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AAJAXIgIgdIgBgHIAAAHIgHAdIgDAAIgLgtIAFAAIAHAdIABAIIABgIIAHgdIABAAIAIAdIABAIIABgIIAGgdIAFAAIgLAtg");
	this.shape_29.setTransform(-15,-15.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgBADIgBgDIABgCIABgBIACABIACACIgCADIgCABIgBgBg");
	this.shape_30.setTransform(-21.4,-13.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgFARIgDgCIABgEIADABIAEABIADgBQAAAAAAgBQABAAAAAAQAAgBAAAAQAAgBAAAAIgBgEIgCgDIgCgBIgDgBIgDgEIAAgEQAAgEACgDQACgBADAAIAFAAIAEABIgCAEIgDgBIgDgBIgDABIgBAEIABACIACADIADACIADABIACADIABAFIAAADIgCADIgDADIgEABIgFgBg");
	this.shape_31.setTransform(-23.2,-15.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgEAQIgDgEIgCgFIgBgHQAAgHADgFQADgFAFABIADAAIAEABIACAEIABAHIAAACIAAADIgQAAIAAAEIACAFIADACIACABIAEgBIADgBIABADIgDADIgGABQgCAAgDgCgAgDgKQgBACgBAFIAMAAQAAgFgCgCQAAgBgBAAQAAgBgBAAQAAAAgBAAQAAgBgBAAQgCABgCACg");
	this.shape_32.setTransform(-25.7,-15.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgFARIgCgCIgCgEIgBgGIAAgVIAFAAIAAATIABAIQAAAAABABQAAAAAAAAQABABAAAAQABAAABAAIABgBIACgBIABgCIABgDIAAgWIAFAAIAAAXIAAAFIABAEIgDAAIgBgEIgEADQgCACgCAAIgEAAg");
	this.shape_33.setTransform(-28.5,-15.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgCAXIAAgpIgLAAIAAgEIAbAAIAAAEIgMAAIAAApg");
	this.shape_34.setTransform(-30.8,-15.8);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgCADIgBgDIABgCIACgBIADABIABACIgBADIgDABIgCgBg");
	this.shape_35.setTransform(-36.4,-13.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AAGARIAAgTIgBgIQgBgCgDAAQgBAAAAAAQAAAAgBAAQAAABgBAAQAAAAgBABIgDADIAAAYIgEAAIAAghIAEAAIAAAEIAEgDIAEgBIAEAAIADADIACADIAAAHIAAAUg");
	this.shape_36.setTransform(-38.5,-15.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgIANQgDgFAAgIQAAgIADgFQADgDAFAAQAGAAADADQADAFAAAIQAAAJgEAEQgDAFgFAAQgFAAgDgFgAgEgJQgCADAAAGIABAFIABAFIABACIADABQADAAACgDQACgDAAgHIgBgFIgBgDIgCgEIgDgBQgCABgCADg");
	this.shape_37.setTransform(-41.4,-15.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AAMAXIAAgdIAAgHIgCAGIgJATIgBAAIgKgTIgCgGIAAAAIABAHIAAAdIgFAAIAAgtIAEAAIALAWIABAFIACgFIAKgWIAFAAIAAAtg");
	this.shape_38.setTransform(-45,-15.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#999999").ss(1,1,1).p("ACCjLICnAAIDOAAIAAAIIAACEIAACYIAACMACClyIAACnIAACMIAACYIAACMICnAAIAAAAIDOAAAEploIAACdIAACMIAACYIAACMIAACJIDOiJAH2lyIABAAIAACnAH2lyIjNCnACClyIF0AAAn2jLIAAinIElAAICgAAIAACnICzAAAljjLICSAAICgAAIAACMIAACYIAACMIAACMIigAAIiSAAIiTAAIAAiMIAAiMIAAiYICTAAIAACYIAACMICSAAICgAAICzAAIAACMIF1ACIAAiOAjRlyIAACnIAACMIAACYICgAAICzAAICnAAIDOAAIjOCMAljlpIAACeIAACMICSAAICgAAICzAAICnAAIDOAAIjOCYAn2jLICTAAAjRBZIAACMIAACMAljBZICSAAAljDlIAACMAn2DlICTAAAn2BZICTAAAgxlyICzAAACCFxIizAAAn2g/IAAiMAH3jDIjOCE");
	this.shape_39.setTransform(1,13.9);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#666666").ss(1,1,1).p("AqolwIAAkcQAAgaAbAAIUbAAQAbAAAAAaIAAEbQgBAYgaAAI0bAAQgaAAgBgXgAKplxIAAP+QAAAagbAAI0bAAQgbAAAAgaIAAv9");

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#D72A2B").s().p("AqNCnQgaAAAAgYIAAkaQgBgbAbAAIUaAAQAbAAAAAbIAAEaQgBAYgaAAg");
	this.shape_41.setTransform(0,-51.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.calendarnew, new cjs.Rectangle(-69,-68.9,138.1,137.9), null);


(lib.wedx = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0.498)").s().p("AAhA6IghgpIggApQgDAEgHAAQgEAAgDgDQgDgDAAgFQAAgDACgDIAmgsIgmgtQgCgDAAgEQAAgEADgDQADgDAFAAQAFAAADAEIAhApIAigpQADgEAFAAQAEAAADADQAEADAAAEQAAAEgCADIgnAsIAmAsQACADABAEQAAAFgEADQgCADgFAAQgGAAgDgEg");
	this.shape.setTransform(-0.5,5.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.wedx, new cjs.Rectangle(-9.1,-15.1,17.4,35.5), null);


(lib.tuesx = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0.498)").s().p("AAhA6IghgpIggApQgEAEgFAAQgFAAgDgDQgDgDAAgFQAAgDADgDIAlgsIglgtQgDgDAAgEQAAgEADgDQAEgDAEAAQAGAAADAEIAgApIAhgpQADgEAGAAQAFAAACADQAEADAAAEQAAAEgDADIglAsIAlAsQACADAAAEQAAAFgDADQgCADgGAAQgEAAgEgEg");
	this.shape.setTransform(0,4.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.tuesx, new cjs.Rectangle(-8.6,-15.6,17.4,35.5), null);


(lib.thursx = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0.498)").s().p("AAhA6IghgpIggApQgEAEgFAAQgFAAgDgDQgDgDAAgFQAAgDADgDIAlgsIglgtQgDgDAAgEQAAgEADgDQAEgDAEAAQAGAAADAEIAgApIAhgpQADgEAGAAQAFAAACADQAEADAAAEQAAAEgDADIglAsIAlAsQACADAAAEQAAAFgDADQgCADgGAAQgEAAgEgEg");
	this.shape.setTransform(0,5.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.thursx, new cjs.Rectangle(-8.6,-15.1,17.4,35.5), null);


(lib.sunx = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0.498)").s().p("AAfA1IgfglIgeAlQgDAEgFAAQgEAAgDgCQgDgDAAgFQABgDACgDIAigoIgigpQgCgDgBgDQAAgFADgCQAEgDADAAQAGAAACAEIAeAmIAfgmQACgEAGAAQAEAAADADQADACAAAEQAAAEgCADIgjAoIAiApQACACABAEQAAAEgDADQgDADgFAAQgEAAgDgEg");
	this.shape.setTransform(0,3.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.sunx, new cjs.Rectangle(-8.6,-15.8,17.4,32.9), null);


(lib.satx = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0.498)").s().p("AAfA1IgfglIgeAlQgDAEgFAAQgEAAgDgCQgDgDAAgFQABgDACgDIAigoIgigpQgCgDgBgDQAAgFADgCQAEgDADAAQAGAAACAEIAeAmIAfgmQACgEAGAAQAEAAADADQADACAAAEQAAAEgCADIgjAoIAiApQACACABAEQAAAEgDADQgDADgFAAQgEAAgDgEg");
	this.shape.setTransform(0,3.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.satx, new cjs.Rectangle(-8.6,-15.8,17.4,32.9), null);


(lib.monx = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0.498)").s().p("AAhA6IghgpIggApQgDAEgHAAQgEAAgDgDQgDgDAAgFQAAgDACgDIAmgsIgmgtQgCgDAAgEQAAgEADgDQAEgDAEAAQAFAAADAEIAhApIAigpQADgEAFAAQAFAAADADQADADAAAEQAAAEgCADIgnAsIAmAsQACADABAEQAAAFgDADQgDADgFAAQgGAAgDgEg");
	this.shape.setTransform(0.5,4.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.monx, new cjs.Rectangle(-8.1,-15.6,17.4,35.5), null);


(lib.frix = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0.498)").s().p("AAhA6IghgpIggApQgDAEgHAAQgEAAgDgDQgDgDAAgFQAAgDACgDIAmgsIgmgtQgCgDAAgEQAAgEADgDQAEgDAEAAQAFAAADAEIAhApIAigpQADgEAFAAQAFAAADADQADADAAAEQAAAEgCADIgnAsIAmAsQACADABAEQAAAFgDADQgDADgFAAQgGAAgDgEg");
	this.shape.setTransform(0.5,6.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.frix, new cjs.Rectangle(-8.1,-14.1,17.4,35.5), null);


(lib.calendarpin_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.calendarpin_1, null, null);


(lib.calendarnew_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.calendarnew_1, null, null);


(lib.Background_intro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("EhChACmIkkACIohgCEhR8gCnMBHNAAAEBN8gCnIEBAAAjminMBKtAAA");
	this.shape.setTransform(21.8,381);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(255,255,102,0.6)").ss(14.3,1,1).p("AR+AAQAAC/g2CpQhRD7jKDKQiqCqjNBUQg2AWg5ARQiaAsitAAQnbAAlRlRQjKjKhQj7Qg3ipAAi/QAAnbFRlRQFRlRHbAAQCtAACaAtQA5AQA2AWQDNBUCqCqQFRFRAAHbg");
	this.shape_1.setTransform(-416.9,-335.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("Eg5phDiIAAC4IAAW5IAALqIAAVUI5wAAMAAAgg+IAA5xIZwAAIZyAAIAAZxEhTZgpxIDiAAIWOAAIMBAAINxAAMAAAAg+I5yAAEgE8BDJIAAgCIAAlOIHIAAIAAFOIAAAREhTtBDYIAAlfIHjAAIAAFCIAAAgEBM6BDjIAAgcIAAlOIG0AAIAAFOIAAAV");
	this.shape_2.setTransform(-15.3,-32);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("EhPmACmIiOgMIgIAAIAAlBMBHMAAAIAAFNIgXAAQh0gHiDgBQiFgBjxAGIAAADMgoCAAAIAAgFIlrAFIklACgEBN8ACmIAAlNIEAAAIACFNgAjnCmIAAlNMBKtAAAIAAFNg");
	this.shape_3.setTransform(21.8,381);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("EBKgAQNIAAlOMhKtAAAIAAFOIAAARIiigCIAAAMQg4gEiFgNQg0gFg2gDIAAgCIAAlOIHJAAInJAAMhHMAAAInlAAIZf7cIAAgLMCSwAAAIAAbcIgygBIAAAMIkAAAIm2AAIG2AAIAAFOIAAAVIgeABImYAGgEhWHAQeIAAlfIHlAAIAAFCIAAAggEhK+AQUIhOgHIIgACIkjAGIhLABQg1AAgvgCgEhWHAK/g");
	this.shape_4.setTransform(0,293.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFF00").s().p("AssMtQjKjKhQj7IWNAAIAALqQiaAsitAAQnbAAlRlRgAFHFoI2NAAQg3ipAAi/QAAnbFRlRQFRlRHbAAQCtAACaAtIAAW4IAA24QA5AQA2AWQDNBUCqCqQFRFRAAHbQAAC/g2CpIsBAAIMBAAQhRD7jKDKQiqCqjNBUQg2AWg5ARgARIFogAxGFogAFHxQIAAAAg");
	this.shape_5.setTransform(-416.9,-335.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Background_intro, new cjs.Rectangle(-552.1,-465.3,1103.3,866.7), null);


(lib.ef_TutorModule = function(options) {
	this._element = new $.ef.TutorModule(options);
	this._el = this._element.create();
	var $this = this;
	this.addEventListener('added', function() {
		$this._lastAddedFrame = $this.parent.currentFrame;
		$this._element.attach($('#dom_overlay_container'));
	});
}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,100,100);

p._tick = _tick;
p._handleDrawEnd = _handleDrawEnd;
p._updateVisibility = _updateVisibility;



(lib.playButtonTop = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(30,1,1).p("Ai9FkIAArHIF7Fjg");
	this.shape.setTransform(19,35.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.playButtonTop, new cjs.Rectangle(-15,-15,68,101.2), null);


(lib.contentFrame = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#FFFFFF").ss(1,1,1).rc(-866.5,-523.4,1733,1046.8,11.4,11.4,-110,-110);
	this.shape.setTransform(866.5,523.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.contentFrame, new cjs.Rectangle(-1,-1,1735,1048.8), null);


(lib.TextArea = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s("#CCCCCC").ss(1,1,1).dr(-50,-50,100,100);
	this.shape.setTransform(50,50);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TextArea, new cjs.Rectangle(-1,-1,102,102), null);


(lib.TC_TObject__Expt4a = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Shighlight = new lib.TC_TObject__Highlight();
	this.Shighlight.name = "Shighlight";
	this.Shighlight.parent = this;
	this.Shighlight.setTransform(400,39.9,1,1,0,0,0,63.5,25);

	this.Svar4a = new lib.TC_TObject__CBackgroundSun();
	this.Svar4a.name = "Svar4a";
	this.Svar4a.parent = this;
	this.Svar4a.setTransform(288.9,210.5,1.046,1.046,0,0,0,0.1,0.3);

	this.instance = new lib.CTable();
	this.instance.parent = this;
	this.instance.setTransform(299.6,364.7,1.089,1.089,0,0,0,275.2,53.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.Svar4a},{t:this.Shighlight}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Expt4a, new cjs.Rectangle(-0.5,0,600.6,422.7), null);


(lib.TC_TObject__Expt2a = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Shighlight = new lib.TC_TObject__Highlight();
	this.Shighlight.name = "Shighlight";
	this.Shighlight.parent = this;
	this.Shighlight.setTransform(63.5,25,1,1,0,0,0,63.5,25);

	this.Svar2a = new lib.TC_TObject__CRadio();
	this.Svar2a.name = "Svar2a";
	this.Svar2a.parent = this;
	this.Svar2a.setTransform(135.2,86.9,0.989,0.989,0,0,0,-0.2,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Svar2a},{t:this.Shighlight}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Expt2a, new cjs.Rectangle(-0.5,-0.5,210.3,164.6), null);


(lib.TC_TObject__Callout4b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TC_TObject__CalloutShort();
	this.instance.parent = this;
	this.instance.setTransform(32.7,19.7,1,1,0,0,180,32.6,15.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Callout4b, new cjs.Rectangle(-1.5,2.5,68.3,34.4), null);


(lib.TC_TObject__Callout3b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TC_TObject__CalloutLong();
	this.instance.parent = this;
	this.instance.setTransform(71.2,29.9,1,1,0,0,180,71.2,1.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Callout3b, new cjs.Rectangle(-1.5,-1.5,145.4,62.6), null);


(lib.TC_TObject__Callout3a = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TC_TObject__CalloutLong();
	this.instance.parent = this;
	this.instance.setTransform(71.2,29.9,1,1,0,0,180,71.2,1.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Callout3a, new cjs.Rectangle(-1.5,-1.5,145.4,62.6), null);


(lib.TC_TObject__Callout1a = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TC_TObject__CalloutLong();
	this.instance.parent = this;
	this.instance.setTransform(71.2,54.4,1,1,180,0,0,71.2,1.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Callout1a, new cjs.Rectangle(-1.5,23.2,145.4,62.6), null);


(lib.TC_TMaterialIcon__scale = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Stitle = new cjs.Text("Digital Scale", "bold 40px 'PT Sans'");
	this.Stitle.name = "Stitle";
	this.Stitle.lineHeight = 54;
	this.Stitle.parent = this;
	this.Stitle.setTransform(109.6,175.1,0.865,0.865);

	this.Sicon = new lib.CScalecopy();
	this.Sicon.name = "Sicon";
	this.Sicon.parent = this;
	this.Sicon.setTransform(262.1,81.1,1.556,1.556,0,0,0,-0.5,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Sicon},{t:this.Stitle}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TMaterialIcon__scale, new cjs.Rectangle(43.5,0,437.4,221.6), null);


(lib.TC_TMaterialIcon__radio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Stitle = new cjs.Text("Radio", "bold 40px 'PT Sans'");
	this.Stitle.name = "Stitle";
	this.Stitle.lineHeight = 54;
	this.Stitle.parent = this;
	this.Stitle.setTransform(113,280.6,0.865,0.865);

	this.Sicon = new lib.CRadio();
	this.Sicon.name = "Sicon";
	this.Sicon.parent = this;
	this.Sicon.setTransform(162.5,134.2,1.729,1.729,0,0,0,-0.1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Sicon},{t:this.Stitle}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TMaterialIcon__radio, new cjs.Rectangle(32,-0.8,260.6,328), null);


(lib.TC_TMaterialIcon__heater = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Stitle = new cjs.Text("Fish\nTank\nHeater", "bold 40px 'PT Sans'");
	this.Stitle.name = "Stitle";
	this.Stitle.lineHeight = 54;
	this.Stitle.parent = this;
	this.Stitle.setTransform(184.7,102.2,0.865,0.865);

	this.Sicon = new lib.CFishtank_heater();
	this.Sicon.name = "Sicon";
	this.Sicon.parent = this;
	this.Sicon.setTransform(140.9,127.9,2.698,2.698);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Sicon},{t:this.Stitle}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TMaterialIcon__heater, new cjs.Rectangle(107.7,0,177.9,255.9), null);


(lib.TC_TMaterialIcon__co2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Stitle = new cjs.Text("Carbon\nDioxide\nMachine", "bold 40px 'PT Sans'");
	this.Stitle.name = "Stitle";
	this.Stitle.lineHeight = 54;
	this.Stitle.parent = this;
	this.Stitle.setTransform(138.2,114.8,0.865,0.865);

	this.Sicon = new lib.squareco2machine();
	this.Sicon.name = "Sicon";
	this.Sicon.parent = this;
	this.Sicon.setTransform(130.6,197.8,2.486,2.486);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Sicon},{t:this.Stitle}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TMaterialIcon__co2, new cjs.Rectangle(87.1,0,177.3,395.7), null);


(lib.TC_TMaterialIcon__calendar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Stitle = new cjs.Text("Calendar", "bold 40px 'PT Sans'");
	this.Stitle.name = "Stitle";
	this.Stitle.lineHeight = 54;
	this.Stitle.parent = this;
	this.Stitle.setTransform(109.6,244.4,0.865,0.865);

	this.Sicon = new lib.calendarnew();
	this.Sicon.name = "Sicon";
	this.Sicon.parent = this;
	this.Sicon.setTransform(183.4,117.5,1.729,1.729);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Sicon},{t:this.Stitle}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TMaterialIcon__calendar, new cjs.Rectangle(64.9,-0.8,237.1,291.8), null);


(lib.TC_TMaterialIcon__algae = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Stitle = new cjs.Text("50 grams\nof algae", "bold 40px 'PT Sans'");
	this.Stitle.name = "Stitle";
	this.Stitle.lineHeight = 54;
	this.Stitle.parent = this;
	this.Stitle.setTransform(127.5,102,0.865,0.865);

	this.Sicon = new lib.CAlgaeLarge();
	this.Sicon.name = "Sicon";
	this.Sicon.parent = this;
	this.Sicon.setTransform(200.1,43,1.729,1.729,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Sicon},{t:this.Stitle}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TMaterialIcon__algae, new cjs.Rectangle(101.9,-6,196.5,200.9), null);


(lib.CThermometerHot = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.squarethermometernumbers();
	this.instance.parent = this;
	this.instance.setTransform(1.2,-3.1);

	this.instance_1 = new lib.squarethermometercolorhot();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-2,-27.3);

	this.instance_2 = new lib.squarefishtankthermometer();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.CThermometerHot, new cjs.Rectangle(-10.8,-42.3,21.7,84.8), null);


(lib.TC_TObject__CThermometerRoomTemp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.squarethermometernumbers();
	this.instance.parent = this;
	this.instance.setTransform(1.2,-3.1);

	this.instance_1 = new lib.squarethermometercolorroomtemp();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-1.1,30.6);

	this.instance_2 = new lib.squarefishtankthermometer();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__CThermometerRoomTemp, new cjs.Rectangle(-10.8,-42.3,21.7,84.8), null);


(lib.TC_TObject__CThermometerHot = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// TC_TObject__HeaterWater
	this.instance = new lib.TC_TObject__HeaterWater();
	this.instance.parent = this;
	this.instance.setTransform(52.5,-28.8,0.802,0.762,0,0,0,15.4,35.9);
	this.instance.alpha = 0.801;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Svar1b2
	this.Svar1b2 = new lib.CFishtank_heater();
	this.Svar1b2.name = "Svar1b2";
	this.Svar1b2.parent = this;
	this.Svar1b2.setTransform(52.6,-50.9,1.007,1.007);

	this.timeline.addTween(cjs.Tween.get(this.Svar1b2).wait(1));

	// squarethermometernumbers
	this.instance_1 = new lib.squarethermometernumbers();
	this.instance_1.parent = this;
	this.instance_1.setTransform(2.2,-3.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// squarethermometercolorhot
	this.instance_2 = new lib.squarethermometercolorhot();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0.8,-26.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// squarefishtankthermometer
	this.instance_3 = new lib.squarefishtankthermometer();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__CThermometerHot, new cjs.Rectangle(-10.8,-98.7,75.8,141.2), null);


(lib.NewCombinedWater = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.WaterAddition();
	this.instance.parent = this;
	this.instance.setTransform(-0.2,-44.6);

	this.instance_1 = new lib.OldWater();
	this.instance_1.parent = this;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(153,255,255,0.498)").s().p("AqEAMIAAgPIU7AAIAAAPgAq2AMIAxgXIgEAXg");
	this.shape.setTransform(25.3,-66);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.NewCombinedWater, new cjs.Rectangle(-99.1,-69.6,198.4,139.3), null);


(lib.TC_TObject__co2machine = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.squareco2bubbles();
	this.instance.parent = this;
	this.instance.setTransform(23.6,162.3,1,1,0,0,0,0,-0.1);

	this.instance_1 = new lib.squareco2machine();
	this.instance_1.parent = this;
	this.instance_1.setTransform(24.6,111.1,1.414,1.396);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__co2machine, new cjs.Rectangle(-0.1,0,49.4,222.3), null);


(lib.CAlgaeonScale = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CAlgaeLarge();
	this.instance.parent = this;
	this.instance.setTransform(38.2,10,0.732,0.848,0,0,0,0.1,0);

	this.instance_1 = new lib.CAlgaeSmall();
	this.instance_1.parent = this;
	this.instance_1.setTransform(43,13,0.936,1.083,0,0,0,0.5,0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.CAlgaeonScale, new cjs.Rectangle(-2.1,-2.4,80.4,27.5), null);


(lib.Calendarendofweek = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.sunx();
	this.instance.parent = this;
	this.instance.setTransform(61,0.9);

	this.instance_1 = new lib.satx();
	this.instance_1.parent = this;
	this.instance_1.setTransform(46.6,-5.1);

	this.instance_2 = new lib.frix();
	this.instance_2.parent = this;
	this.instance_2.setTransform(29.8,-2.4);

	this.instance_3 = new lib.thursx();
	this.instance_3.parent = this;
	this.instance_3.setTransform(6.4,-2.4);

	this.instance_4 = new lib.wedx();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-14.9,-2.4);

	this.instance_5 = new lib.tuesx();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-35.4,-2.4);

	this.instance_6 = new lib.monx();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-51.5,-2.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Calendarendofweek, new cjs.Rectangle(-59.7,-21,129.4,39.9), null);


(lib.SceneRegion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// SbackMask
	this.instance = new lib.contentFrame();
	this.instance.parent = this;
	this.instance.setTransform(960,587.5,1,1,0,0,0,866.5,523.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s("#000066").ss(2.5,1,1).dr(-960,-600,1920,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.SceneRegion, new cjs.Rectangle(-1.2,-1.2,1922.5,1202.5), null);


(lib.playup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.playButtonTop();
	this.instance.parent = this;
	this.instance.setTransform(5,0,1,1,0,0,0,19,35.6);
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#333333").ss(10.6,1,1).de(-86,-86,172,172);
	this.shape.setTransform(-4,0,1,1,-90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.playup, new cjs.Rectangle(-95.3,-91.3,182.6,182.6), null);


(lib.TC_THtmlText__Text1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.SControlContainer = new lib.TextArea();
	this.SControlContainer.name = "SControlContainer";
	this.SControlContainer.parent = this;
	this.SControlContainer.setTransform(50,50,1,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.SControlContainer).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_THtmlText__Text1, new cjs.Rectangle(-0.5,-0.5,101,101), null);


(lib.TC_THtmlText__CallOutText = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.SControlContainer = new lib.TextArea();
	this.SControlContainer.name = "SControlContainer";
	this.SControlContainer.parent = this;
	this.SControlContainer.setTransform(50,50,1,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.SControlContainer).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_THtmlText__CallOutText, new cjs.Rectangle(-0.5,-0.5,101,101), null);


(lib.TC_TObject__Expt4b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.ScallOut = new lib.TC_TObject__Callout4b();
	this.ScallOut.name = "ScallOut";
	this.ScallOut.parent = this;
	this.ScallOut.setTransform(367.3,34.9,1,1,0,0,0,83.9,22.4);

	this.Svar4b = new lib.TC_TObject__Shade();
	this.Svar4b.name = "Svar4b";
	this.Svar4b.parent = this;
	this.Svar4b.setTransform(190.7,100.6,0.583,0.584,0,0,0,0,-0.1);

	this.Shighlight = new lib.TC_TObject__Highlight();
	this.Shighlight.name = "Shighlight";
	this.Shighlight.parent = this;
	this.Shighlight.setTransform(399.6,37.5,1,1,0,0,0,63.5,25);

	this.Svar4a = new lib.TC_TObject__CBackgroundSun();
	this.Svar4a.name = "Svar4a";
	this.Svar4a.parent = this;
	this.Svar4a.setTransform(288.9,210.5,1.046,1.046,0,0,0,0.1,0.3);

	this.instance = new lib.CTable();
	this.instance.parent = this;
	this.instance.setTransform(299.6,364.7,1.089,1.089,0,0,0,275.2,53.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.Svar4a},{t:this.Shighlight},{t:this.Svar4b},{t:this.ScallOut}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Expt4b, new cjs.Rectangle(-0.5,-0.3,600.6,423), null);


(lib.TC_TObject__Expt1b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AmmjIIW5AAIn+GRI4nAAg");
	this.shape.setTransform(-23.9,-17.9,1.35,1.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AwSDJIJsmRIW5AAIn/GRg");
	this.shape_1.setTransform(-23.9,-17.9,1.35,1.35);

	this.Shighlight = new lib.TC_TObject__Highlight();
	this.Shighlight.name = "Shighlight";
	this.Shighlight.parent = this;
	this.Shighlight.setTransform(236.1,25,1,1,0,0,0,63.5,25);

	this.Svar1b = new lib.TC_TObject__CThermometerHot();
	this.Svar1b.name = "Svar1b";
	this.Svar1b.parent = this;
	this.Svar1b.setTransform(14.3,101.2,1.39,1.39,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Svar1b},{t:this.Shighlight},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Expt1b, new cjs.Rectangle(-165.6,-46,465.8,206), null);


(lib.TC_TObject__Expt1a = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ScallOut
	this.ScallOut = new lib.TC_TObject__Callout1a();
	this.ScallOut.name = "ScallOut";
	this.ScallOut.parent = this;
	this.ScallOut.setTransform(163.2,44.9,1,1,0,0,0,135.9,42.9);

	this.timeline.addTween(cjs.Tween.get(this.ScallOut).wait(1));

	// Shighlight
	this.Shighlight = new lib.TC_TObject__Highlight();
	this.Shighlight.name = "Shighlight";
	this.Shighlight.parent = this;
	this.Shighlight.setTransform(237,27,1,1,0,0,0,63.5,25);

	this.timeline.addTween(cjs.Tween.get(this.Shighlight).wait(1));

	// Svar1a
	this.Svar1a = new lib.TC_TObject__CThermometerRoomTemp();
	this.Svar1a.name = "Svar1a";
	this.Svar1a.parent = this;
	this.Svar1a.setTransform(14.6,59.6,1.416,1.416,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.Svar1a).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Expt1a, new cjs.Rectangle(-0.7,-0.5,301.8,120.1), null);


(lib.TC_TObject__Movie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// handmovingalgae
	this.instance = new lib.Chandholdingalgae();
	this.instance.parent = this;
	this.instance.setTransform(166.1,203.3);
	this.instance._off = true;
	this.instance.cache(-22,-23,44,47);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(256).to({_off:false},0).wait(1).to({x:199.7,y:163.1},0).wait(1).to({x:233.4,y:122.9},0).wait(1).to({x:332.2,y:173.1},0).wait(1).to({x:431.1,y:223.2},0).wait(1).to({x:444.6,y:273.7},0).wait(1).to({y:254.7},0).wait(1).to({x:379.2},0).wait(1).to({x:327,y:319.3},0).wait(1).to({x:340},0).wait(32).to({_off:true},1).wait(76));

	// algae
	this.instance_1 = new lib.CAlgaeSmall();
	this.instance_1.parent = this;
	this.instance_1.setTransform(161.6,225.5,0.554,0.554,0,0,0,0.2,0.1);
	this.instance_1.cache(-23,-12,47,25);

	this.instance_2 = new lib.CAlgaeSmall();
	this.instance_2.parent = this;
	this.instance_2.setTransform(169.6,223,0.549,0.237,0,0,0,0.1,0);
	this.instance_2.cache(-23,-12,47,25);

	this.instance_3 = new lib.CAlgaeSmall();
	this.instance_3.parent = this;
	this.instance_3.setTransform(162.7,222.5,0.886,0.886,0,0,0,0.4,0.1);
	this.instance_3.cache(-23,-12,47,25);

	this.instance_4 = new lib.CAlgaeLarge();
	this.instance_4.parent = this;
	this.instance_4.setTransform(158.1,223.4,0.617,0.848,0,0,0,0.1,0);
	this.instance_4.cache(-58,-15,114,32);

	this.instance_5 = new lib.CAlgaeonScale();
	this.instance_5.parent = this;
	this.instance_5.setTransform(158.1,224.7,1,1,0,0,0,38.1,11.3);
	this.instance_5._off = true;
	this.instance_5.cache(-4,-4,84,32);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1,p:{regX:0.2,regY:0.1,scaleX:0.554,scaleY:0.554,x:161.6,y:225.5}}]}).to({state:[{t:this.instance_1,p:{regX:0.4,regY:0.2,scaleX:0.766,scaleY:0.67,x:161.7,y:225.5}}]},23).to({state:[{t:this.instance_1,p:{regX:0.4,regY:0.3,scaleX:0.886,scaleY:0.886,x:162.7,y:222.6}}]},24).to({state:[{t:this.instance_3,p:{regX:0.4,regY:0.1,scaleX:0.886,scaleY:0.886,x:162.7,y:222.5}},{t:this.instance_2,p:{regY:0,scaleX:0.549,scaleY:0.237,x:169.6,y:223}},{t:this.instance_1,p:{regX:0,regY:0.1,scaleX:0.242,scaleY:0.544,x:157.2,y:223}}]},21).to({state:[{t:this.instance_3,p:{regX:0.5,regY:0.4,scaleX:0.979,scaleY:0.646,x:162.1,y:225.2}},{t:this.instance_2,p:{regY:0.1,scaleX:0.885,scaleY:0.728,x:158.7,y:222.6}},{t:this.instance_1,p:{regX:0.1,regY:0.1,scaleX:0.642,scaleY:1.057,x:177.5,y:221.5}}]},26).to({state:[{t:this.instance_1,p:{regX:0.5,regY:0.2,scaleX:0.788,scaleY:1.083,x:162.2,y:226.4}},{t:this.instance_4,p:{scaleX:0.617}}]},24).to({state:[{t:this.instance_1,p:{regX:0.5,regY:0.2,scaleX:0.936,scaleY:1.083,x:163,y:226.4}},{t:this.instance_4,p:{scaleX:0.732}}]},27).to({state:[{t:this.instance_5}]},111).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_5}]},1).wait(113));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(256).to({_off:false},0).wait(1).to({regX:38.2,rotation:30,x:205.1,y:181.8},0).wait(1).to({regX:38.1,rotation:0,x:241.5,y:141.7},0).wait(1).to({x:335.5,y:191},0).wait(1).to({x:435.4,y:244.4},0).wait(1).to({x:451.4,y:293.4},0).wait(113));

	// thermometer
	this.instance_6 = new lib.CThermometerHot();
	this.instance_6.parent = this;
	this.instance_6.setTransform(193.1,275.2,1,1,0,0,0,0,0.1);
	this.instance_6.cache(-13,-44,26,89);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(374));

	// hand
	this.instance_7 = new lib.CHand();
	this.instance_7.parent = this;
	this.instance_7.setTransform(69.5,103,0.639,0.717,-60,0,0,16.1,27.1);
	this.instance_7._off = true;
	this.instance_7.cache(-30,-37,59,75);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(186).to({_off:false},0).wait(1).to({regX:0,regY:0,rotation:-59.6,x:60.2,y:109.3},0).wait(1).to({rotation:-59.1,x:72.9,y:116.4},0).wait(1).to({rotation:-58.7,x:85.7,y:123.5},0).wait(1).to({rotation:-58.2,x:98.4,y:130.7},0).wait(1).to({rotation:-57.8,x:103,y:137.1},0).wait(1).to({rotation:-57.4,x:107.7,y:143.5},0).wait(1).to({rotation:-56.9,x:112.3,y:149.9},0).wait(1).to({rotation:-56.5,x:117,y:156.4},0).wait(1).to({rotation:-56,x:121.7,y:162.8},0).wait(1).to({rotation:-55.6,x:127.1,y:161.1},0).wait(1).to({rotation:-55.1,x:132.5,y:159.5},0).wait(1).to({rotation:-54.7,x:137.9,y:157.9},0).wait(1).to({rotation:-54.3,x:143.3,y:156.2},0).wait(1).to({rotation:-53.8,x:142.9,y:156},0).wait(1).to({rotation:-53.4,x:142.5,y:155.9},0).wait(1).to({rotation:-52.9,x:142.1,y:155.7},0).wait(1).to({rotation:-52.5,x:141.7,y:155.5},0).wait(1).to({rotation:-52.1,x:141.3,y:155.4},0).wait(1).to({rotation:-51.6,x:141,y:155.2},0).wait(1).to({rotation:-51.2,x:140.6,y:155},0).wait(1).to({rotation:-50.7,x:140.2,y:154.9},0).wait(1).to({rotation:-50.3,x:139.8,y:154.7},0).wait(1).to({rotation:-49.9,x:139.4,y:154.5},0).wait(1).to({rotation:-49.4,x:139,y:154.4},0).wait(1).to({rotation:-49,x:138.7,y:154.2},0).wait(1).to({rotation:-48.5,x:138.3,y:154.1},0).wait(1).to({rotation:-48.1,x:137.9,y:153.9},0).wait(1).to({rotation:-47.6,x:137.5,y:153.7},0).wait(1).to({rotation:-47.2,x:137.2,y:153.6},0).wait(1).to({rotation:-46.8,x:136.8,y:153.4},0).wait(1).to({rotation:-46.3,x:136.4,y:153.2},0).wait(1).to({rotation:-45.9,x:136,y:153.1},0).wait(1).to({rotation:-45.4,x:135.7,y:152.9},0).wait(1).to({rotation:-45,x:135.3,y:152.7},0).wait(1).to({rotation:-44.6,x:134.9,y:152.6},0).wait(1).to({rotation:-44.1,x:134.6,y:152.4},0).wait(1).to({rotation:-43.7,x:134.2,y:152.3},0).wait(1).to({rotation:-43.2,x:133.9,y:152.1},0).wait(1).to({rotation:-42.8,x:133.5,y:151.9},0).wait(1).to({rotation:-42.4,x:133.1,y:151.8},0).wait(1).to({rotation:-41.9,x:132.8,y:151.6},0).wait(1).to({rotation:-41.5,x:132.4,y:151.5},0).wait(1).to({rotation:-41,x:132.1,y:151.3},0).wait(1).to({rotation:-40.6,x:131.7,y:151.2},0).wait(1).to({rotation:-40.1,x:131.4,y:151},0).wait(1).to({rotation:-39.7,x:131,y:150.8},0).wait(1).to({rotation:-39.3,x:130.6,y:150.7},0).wait(1).to({rotation:-38.8,x:130.3,y:150.5},0).wait(1).to({rotation:-38.4,x:130,y:150.4},0).wait(1).to({rotation:-37.9,x:129.6,y:150.2},0).wait(1).to({rotation:-37.5,x:131.5,y:152.7},0).wait(1).to({rotation:-37.1,x:133.5,y:155.1},0).wait(1).to({rotation:-36.6,x:135.4,y:157.5},0).wait(1).to({rotation:-36.2,x:137.3,y:160},0).wait(1).to({rotation:-35.7,x:139.2,y:162.4},0).wait(1).to({rotation:-35.3,x:141.2,y:164.9},0).wait(1).to({rotation:-34.9,x:143.1,y:167.3},0).wait(1).to({rotation:-34.4,x:145,y:169.8},0).wait(1).to({rotation:-34,x:147,y:172.2},0).wait(1).to({rotation:-33.5,x:148.9,y:174.7},0).wait(1).to({rotation:-33.1,x:150.8,y:177.1},0).wait(1).to({rotation:-32.6,x:152.8,y:179.6},0).wait(1).to({rotation:-32.2,x:154.7,y:182},0).wait(1).to({rotation:-31.8,x:156.7,y:184.5},0).wait(1).to({rotation:-31.3,x:158.6,y:186.9},0).wait(1).to({rotation:-30.9,x:160.5,y:189.4},0).wait(1).to({rotation:-30.4,x:162.5,y:191.8},0).wait(1).to({rotation:-30,x:164.4,y:194.3},0).wait(1).to({_off:true},1).wait(118));

	// lid
	this.instance_8 = new lib.squaretintedfishtanklid();
	this.instance_8.parent = this;
	this.instance_8.setTransform(166.1,181.1);
	this.instance_8.cache(-107,-23,215,46);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(201).to({x:126.8,y:180.9},0).wait(1).to({x:120.3},0).wait(1).to({x:113.8},0).wait(1).to({x:111.9,y:181},0).wait(1).to({x:110,y:181.1},0).wait(1).to({x:108.1,y:181.3},0).wait(1).to({x:106.2,y:181.4},0).wait(1).to({x:104.3,y:181.6},0).wait(1).to({x:97.8},0).wait(1).to({x:91.3},0).wait(1).to({x:84.8},0).wait(1).to({x:78.3},0).wait(1).to({x:75.1},0).wait(1).to({x:72},0).wait(1).to({x:68.9},0).wait(1).to({x:65.8},0).wait(1).to({x:62.7},0).wait(157));

	// fishtank
	this.instance_9 = new lib.squarefishtank();
	this.instance_9.parent = this;
	this.instance_9.setTransform(165.1,255.1);
	this.instance_9.cache(-101,-93,202,186);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(374));

	// handpushingbutton
	this.instance_10 = new lib.CHand();
	this.instance_10.parent = this;
	this.instance_10.setTransform(350.1,321.2,0.602,0.718,-45,0,0,0.1,0.1);
	this.instance_10.cache(-30,-37,59,75);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AAZAAQAAALgHAHQgHAHgLAAQgKAAgHgHQgHgHAAgLQAAgKAHgHQAHgHAKAAQALAAAHAHQAHAHAAAKg");
	this.shape.setTransform(368.5,336);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#66FFFF").s().p("AgRARQgHgGAAgLQAAgKAHgHQAHgHAKAAQALAAAGAHQAIAHAAAKQAAALgIAGQgGAIgLAAQgKAAgHgIg");
	this.shape_1.setTransform(368.5,336);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0066FF").s().p("AgRARQgHgGAAgLQAAgKAHgHQAHgHAKAAQALAAAGAHQAIAHAAAKQAAALgIAGQgGAIgLAAQgKAAgHgIg");
	this.shape_2.setTransform(368.5,336);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_10,p:{x:350.1,y:321.2}}]},298).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance_10,p:{x:350.1,y:321.2}}]},30).to({state:[{t:this.shape_2},{t:this.shape},{t:this.instance_10,p:{x:350.1,y:321.2}}]},4).to({state:[{t:this.instance_10,p:{x:331.1,y:312.2}}]},4).wait(38));

	// Water
	this.instance_11 = new lib.squareco2bubbles_1();
	this.instance_11.parent = this;
	this.instance_11.setTransform(95.6,262.9,0.837,0.837,0,0,0,0,-0.1);
	this.instance_11.cache(-14,-31,27,61);

	this.instance_12 = new lib.NewCombinedWater();
	this.instance_12.parent = this;
	this.instance_12.setTransform(165.1,274.8);
	this.instance_12.cache(-101,-72,202,143);

	this.instance_13 = new lib.squareco2machine_1();
	this.instance_13.parent = this;
	this.instance_13.setTransform(98.7,247.2,1,0.887,0,0,0,0.1,0.1);
	this.instance_13.cache(-19,-81,39,163);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_13},{t:this.instance_12},{t:this.instance_11}]}).wait(374));

	// fishtankheater
	this.instance_14 = new lib.CFishtankheater();
	this.instance_14.parent = this;
	this.instance_14.setTransform(245.1,209.5);
	this.instance_14.cache(-15,-49,31,100);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(374));

	// calenderpin
	this.instance_15 = new lib.calendarpin();
	this.instance_15.parent = this;
	this.instance_15.setTransform(400.5,28.6);
	this.instance_15.cache(-4,-4,9,9);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(374));

	// calendar
	this.instance_16 = new lib.calendarnew();
	this.instance_16.parent = this;
	this.instance_16.setTransform(400,93.1);
	this.instance_16.cache(-71,-71,142,142);

	this.instance_17 = new lib.monx();
	this.instance_17.parent = this;
	this.instance_17.setTransform(358,91);
	this.instance_17.cache(-10,-18,21,40);

	this.instance_18 = new lib.tuesx();
	this.instance_18.parent = this;
	this.instance_18.setTransform(373,91.5);
	this.instance_18.cache(-11,-18,21,40);

	this.instance_19 = new lib.wedx();
	this.instance_19.parent = this;
	this.instance_19.setTransform(389.5,91);
	this.instance_19.cache(-11,-17,21,40);

	this.instance_20 = new lib.thursx();
	this.instance_20.parent = this;
	this.instance_20.setTransform(406,91);
	this.instance_20.cache(-11,-17,21,40);

	this.instance_21 = new lib.frix();
	this.instance_21.parent = this;
	this.instance_21.setTransform(422,90.5);
	this.instance_21.cache(-10,-16,21,40);

	this.instance_22 = new lib.satx();
	this.instance_22.parent = this;
	this.instance_22.setTransform(435.2,91.5,0.779,0.779);
	this.instance_22.cache(-11,-18,21,37);

	this.instance_23 = new lib.satx();
	this.instance_23.parent = this;
	this.instance_23.setTransform(445.7,96.4,0.779,0.779);
	this.instance_23.cache(-11,-18,21,37);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_16,p:{x:400,y:93.1}}]}).to({state:[{t:this.instance_17,p:{y:91}},{t:this.instance_16,p:{x:400,y:93.1}}]},1).to({state:[{t:this.instance_17,p:{y:91.5}},{t:this.instance_18,p:{y:91.5}},{t:this.instance_16,p:{x:399.5,y:93.6}}]},22).to({state:[{t:this.instance_17,p:{y:91}},{t:this.instance_18,p:{y:91}},{t:this.instance_19},{t:this.instance_16,p:{x:399.5,y:93.6}}]},24).to({state:[{t:this.instance_17,p:{y:91}},{t:this.instance_18,p:{y:91}},{t:this.instance_19},{t:this.instance_20},{t:this.instance_16,p:{x:399.5,y:93.6}}]},21).to({state:[{t:this.instance_17,p:{y:91}},{t:this.instance_18,p:{y:91}},{t:this.instance_19},{t:this.instance_20},{t:this.instance_21},{t:this.instance_16,p:{x:399.5,y:93.6}}]},26).to({state:[{t:this.instance_17,p:{y:91}},{t:this.instance_18,p:{y:91}},{t:this.instance_19},{t:this.instance_20},{t:this.instance_21},{t:this.instance_22},{t:this.instance_16,p:{x:399.5,y:93.6}}]},24).to({state:[{t:this.instance_17,p:{y:91}},{t:this.instance_18,p:{y:91}},{t:this.instance_19},{t:this.instance_20},{t:this.instance_21},{t:this.instance_16,p:{x:399.5,y:93.6}},{t:this.instance_23},{t:this.instance_22}]},27).wait(229));

	// scalenumbers
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCFF00").s().p("AgMAqIgJgEIAEgIIADABIAEACIAFABIAFABIAIgBQAEgBACgCIADgFIABgIIAAgHIgBAAQgCAEgFACQgEACgGAAQgOAAgGgHQgGgIAAgPQAAgPAIgIQAIgIAPAAIANABIAJACIAAA8QAAAFgCAFQgCAEgEADIgJAEQgFABgFAAQgHAAgFgBgAgLgdQgGAGAAAMIABAJIADAHQACADAEABQADACAEAAQAIAAAEgEQAEgDACgHIAAgdQgGgCgJAAQgJAAgFAFg");
	this.shape_3.setTransform(431.5,335.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCFF00").s().p("AgNApQgFgEgEgFQgEgGgBgIQgBgJgBgJQAAgJACgJQACgIAEgFQADgFAGgDQAFgEAHAAQAIAAAGAEQAFADADAFQAEAFACAIQACAJAAAJQAAAKgCAIQgDAJgDAFQgDAGgGADQgFADgIAAQgHAAgGgDgAgQAUQACAHAEAFQAEADAGAAQAKABAFgKQAFgIAAgSIgBgLgAgOgaQgFAJAAARIAAAGIABAFIAjgfQgCgGgEgEQgEgFgHAAQgJAAgFAJg");
	this.shape_4.setTransform(417.2,333.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCFF00").s().p("AgMApQgGgEgEgFQgEgGgBgIQgBgJgBgJQAAgJACgJQACgIAEgFQADgFAGgDQAFgEAHAAQAIAAAFAEQAGADADAFQAEAFACAIQACAJAAAJQAAAKgCAIQgDAJgDAFQgDAGgGADQgFADgIAAQgHAAgFgDgAgQAUQACAHAEAFQAEADAGAAQAKABAFgKQAFgIAAgSIgBgLgAgOgaQgFAJAAARIAAAGIABAFIAjgfQgCgGgEgEQgEgFgHAAQgJAAgFAJg");
	this.shape_5.setTransform(410,333.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCFF00").s().p("AgFAFQgCgCAAgDQAAgDACgCQACgCADAAQADAAADACQACACAAADQAAADgCACQgDADgDAAQgCAAgDgDg");
	this.shape_6.setTransform(402.8,337.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCFF00").s().p("AgNApQgFgEgEgFQgEgGgBgIQgBgJgBgJQAAgJACgJQACgIAEgFQADgFAGgDQAFgEAHAAQAIAAAFAEQAGADADAFQAEAFACAIQACAJAAAJQAAAKgCAIQgDAJgDAFQgDAGgGADQgFADgIAAQgHAAgGgDgAgQAUQACAHAEAFQAEADAGAAQAKABAFgKQAFgIAAgSIgBgLgAgOgaQgFAJAAARIAAAGIABAFIAjgfQgCgGgEgEQgEgFgHAAQgJAAgFAJg");
	this.shape_7.setTransform(395.6,333.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CCFF00").s().p("AgUAqIAAgIIATAAIAAg/IgTANIgFgGIAagTIAGAAIAABLIATAAIAAAIg");
	this.shape_8.setTransform(417.2,333.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CCFF00").s().p("AgZArIAAgJIAFgGIAJgHIAJgJIAIgKIAHgKQABgFAAgFQAAgHgDgEQgEgEgHAAQgGAAgFABIgIAEIgDgGQAFgEAGgCQAGgCAGAAQALAAAHAGQAFAHAAAKQAAALgKANQgLANgRAQIAoAAIAAAJg");
	this.shape_9.setTransform(417.2,333.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CCFF00").s().p("AgQAqIgIgCIACgJIAIADIAJAAIAIgBIAHgDIAEgGQACgDAAgEQAAgIgGgEQgFgDgJAAIgIAAIAAgFIAXgeIgjAAIAAgJIAuAAIAAAJIgXAcIABAAQAGAAAFABQAEACAEACIAEAHQACAEAAAFQAAAGgCAFQgDAFgEAEQgFADgFACQgGACgFAAIgLgBg");
	this.shape_10.setTransform(417.2,333.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CCFF00").s().p("AAHAqIAAgaIgmAAIAAgHIAngyIAIAAIAAAxIAQAAIAAAIIgQAAIAAAagAgUAIIAbAAIAAgig");
	this.shape_11.setTransform(417.3,333.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CCFF00").s().p("AgLAqIgGgBIgFgCIgDgBIAFgIIAFADQAFABAGAAIAHgBQAEgBADgCQADgDACgDQABgEAAgEQAAgJgHgEQgGgEgJAAIgLABIAAgqIAnAAIAAAJIgeAAIAAAYIAGAAQAMAAAIAGQAHAGABAMQgBAHgCAFQgCAFgEAEQgFADgFACQgGACgGAAIgGgBg");
	this.shape_12.setTransform(417.1,333.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CCFF00").s().p("AgLAqQgFgCgEgFQgDgDgCgGQgDgFAAgHQAAgMAEgJQADgKAGgHQAGgIAIgEQAHgGAKgBIACAIQgIABgGAEQgFADgFAGQgEAEgDAHQgDAGgCAFIAEgCIAEgDIAGgCIAGgBQAGABAFABQAFACAEADQADACACAFQACAEAAAGQAAAFgCAEQgCAFgDAEQgEAEgFACQgGACgGABQgGAAgGgCgAgFABIgGACIgEAEIgDADIgBADIAAACIACAIQABADADADQACADAEACQADABAFAAQAEAAADgBQADgCADgCQACgCABgDQACgDAAgEQAAgJgFgEQgFgEgJgBIgFABg");
	this.shape_13.setTransform(417.2,333.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CCFF00").s().p("AgTAqIAjhLIgqAAIAAgIIA0AAIAAAIIgkBLg");
	this.shape_14.setTransform(417.1,333.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CCFF00").s().p("AgLAqQgFgCgEgDIgEgHQgCgEAAgFQAAgOARgIIgFgEIgGgEIgDgGIgBgGQAAgFACgEQACgDADgDIAIgFQAFgBAFgBQAGABAEABQAFABADADIAEAGQACADAAAEQAAAIgDAFQgEAGgHAFIAGACIAFAFIAEAFIABAIQAAAFgCAEQgCAEgDADQgDAEgGACQgFACgGAAQgGAAgFgCgAgNALQgDAFAAAEIABAGQAAADADACIAGAEIAGAAIAGAAQAEgBACgCQADgCABgDQABgDAAgEQAAgDgBgDIgEgFIgHgDIgGgEQgIAEgEAFgAgFgiIgGAEIgCADIgBAFQgBADACADIAEAFIAGADIAGAEQAHgEADgEQACgFAAgEIgBgGIgDgEIgFgDIgFgBIgGABg");
	this.shape_15.setTransform(417.2,333.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CCFF00").s().p("AgRAkQAIgBAGgDQAFgDAFgEQAEgGADgFQADgGACgIIgFAEIgEACIgFACIgGAAQgFgBgFgBQgFgCgEgDQgDgCgCgFQgDgEAAgGQAAgFACgFQACgFADgEQAEgDAFgDQAGgCAHAAQAGAAAFACQAGADADAEQAEAEACAFQACAGAAAHQAAAMgEAKQgDALgGAGQgGAIgIADQgIAFgJABgAgNgeQgFAFAAAIQAAAJAFAFQAFADAJAAQAGAAAFgBQAFgDACgDIABgCIAAgCQAAgFgCgEQgBgEgDgDIgGgGQgDgCgFAAQgIABgFAEg");
	this.shape_16.setTransform(417.2,333.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CCFF00").s().p("AgUAqIAAgIIATAAIAAg/IgTANIgFgGIAagTIAGAAIAABLIATAAIAAAIg");
	this.shape_17.setTransform(410,333.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},328).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_8,p:{x:417.2}},{t:this.shape_3}]},3).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_9},{t:this.shape_3}]},2).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_10},{t:this.shape_3}]},2).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_11},{t:this.shape_3}]},3).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_12},{t:this.shape_3}]},2).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_13},{t:this.shape_3}]},2).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_14},{t:this.shape_3}]},2).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_15},{t:this.shape_3}]},1).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_16},{t:this.shape_3}]},1).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_8,p:{x:410}},{t:this.shape_4},{t:this.shape_3}]},2).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_17},{t:this.shape_8,p:{x:417.2}},{t:this.shape_3}]},1).wait(25));

	// scale
	this.instance_24 = new lib.CScalecopy();
	this.instance_24.parent = this;
	this.instance_24.setTransform(432.5,320.1,0.615,0.615,0,0,0,-0.5,1);
	this.instance_24.cache(-143,-53,285,108);

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(374));

	// Layer_1
	this.instance_25 = new lib.CRadio();
	this.instance_25.parent = this;
	this.instance_25.setTransform(354.4,234.7,1,1,0,0,0,-0.2,0);
	this.instance_25.cache(-78,-81,156,161);

	this.instance_26 = new lib.window();
	this.instance_26.parent = this;
	this.instance_26.setTransform(32.1,63.1);
	this.instance_26.cache(-85,-97,171,194);

	this.instance_27 = new lib.sun();
	this.instance_27.parent = this;
	this.instance_27.setTransform(30.1,32.1);
	this.instance_27.cache(-67,-67,133,133);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_27},{t:this.instance_26},{t:this.instance_25}]}).wait(374));

	// table
	this.instance_28 = new lib.table();
	this.instance_28.parent = this;
	this.instance_28.setTransform(273.8,351.3,1,1,0,0,0,0,0.3);
	this.instance_28.cache(-278,-55,556,112);

	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(374));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-50.9,-32.6,600.9,437.4);


(lib.TC_TMaterialIcon__thermometer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Stitle = new cjs.Text("Thermometer", "bold 40px 'PT Sans'");
	this.Stitle.name = "Stitle";
	this.Stitle.textAlign = "center";
	this.Stitle.lineHeight = 54;
	this.Stitle.parent = this;
	this.Stitle.setTransform(215.3,287.8,0.865,0.865);

	this.timeline.addTween(cjs.Tween.get(this.Stitle).wait(1));

	// Layer_2
	this.Sicon = new lib.TC_TObject__CThermometerRoomTemp();
	this.Sicon.name = "Sicon";
	this.Sicon.parent = this;
	this.Sicon.setTransform(217.2,135.9,3.243,3.243);

	this.timeline.addTween(cjs.Tween.get(this.Sicon).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TMaterialIcon__thermometer, new cjs.Rectangle(112.7,-1.3,205.4,335.6), null);


(lib.CFishTank_water = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// squarefishtank
	this.instance = new lib.squarefishtank();
	this.instance.parent = this;
	this.instance.setTransform(-0.1,2.2,1.432,1.432);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// NewCombinedWater
	this.instance_1 = new lib.NewCombinedWater();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.7,32.8,1.445,1.38);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.CFishTank_water, new cjs.Rectangle(-144,-127.3,286.6,259.1), null);


(lib.TC_TVirtual__SceneRgn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// background
	this.instance = new lib.SceneRegion();
	this.instance.parent = this;
	this.instance.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TVirtual__SceneRgn, new cjs.Rectangle(-1.2,-1.2,1922.5,1202.5), null);


(lib.TC_TButton__PlayButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// SpinButtonUp
	this.instance = new lib.playup();
	this.instance.parent = this;
	this.instance.setTransform(115.7,86,1,1,0,0,0,115.7,86);
	this.instance.alpha = 0.191;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(4));

	// SpinButtonOver
	this.instance_1 = new lib.playup();
	this.instance_1.parent = this;
	this.instance_1.setTransform(115.7,86,1,1,0,0,0,115.7,86);
	this.instance_1.alpha = 0.191;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({_off:true},1).wait(3));

	// SpinButtonDown
	this.instance_2 = new lib.playup();
	this.instance_2.parent = this;
	this.instance_2.setTransform(115.7,86,1,1,0,0,0,115.7,86);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({_off:false},0).to({_off:true},1).wait(2));

	// SpinButtonDisabled
	this.instance_3 = new lib.playup();
	this.instance_3.parent = this;
	this.instance_3.setTransform(115.7,86.1,1,1,0,0,0,115.7,86.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(3).to({_off:false},0).to({_off:true},1).wait(1));

	// SpinButtonFocus
	this.instance_4 = new lib.playup();
	this.instance_4.parent = this;
	this.instance_4.setTransform(115.7,86,1,1,0,0,0,115.7,86);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(4).to({_off:false},0).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(210,210,210,0.008)").s().p("EhAcAogMAAAhQ/MCA5AAAMAAABQ/g");
	this.shape.setTransform(-0.5,-0.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-413,-260,825,518.5);


(lib.TC_TScene__RQmovie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.Splay = new lib.TC_TButton__PlayButton();
	this.Splay.name = "Splay";
	this.Splay.parent = this;
	this.Splay.setTransform(978.6,600,2.424,2.424);
	new cjs.ButtonHelper(this.Splay, 0, 1, 2, false, new lib.TC_TButton__PlayButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Splay).wait(1));

	// Smovie
	this.Smovie = new lib.TC_TObject__Movie();
	this.Smovie.name = "Smovie";
	this.Smovie.parent = this;
	this.Smovie.setTransform(959.8,598.8,1.999,1.999,0,0,0,249.7,186.1);

	this.timeline.addTween(cjs.Tween.get(this.Smovie).wait(1));

	// SceneRegion
	this.instance = new lib.TC_TVirtual__SceneRgn();
	this.instance.parent = this;
	this.instance.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__RQmovie, new cjs.Rectangle(-22.6,-30.4,2000,1256.8), null);


(lib.TC_TScene__RQintro4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.CHand();
	this.instance.parent = this;
	this.instance.setTransform(1031.1,971.3,1,1,-105);

	this.instance_1 = new lib.CAlgaeLarge();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1188,881.9,1.474,1.374,0,0,0,0.1,0.1);

	this.instance_2 = new lib.grams();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1200.8,946);

	this.instance_3 = new lib.CScalecopy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(1181,918.6,1.071,1);

	this.instance_4 = new lib.Calendarendofweek();
	this.instance_4.parent = this;
	this.instance_4.setTransform(1192.5,449.6,1.5,1.5,0,0,0,4.7,-2.1);

	this.instance_5 = new lib.calendarpin();
	this.instance_5.parent = this;
	this.instance_5.setTransform(1186.1,327.5,2,2);

	this.instance_6 = new lib.calendarnew();
	this.instance_6.parent = this;
	this.instance_6.setTransform(1188.4,453.4,2,2);

	this.instance_7 = new lib.squaretintedfishtanklid();
	this.instance_7.parent = this;
	this.instance_7.setTransform(629.6,709.4,1.741,1.822,0,0,0,0.1,0.1);

	this.instance_8 = new lib.squareco2bubbles();
	this.instance_8.parent = this;
	this.instance_8.setTransform(645,837.2,1.15,1.15,0,0,0,0.1,-0.1);

	this.S_wecanmeasure = new cjs.Text("We can measure the weight of the algae growth after one week.", "bold 45px 'PT Sans'");
	this.S_wecanmeasure.name = "S_wecanmeasure";
	this.S_wecanmeasure.textAlign = "center";
	this.S_wecanmeasure.lineHeight = 60;
	this.S_wecanmeasure.lineWidth = 1832;
	this.S_wecanmeasure.parent = this;
	this.S_wecanmeasure.setTransform(960,122.8);

	this.instance_9 = new lib.line();
	this.instance_9.parent = this;
	this.instance_9.setTransform(633.6,706.3,0.491,0.829,19,0,0,0.1,0.1);

	this.instance_10 = new lib.TC_TObject__CThermometerHot();
	this.instance_10.parent = this;
	this.instance_10.setTransform(787.8,867.6,1.617,1.617,0,0,0,0,0.1);

	this.instance_11 = new lib.NewCombinedWater();
	this.instance_11.parent = this;
	this.instance_11.setTransform(734.5,862.3,1.65,1.65);

	this.instance_12 = new lib.squarefishtank();
	this.instance_12.parent = this;
	this.instance_12.setTransform(736.7,832.7,1.646,1.646);

	this.instance_13 = new lib.squareco2machine();
	this.instance_13.parent = this;
	this.instance_13.setTransform(640.2,807.3,1.68,1.41,0,0,0,0.1,0.1);

	this.instance_14 = new lib.CFishtank_heater();
	this.instance_14.parent = this;
	this.instance_14.setTransform(866.8,756.2,1.646,1.646);

	this.instance_15 = new lib.CScale();
	this.instance_15.parent = this;
	this.instance_15.setTransform(1265.6,958.6,1,1,0,0,0,-0.5,1);

	this.instance_16 = new lib.Background_intro();
	this.instance_16.parent = this;
	this.instance_16.setTransform(922.1,678.9,1,1,0,0,0,-0.3,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.S_wecanmeasure},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// SceneRegion
	this.instance_17 = new lib.TC_TVirtual__SceneRgn();
	this.instance_17.parent = this;
	this.instance_17.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__RQintro4, new cjs.Rectangle(-1.2,-1.2,1922.5,1202.5), null);


(lib.TC_TScene__RQintro3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.CAlgaeSmall();
	this.instance.parent = this;
	this.instance.setTransform(738.3,772,1.322,1.322,0,0,0,0.1,0.1);

	this.instance_1 = new lib.Chandholdingalgae();
	this.instance_1.parent = this;
	this.instance_1.setTransform(722.1,692,1.521,1.521,0,0,0,-0.1,0.1);

	this.instance_2 = new lib.CScalecopy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1180.5,919.6,1.071,1,0,0,0,-0.5,1);

	this.instance_3 = new lib.calendarnew();
	this.instance_3.parent = this;
	this.instance_3.setTransform(1192,456.1,1.919,1.853);

	this.instance_4 = new lib.squareco2bubbles();
	this.instance_4.parent = this;
	this.instance_4.setTransform(645,837.2,1.15,1.15,0,0,0,0.1,-0.1);

	this.instance_5 = new lib.line();
	this.instance_5.parent = this;
	this.instance_5.setTransform(633.6,706.3,0.491,0.829,19,0,0,0.1,0.1);

	this.instance_6 = new lib.TC_TObject__CThermometerHot();
	this.instance_6.parent = this;
	this.instance_6.setTransform(787.8,867.6,1.617,1.617,0,0,0,0,0.1);

	this.instance_7 = new lib.NewCombinedWater();
	this.instance_7.parent = this;
	this.instance_7.setTransform(735.7,862,1.634,1.665,0,0,0,-0.2,0.1);

	this.instance_8 = new lib.squarefishtank();
	this.instance_8.parent = this;
	this.instance_8.setTransform(736.7,832.7,1.646,1.646);

	this.instance_9 = new lib.squareco2machine();
	this.instance_9.parent = this;
	this.instance_9.setTransform(640.2,807.3,1.68,1.41,0,0,0,0.1,0.1);

	this.instance_10 = new lib.CFishtank_heater();
	this.instance_10.parent = this;
	this.instance_10.setTransform(866.8,756.2,1.646,1.646);

	this.instance_11 = new lib.calendarpin_1();
	this.instance_11.parent = this;
	this.instance_11.setTransform(1186.1,327.5,2,2);

	this.instance_12 = new lib.calendarnew_1();
	this.instance_12.parent = this;
	this.instance_12.setTransform(1188.4,453.4,2,2);

	this.S_wewilladd2 = new cjs.Text("We will add fifty grams of algae to a fish tank filled with 16 liters of distilled water.", "bold 45px 'PT Sans'");
	this.S_wewilladd2.name = "S_wewilladd2";
	this.S_wewilladd2.textAlign = "center";
	this.S_wewilladd2.lineHeight = 60;
	this.S_wewilladd2.lineWidth = 1832;
	this.S_wewilladd2.parent = this;
	this.S_wewilladd2.setTransform(960,122.8);

	this.instance_13 = new lib.CScale();
	this.instance_13.parent = this;
	this.instance_13.setTransform(1265.6,958.6,1,1,0,0,0,-0.5,1);

	this.instance_14 = new lib.Background_intro();
	this.instance_14.parent = this;
	this.instance_14.setTransform(922.1,678.9,1,1,0,0,0,-0.3,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_14},{t:this.instance_13},{t:this.S_wewilladd2},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// SceneRegion
	this.instance_15 = new lib.TC_TVirtual__SceneRgn();
	this.instance_15.parent = this;
	this.instance_15.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__RQintro3, new cjs.Rectangle(-1.2,-1.2,1922.5,1202.5), null);


(lib.TC_TScene__RQintro2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.Chandholdingalgae();
	this.instance.parent = this;
	this.instance.setTransform(718.1,681.8,1.521,1.521,0,0,0,-0.1,-0.1);

	this.instance_1 = new lib.CAlgaeSmall();
	this.instance_1.parent = this;
	this.instance_1.setTransform(738.2,715.8,1.322,1.322,60);

	this.instance_2 = new lib.CScalecopy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1180.5,919.6,1.071,1,0,0,0,-0.5,1);

	this.instance_3 = new lib.calendarpin();
	this.instance_3.parent = this;
	this.instance_3.setTransform(1187,341.1);

	this.instance_4 = new lib.calendarnew();
	this.instance_4.parent = this;
	this.instance_4.setTransform(1192,456.1,1.919,1.853);

	this.instance_5 = new lib.squareco2bubbles();
	this.instance_5.parent = this;
	this.instance_5.setTransform(645,837.2,1.15,1.15,0,0,0,0.1,-0.1);

	this.instance_6 = new lib.TC_TObject__CThermometerHot();
	this.instance_6.parent = this;
	this.instance_6.setTransform(787.8,867.6,1.617,1.617,0,0,0,0,0.1);

	this.instance_7 = new lib.NewCombinedWater();
	this.instance_7.parent = this;
	this.instance_7.setTransform(735.7,862,1.634,1.665,0,0,0,-0.2,0.1);

	this.instance_8 = new lib.CFishtank_heater();
	this.instance_8.parent = this;
	this.instance_8.setTransform(866.8,756.2,1.646,1.646);

	this.instance_9 = new lib.calendarpin_1();
	this.instance_9.parent = this;
	this.instance_9.setTransform(1186.1,327.5,2,2);

	this.instance_10 = new lib.calendarnew_1();
	this.instance_10.parent = this;
	this.instance_10.setTransform(1188.4,453.4,2,2);

	this.S_wewilladd1 = new cjs.Text("We will add fifty grams of algae to a fish tank filled with 16 liters of distilled water.", "bold 45px 'PT Sans'");
	this.S_wewilladd1.name = "S_wewilladd1";
	this.S_wewilladd1.textAlign = "center";
	this.S_wewilladd1.lineHeight = 60;
	this.S_wewilladd1.lineWidth = 1832;
	this.S_wewilladd1.parent = this;
	this.S_wewilladd1.setTransform(960,122.8);

	this.instance_11 = new lib.CScale();
	this.instance_11.parent = this;
	this.instance_11.setTransform(1265.6,958.6,1,1,0,0,0,-0.5,1);

	this.instance_12 = new lib.squarefishtank();
	this.instance_12.parent = this;
	this.instance_12.setTransform(736.7,832.7,1.646,1.646);

	this.instance_13 = new lib.squareco2machine();
	this.instance_13.parent = this;
	this.instance_13.setTransform(640.2,807.3,1.68,1.41,0,0,0,0.1,0.1);

	this.instance_14 = new lib.Background_intro();
	this.instance_14.parent = this;
	this.instance_14.setTransform(922.1,678.9,1,1,0,0,0,-0.3,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.S_wewilladd1},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// SceneRegion
	this.instance_15 = new lib.TC_TVirtual__SceneRgn();
	this.instance_15.parent = this;
	this.instance_15.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__RQintro2, new cjs.Rectangle(-1.2,-1.2,1922.5,1202.5), null);


(lib.TC_TScene__RQintro1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// squaretintedfishtanklid
	this.instance = new lib.squaretintedfishtanklid();
	this.instance.parent = this;
	this.instance.setTransform(625.3,711.2,1.719,1.719);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// CScale copy
	this.instance_1 = new lib.CScalecopy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1180.5,919.6,1.071,1,0,0,0,-0.5,1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// calendarpin
	this.instance_2 = new lib.calendarpin();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1187,341.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// calendarnew
	this.instance_3 = new lib.calendarnew();
	this.instance_3.parent = this;
	this.instance_3.setTransform(1192,456.1,1.919,1.853);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// squareco2bubbles
	this.instance_4 = new lib.squareco2bubbles();
	this.instance_4.parent = this;
	this.instance_4.setTransform(645,837.2,1.15,1.15,0,0,0,0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// CThermometerHot
	this.instance_5 = new lib.TC_TObject__CThermometerHot();
	this.instance_5.parent = this;
	this.instance_5.setTransform(787.8,867.6,1.617,1.617,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// NewCombinedWater
	this.instance_6 = new lib.NewCombinedWater();
	this.instance_6.parent = this;
	this.instance_6.setTransform(735.7,862,1.634,1.665,0,0,0,-0.2,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

	// CFishtank_heater
	this.instance_7 = new lib.CFishtank_heater();
	this.instance_7.parent = this;
	this.instance_7.setTransform(866.8,756.2,1.646,1.646);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1));

	// calendarpin
	this.instance_8 = new lib.calendarpin_1();
	this.instance_8.parent = this;
	this.instance_8.setTransform(1186.1,327.5,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

	// calendarnew
	this.instance_9 = new lib.calendarnew_1();
	this.instance_9.parent = this;
	this.instance_9.setTransform(1188.4,453.4,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1));

	// CScale
	this.instance_10 = new lib.CScale();
	this.instance_10.parent = this;
	this.instance_10.setTransform(1265.6,958.6,1,1,0,0,0,-0.5,1);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(1));

	// squarefishtank
	this.instance_11 = new lib.squarefishtank();
	this.instance_11.parent = this;
	this.instance_11.setTransform(736.7,832.7,1.646,1.646);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(1));

	// squareco2machine
	this.instance_12 = new lib.squareco2machine();
	this.instance_12.parent = this;
	this.instance_12.setTransform(640.2,807.3,1.68,1.41,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(1));

	// Background_intro
	this.instance_13 = new lib.Background_intro();
	this.instance_13.parent = this;
	this.instance_13.setTransform(922.1,678.9,1,1,0,0,0,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(1));

	// S_algaeexperimentworks
	this.S_algaeexperimentworks = new cjs.Text("Let's see how this experiment works.", "bold 70px 'PT Sans'");
	this.S_algaeexperimentworks.name = "S_algaeexperimentworks";
	this.S_algaeexperimentworks.textAlign = "center";
	this.S_algaeexperimentworks.lineHeight = 93;
	this.S_algaeexperimentworks.lineWidth = 1377;
	this.S_algaeexperimentworks.parent = this;
	this.S_algaeexperimentworks.setTransform(960,108.8);

	this.timeline.addTween(cjs.Tween.get(this.S_algaeexperimentworks).wait(1));

	// SceneRegion
	this.instance_14 = new lib.TC_TVirtual__SceneRgn();
	this.instance_14.parent = this;
	this.instance_14.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__RQintro1, new cjs.Rectangle(-1.2,-1.2,1922.5,1202.5), null);


(lib.TC_TObject__Expt3b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TC_TObject__Callout3b();
	this.instance.parent = this;
	this.instance.setTransform(196.6,247,1,1,0,0,0,131.3,37.6);

	this.Shighlight = new lib.TC_TObject__Highlight();
	this.Shighlight.name = "Shighlight";
	this.Shighlight.parent = this;
	this.Shighlight.setTransform(277.3,263,1,1,0,0,0,63.5,25);

	this.instance_1 = new lib.CFishTank_water();
	this.instance_1.parent = this;
	this.instance_1.setTransform(147.7,129.6,0.989,0.989);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.Shighlight},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Expt3b, new cjs.Rectangle(5.2,3.6,336.2,285), null);


(lib.TC_TObject__Expt3a = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.ScallOut = new lib.TC_TObject__Callout3a();
	this.ScallOut.name = "ScallOut";
	this.ScallOut.parent = this;
	this.ScallOut.setTransform(196.6,247,1,1,0,0,0,131.3,37.6);

	this.Shighlight = new lib.TC_TObject__Highlight();
	this.Shighlight.name = "Shighlight";
	this.Shighlight.parent = this;
	this.Shighlight.setTransform(277.7,261,1,1,0,0,0,63.5,25);

	this.instance = new lib.CFishTank_water();
	this.instance.parent = this;
	this.instance.setTransform(147.7,129.6,0.989,0.989);

	this.Svar3a = new lib.TC_TObject__co2machine();
	this.Svar3a.name = "Svar3a";
	this.Svar3a.parent = this;
	this.Svar3a.setTransform(53.8,125.5,0.791,0.791,0,0,0,24.7,111.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Svar3a},{t:this.instance},{t:this.Shighlight},{t:this.ScallOut}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Expt3a, new cjs.Rectangle(5.2,3.6,336.6,283), null);


(lib.TC_TTEDExpt__TEDExpt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{Svar1a:0});

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AmmjIIW5AAIn+GRI4nAAg");
	this.shape.setTransform(729.1,273.1,1.35,1.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AwSDJIJsmRIW5AAIn/GRg");
	this.shape_1.setTransform(729.1,273.1,1.35,1.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// TC_TObject__Svar1a
	this.Svar1a = new lib.TC_TObject__Expt1a();
	this.Svar1a.name = "Svar1a";
	this.Svar1a.parent = this;
	this.Svar1a.setTransform(902.7,391.1,1,1,0,0,0,150.2,59.6);

	this.timeline.addTween(cjs.Tween.get(this.Svar1a).wait(1));

	// TC_TObject__Expt1b
	this.Svar1b = new lib.TC_TObject__Expt1b();
	this.Svar1b.name = "Svar1b";
	this.Svar1b.parent = this;
	this.Svar1b.setTransform(903.7,370.8,1,1,0,0,0,150.7,79.8);

	this.timeline.addTween(cjs.Tween.get(this.Svar1b).wait(1));

	// TC_TObject__Svar2a
	this.Svar2a = new lib.TC_TObject__Expt2a();
	this.Svar2a.name = "Svar2a";
	this.Svar2a.parent = this;
	this.Svar2a.setTransform(427.9,410.7,1,1,0,0,0,104.6,81.8);

	this.timeline.addTween(cjs.Tween.get(this.Svar2a).wait(1));

	// TC_TObject__Svar2b
	this.Svar2b = new lib.TC_TObject__CRadionomusic();
	this.Svar2b.name = "Svar2b";
	this.Svar2b.parent = this;
	this.Svar2b.setTransform(563,496.6,1,1,0,0,0,104.6,81.8);

	this.timeline.addTween(cjs.Tween.get(this.Svar2b).wait(1));

	// TC_TObject__Svar3a
	this.Svar3a = new lib.TC_TObject__Expt3a();
	this.Svar3a.name = "Svar3a";
	this.Svar3a.parent = this;
	this.Svar3a.setTransform(752,390.5,1,1,0,0,0,170.6,142.9);

	this.timeline.addTween(cjs.Tween.get(this.Svar3a).wait(1));

	// TC_TObject__Svar3b
	this.Svar3b = new lib.TC_TObject__Expt3b();
	this.Svar3b.name = "Svar3b";
	this.Svar3b.parent = this;
	this.Svar3b.setTransform(751.1,391,1,1,0,0,0,170.3,143.9);

	this.timeline.addTween(cjs.Tween.get(this.Svar3b).wait(1));

	// TC_TObject__Svar4a
	this.Svar4a = new lib.TC_TObject__Expt4a();
	this.Svar4a.name = "Svar4a";
	this.Svar4a.parent = this;
	this.Svar4a.setTransform(577.8,334.9,1,1,0,0,0,299.7,211.3);

	this.timeline.addTween(cjs.Tween.get(this.Svar4a).wait(1));

	// TC_TObject__Svar4b
	this.Svar4b = new lib.TC_TObject__Expt4b();
	this.Svar4b.name = "Svar4b";
	this.Svar4b.parent = this;
	this.Svar4b.setTransform(577.8,334.8,1,1,0,0,0,299.7,211.2);

	this.timeline.addTween(cjs.Tween.get(this.Svar4b).wait(1));

	// Stag1
	this.Stag1 = new lib.TC_THtmlText__CallOutText();
	this.Stag1.name = "Stag1";
	this.Stag1.parent = this;
	this.Stag1.setTransform(130,130,2.4,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.Stag1).wait(1));

	// Shighlight1
	this.Shighlight1 = new lib.TC_TObject__CallOutHighlight();
	this.Shighlight1.name = "Shighlight1";
	this.Shighlight1.parent = this;
	this.Shighlight1.setTransform(73.7,105.1,1,1,0,0,0,63.7,25.1);

	this.timeline.addTween(cjs.Tween.get(this.Shighlight1).wait(1));

	// Stag2
	this.Stag2 = new lib.TC_THtmlText__CallOutText();
	this.Stag2.name = "Stag2";
	this.Stag2.parent = this;
	this.Stag2.setTransform(130,261.8,2.4,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.Stag2).wait(1));

	// Shighlight2
	this.Shighlight2 = new lib.TC_TObject__CallOutHighlight();
	this.Shighlight2.name = "Shighlight2";
	this.Shighlight2.parent = this;
	this.Shighlight2.setTransform(73.7,236.9,1,1,0,0,0,63.7,25.1);

	this.timeline.addTween(cjs.Tween.get(this.Shighlight2).wait(1));

	// Stag3
	this.Stag3 = new lib.TC_THtmlText__CallOutText();
	this.Stag3.name = "Stag3";
	this.Stag3.parent = this;
	this.Stag3.setTransform(130,393.6,2.4,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.Stag3).wait(1));

	// Shighlight3
	this.Shighlight3 = new lib.TC_TObject__CallOutHighlight();
	this.Shighlight3.name = "Shighlight3";
	this.Shighlight3.parent = this;
	this.Shighlight3.setTransform(73.7,368.7,1,1,0,0,0,63.7,25.1);

	this.timeline.addTween(cjs.Tween.get(this.Shighlight3).wait(1));

	// Stag4
	this.Stag4 = new lib.TC_THtmlText__CallOutText();
	this.Stag4.name = "Stag4";
	this.Stag4.parent = this;
	this.Stag4.setTransform(130,525.5,2.4,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.Stag4).wait(1));

	// Shighlight4
	this.Shighlight4 = new lib.TC_TObject__CallOutHighlight();
	this.Shighlight4.name = "Shighlight4";
	this.Shighlight4.parent = this;
	this.Shighlight4.setTransform(73.7,500.6,1,1,0,0,0,63.7,25.1);

	this.timeline.addTween(cjs.Tween.get(this.Shighlight4).wait(1));

	// Region
	this.instance = new lib.TC_TVirtual__ExptRgn();
	this.instance.parent = this;
	this.instance.setTransform(473.9,328.5,1,1,0,0,0,474.9,329.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TTEDExpt__TEDExpt, new cjs.Rectangle(-1,-0.9,1054.5,659), null);


(lib.TC_TObject__Vars = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_13
	this.instance = new lib.squaretintedfishtanklid();
	this.instance.parent = this;
	this.instance.setTransform(419,150.5,1.432,1.432);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Svar1a
	this.Svar1a = new lib.TC_TObject__CThermometerRoomTemp();
	this.Svar1a.name = "Svar1a";
	this.Svar1a.parent = this;
	this.Svar1a.setTransform(462.3,269.8,1.416,1.416,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.Svar1a).wait(1));

	// Svar1b
	this.Svar1b = new lib.TC_TObject__CThermometerHot();
	this.Svar1b.name = "Svar1b";
	this.Svar1b.parent = this;
	this.Svar1b.setTransform(462,268.6,1.39,1.39);

	this.timeline.addTween(cjs.Tween.get(this.Svar1b).wait(1));

	// CFishTank_water
	this.instance_1 = new lib.CFishTank_water();
	this.instance_1.parent = this;
	this.instance_1.setTransform(421.4,255.7,0.989,0.989);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Svar2a
	this.Svar2a = new lib.TC_TObject__CRadio();
	this.Svar2a.name = "Svar2a";
	this.Svar2a.parent = this;
	this.Svar2a.setTransform(176.5,287.6,0.989,0.989,0,0,0,-0.2,0.1);

	this.timeline.addTween(cjs.Tween.get(this.Svar2a).wait(1));

	// Svar2b
	this.Svar2b = new lib.TC_TObject__CRadionomusic();
	this.Svar2b.name = "Svar2b";
	this.Svar2b.parent = this;
	this.Svar2b.setTransform(176.5,287.6,0.989,0.989,0,0,0,-0.2,0.1);

	this.timeline.addTween(cjs.Tween.get(this.Svar2b).wait(1));

	// Svar3a
	this.Svar3a = new lib.TC_TObject__co2machine();
	this.Svar3a.name = "Svar3a";
	this.Svar3a.parent = this;
	this.Svar3a.setTransform(322.5,247.4,0.989,0.989,0,0,0,24.7,111.1);

	this.timeline.addTween(cjs.Tween.get(this.Svar3a).wait(1));

	// Svar3b
	this.Svar3b = new lib.TC_TObject__co2machine();
	this.Svar3b.name = "Svar3b";
	this.Svar3b.parent = this;
	this.Svar3b.setTransform(322.5,247.4,0.989,0.989,0,0,0,24.7,111.1);
	this.Svar3b.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.Svar3b).wait(1));

	// Svar4a
	this.Svar4a = new lib.TC_TObject__CBackgroundSun();
	this.Svar4a.name = "Svar4a";
	this.Svar4a.parent = this;
	this.Svar4a.setTransform(288.9,210.5,1.046,1.046,0,0,0,0.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.Svar4a).wait(1));

	// Svar4b
	this.Svar4b = new lib.TC_TObject__Shade();
	this.Svar4b.name = "Svar4b";
	this.Svar4b.parent = this;
	this.Svar4b.setTransform(192.2,103.2,0.583,0.584,0,0,0,0,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.Svar4b).wait(1));

	// CTable
	this.instance_2 = new lib.CTable();
	this.instance_2.parent = this;
	this.instance_2.setTransform(299.6,364.7,1.089,1.089,0,0,0,275.2,53.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Vars, new cjs.Rectangle(-0.5,0,600.6,422.7), null);


(lib.TC_TObject__Topic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Thermometer
	this.Svar1a = new lib.TC_TObject__CThermometerRoomTemp();
	this.Svar1a.name = "Svar1a";
	this.Svar1a.parent = this;
	this.Svar1a.setTransform(188.6,143.7,1.416,1.416,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.Svar1a).wait(1));

	// algae
	this.instance = new lib.CAlgaeLarge();
	this.instance.parent = this;
	this.instance.setTransform(128.9,95.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// CFishTank_water
	this.instance_1 = new lib.CFishTank_water();
	this.instance_1.parent = this;
	this.instance_1.setTransform(147.7,129.6,0.989,0.989);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Topic, new cjs.Rectangle(5.2,3.6,283.5,256.3), null);


(lib.TC_TMaterialIcon__tank = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Stitle = new cjs.Text("Fish tank with\n16 liters\nof distilled water", "bold 40px 'PT Sans'");
	this.Stitle.name = "Stitle";
	this.Stitle.textAlign = "center";
	this.Stitle.lineHeight = 54;
	this.Stitle.parent = this;
	this.Stitle.setTransform(241.8,311.4,0.865,0.865);

	this.Sicon = new lib.CFishTank_water();
	this.Sicon.name = "Sicon";
	this.Sicon.parent = this;
	this.Sicon.setTransform(281.6,152.5,1.163,1.163,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Sicon},{t:this.Stitle}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TMaterialIcon__tank, new cjs.Rectangle(113.9,4.2,333.5,446.6), null);


(lib.TC_TScene__RQmaterials = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Svar5
	this.Svar5 = new lib.TC_TMaterialIcon__algae();
	this.Svar5.name = "Svar5";
	this.Svar5.parent = this;
	this.Svar5.setTransform(343.9,863.3,1,1,0,0,0,148.7,94.5);

	this.timeline.addTween(cjs.Tween.get(this.Svar5).wait(1));

	// Svar6
	this.Svar6 = new lib.TC_TMaterialIcon__tank();
	this.Svar6.name = "Svar6";
	this.Svar6.parent = this;
	this.Svar6.setTransform(749.9,866.8,1,1,0,0,0,227.5,225);

	this.timeline.addTween(cjs.Tween.get(this.Svar6).wait(1));

	// Svar7
	this.Svar7 = new lib.TC_TMaterialIcon__thermometer();
	this.Svar7.name = "Svar7";
	this.Svar7.parent = this;
	this.Svar7.setTransform(1130,846.8,1,1,0,0,0,158.5,173.5);

	this.timeline.addTween(cjs.Tween.get(this.Svar7).wait(1));

	// Svar8
	this.Sarrow8 = new lib.TC_TObject__Arrow();
	this.Sarrow8.name = "Sarrow8";
	this.Sarrow8.parent = this;
	this.Sarrow8.setTransform(1400.1,802.9,1,1,-105,0,0,-3.4,1.1);
	this.Sarrow8.shadow = new cjs.Shadow("rgba(51,51,51,1)",11,11,15);

	this.Sarrow7 = new lib.TC_TObject__Arrow();
	this.Sarrow7.name = "Sarrow7";
	this.Sarrow7.parent = this;
	this.Sarrow7.setTransform(1054.9,917,1,1,-105,0,0,-3.4,1.1);
	this.Sarrow7.shadow = new cjs.Shadow("rgba(51,51,51,1)",11,11,15);

	this.Sarrow6 = new lib.TC_TObject__Arrow();
	this.Sarrow6.name = "Sarrow6";
	this.Sarrow6.parent = this;
	this.Sarrow6.setTransform(541.4,1032.8,1,1,-105,0,0,-3.4,1.1);
	this.Sarrow6.shadow = new cjs.Shadow("rgba(51,51,51,1)",11,11,15);

	this.Sarrow5 = new lib.TC_TObject__Arrow();
	this.Sarrow5.name = "Sarrow5";
	this.Sarrow5.parent = this;
	this.Sarrow5.setTransform(226.9,830.9,1,1,-105,0,0,-3.4,1.1);
	this.Sarrow5.shadow = new cjs.Shadow("rgba(51,51,51,1)",11,11,15);

	this.Sarrow4 = new lib.TC_TObject__Arrow();
	this.Sarrow4.name = "Sarrow4";
	this.Sarrow4.parent = this;
	this.Sarrow4.setTransform(1452.7,431.6,1,1,-105,0,0,-3.4,1.1);
	this.Sarrow4.shadow = new cjs.Shadow("rgba(51,51,51,1)",11,11,15);

	this.Sarrow3 = new lib.TC_TObject__Arrow();
	this.Sarrow3.name = "Sarrow3";
	this.Sarrow3.parent = this;
	this.Sarrow3.setTransform(940.7,513.5,1,1,-105,0,0,-3.4,1.1);
	this.Sarrow3.shadow = new cjs.Shadow("rgba(51,51,51,1)",11,11,15);

	this.Sarrow2 = new lib.TC_TObject__Arrow();
	this.Sarrow2.name = "Sarrow2";
	this.Sarrow2.parent = this;
	this.Sarrow2.setTransform(579.4,561.7,1,1,-105,0,0,-3.4,1.1);
	this.Sarrow2.shadow = new cjs.Shadow("rgba(51,51,51,1)",11,11,15);

	this.Sarrow1 = new lib.TC_TObject__Arrow();
	this.Sarrow1.name = "Sarrow1";
	this.Sarrow1.parent = this;
	this.Sarrow1.setTransform(137.6,478.3,1,1,-105,0,0,-3.4,1.1);
	this.Sarrow1.shadow = new cjs.Shadow("rgba(51,51,51,1)",11,11,15);

	this.Svar8 = new lib.TC_TMaterialIcon__co2();
	this.Svar8.name = "Svar8";
	this.Svar8.parent = this;
	this.Svar8.setTransform(1497.5,765.8,1,1,0,0,0,131.7,197.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Svar8},{t:this.Sarrow1},{t:this.Sarrow2},{t:this.Sarrow3},{t:this.Sarrow4},{t:this.Sarrow5},{t:this.Sarrow6},{t:this.Sarrow7},{t:this.Sarrow8}]}).wait(1));

	// Svar4
	this.Svar4 = new lib.TC_TMaterialIcon__heater();
	this.Svar4.name = "Svar4";
	this.Svar4.parent = this;
	this.Svar4.setTransform(1563.9,362,1,1,0,0,0,142.3,128);

	this.timeline.addTween(cjs.Tween.get(this.Svar4).wait(1));

	// Svar3
	this.Svar3 = new lib.TC_TMaterialIcon__scale();
	this.Svar3.name = "Svar3";
	this.Svar3.parent = this;
	this.Svar3.setTransform(1153.7,428.5,1,1,0,0,0,239.9,115.5);

	this.timeline.addTween(cjs.Tween.get(this.Svar3).wait(1));

	// Svar2
	this.Svar2 = new lib.TC_TMaterialIcon__calendar();
	this.Svar2.name = "Svar2";
	this.Svar2.parent = this;
	this.Svar2.setTransform(709.6,435.5,1,1,0,0,0,150.5,149.6);

	this.timeline.addTween(cjs.Tween.get(this.Svar2).wait(1));

	// Svar1
	this.Svar1 = new lib.TC_TMaterialIcon__radio();
	this.Svar1.name = "Svar1";
	this.Svar1.parent = this;
	this.Svar1.setTransform(348.6,429.6,1,1,0,0,0,145.8,166.8);

	this.timeline.addTween(cjs.Tween.get(this.Svar1).wait(1));

	// Stitle
	this.Stitle = new cjs.Text("Here are all of the materials that may be necessary for this experiment:", "bold 50px 'PT Sans'");
	this.Stitle.name = "Stitle";
	this.Stitle.lineHeight = 67;
	this.Stitle.parent = this;
	this.Stitle.setTransform(190.4,99.1);

	this.timeline.addTween(cjs.Tween.get(this.Stitle).wait(1));

	// SceneRegion
	this.instance = new lib.TC_TVirtual__SceneRgn();
	this.instance.parent = this;
	this.instance.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__RQmaterials, new cjs.Rectangle(-1.2,-1.2,1922.5,1202.5), null);


(lib.TC_TScene__RQenumVars = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.SsubTitle2 = new lib.TC_THtmlText__Text1();
	this.SsubTitle2.name = "SsubTitle2";
	this.SsubTitle2.parent = this;
	this.SsubTitle2.setTransform(1371.4,972.4,5.494,1.278,0,0,0,50.3,50);

	this.Sicon2 = new lib.TC_TObject__Vars();
	this.Sicon2.name = "Sicon2";
	this.Sicon2.parent = this;
	this.Sicon2.setTransform(1369.5,658.5,1,1,0,0,0,299.7,211.3);

	this.SsubTitle1 = new lib.TC_THtmlText__Text1();
	this.SsubTitle1.name = "SsubTitle1";
	this.SsubTitle1.parent = this;
	this.SsubTitle1.setTransform(551.9,972.4,5.494,1.278,0,0,0,50.3,50);

	this.Sicon1 = new lib.TC_TObject__Vars();
	this.Sicon1.name = "Sicon1";
	this.Sicon1.parent = this;
	this.Sicon1.setTransform(550,658.5,1,1,0,0,0,299.7,211.3);

	this.Stitle = new lib.TC_THtmlText__Text1();
	this.Stitle.name = "Stitle";
	this.Stitle.parent = this;
	this.Stitle.setTransform(973.5,250.8,14.918,2.193,0,0,0,50.9,50.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Stitle},{t:this.Sicon1},{t:this.SsubTitle1},{t:this.Sicon2},{t:this.SsubTitle2}]}).wait(1));

	// Layer_1
	this.instance = new lib.TC_TVirtual__SceneRgn();
	this.instance.parent = this;
	this.instance.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__RQenumVars, new cjs.Rectangle(-1.2,-1.2,1922.5,1202.5), null);


// stage content:
(lib.EFMod_Algae = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(10));

	// Module Component
	this.instance = new lib.ef_TutorModule({'id': '', 'compositionID':'28FA7C3B9363D635B16ED4FEE4764CA0'});

	this.instance.setTransform(960,600,1,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(9));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1869.5,1149.5,101,101);
// library properties:
lib.properties = {
	id: '28FA7C3B9363D635B16ED4FEE4764CA0',
	width: 1920,
	height: 1200,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"components/EFComponents/src/ef_loadManager.js", id:"EFComponents/src/ef_loadManager.js"},
		{src:"components/EFComponents/src/ef_module.js", id:"ef.TutorModule"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['28FA7C3B9363D635B16ED4FEE4764CA0'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}

function _updateVisibility(evt) {
	if((this.getStage() == null || this._off || this._lastAddedFrame != this.parent.currentFrame) && this._element) {
		this._element.detach();
		stage.removeEventListener('drawstart', this._updateVisibilityCbk);
		this._updateVisibilityCbk = false;
	}
}
function _handleDrawEnd(evt) {
	var props = this.getConcatenatedDisplayProps(this._props), mat = props.matrix;
	var tx1 = mat.decompose(); var sx = tx1.scaleX; var sy = tx1.scaleY;
	var dp = window.devicePixelRatio || 1; var w = this.nominalBounds.width * sx; var h = this.nominalBounds.height * sy;
	mat.tx/=dp;mat.ty/=dp; mat.a/=(dp*sx);mat.b/=(dp*sx);mat.c/=(dp*sy);mat.d/=(dp*sy);
	this._element.setProperty('transform-origin', this.regX + 'px ' + this.regY + 'px');
	var x = (mat.tx + this.regX*mat.a + this.regY*mat.c - this.regX);
	var y = (mat.ty + this.regX*mat.b + this.regY*mat.d - this.regY);
	var tx = 'matrix(' + mat.a + ',' + mat.b + ',' + mat.c + ',' + mat.d + ',' + x + ',' + y + ')';
	this._element.setProperty('transform', tx);
	this._element.setProperty('width', w);
	this._element.setProperty('height', h);
	this._element.update();
}

function _tick(evt) {
	var stage = this.getStage();
	stage&&stage.on('drawend', this._handleDrawEnd, this, true);
	if(!this._updateVisibilityCbk) {
		this._updateVisibilityCbk = stage.on('drawstart', this._updateVisibility, this, false);
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;