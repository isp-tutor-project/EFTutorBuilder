(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"EFMod_RQSelect_atlas_", frames: [[552,0,400,400],[0,0,550,400]]}
];


// symbols:



(lib.Arrows = function() {
	this.spriteSheet = ss["EFMod_RQSelect_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.tshirtstickfigures = function() {
	this.spriteSheet = ss["EFMod_RQSelect_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.TC_TScene__SceneEnd = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#FFFFFF").ss(56.6,1,1).dr(-960,-600,1920,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__SceneEnd, new cjs.Rectangle(-28.3,-28.3,1976.6,1256.6), null);


(lib.TL_Soda__Topic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-125.65,-451.55,251.3,903.1);
	this.shape.setTransform(125.6,451.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Soda__Topic, new cjs.Rectangle(0,0,251.3,903.1), null);


(lib.TL_Soda__TEDQuest = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Soda__TEDQuest, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Soda__TEDExpt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Soda__TEDExpt, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Soda__RQmovie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Soda__RQmovie, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Soda__RQintro4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Soda__RQintro4, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Soda__RQintro3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Soda__RQintro3, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Soda__RQintro2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Soda__RQintro2, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Soda__RQintro1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Soda__RQintro1, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Soda__RQenumVars = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Soda__RQenumVars, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Soda__Movie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-300.15,-217.55,600.3,435.1);
	this.shape.setTransform(300.2,217.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Soda__Movie, new cjs.Rectangle(0,0,600.4,435.1), null);


(lib.TL_Sinking__Topic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-146.75,-377.35,293.5,754.7);
	this.shape.setTransform(146.7,377.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Sinking__Topic, new cjs.Rectangle(0,0,293.5,754.7), null);


(lib.TL_Sinking__TEDQuest = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Sinking__TEDQuest, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Sinking__TEDExpt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Sinking__TEDExpt, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Sinking__RQmovie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Sinking__RQmovie, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Sinking__RQintro4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Sinking__RQintro4, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Sinking__RQintro3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Sinking__RQintro3, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Sinking__RQintro2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Sinking__RQintro2, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Sinking__RQintro1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Sinking__RQintro1, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Sinking__RQenumVars = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Sinking__RQenumVars, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Sinking__Movie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-300.15,-217.55,600.3,435.1);
	this.shape.setTransform(300.2,217.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Sinking__Movie, new cjs.Rectangle(0,0,600.4,435.1), null);


(lib.TL_Ramps__Topic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-246,-171.9,492,343.8);
	this.shape.setTransform(246,171.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Ramps__Topic, new cjs.Rectangle(0,0,492.1,343.8), null);


(lib.TL_Ramps__TEDQuest = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Ramps__TEDQuest, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Ramps__TEDExpt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Ramps__TEDExpt, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Ramps__RQmovie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Ramps__RQmovie, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Ramps__RQintro4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Ramps__RQintro4, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Ramps__RQintro3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Ramps__RQintro3, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Ramps__RQintro2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Ramps__RQintro2, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Ramps__RQintro1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Ramps__RQintro1, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Ramps__RQenumVars = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Ramps__RQenumVars, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Ramps__Movie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-300.15,-217.55,600.3,435.1);
	this.shape.setTransform(300.2,217.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Ramps__Movie, new cjs.Rectangle(0,0,600.4,435.1), null);


(lib.TL_IceMelt__Topic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-274.95,-147.85,549.9,295.7);
	this.shape.setTransform(275,147.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_IceMelt__Topic, new cjs.Rectangle(0,0,550,295.7), null);


(lib.TL_IceMelt__TEDQuest = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_IceMelt__TEDQuest, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_IceMelt__TEDExpt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_IceMelt__TEDExpt, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_IceMelt__RQmovie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_IceMelt__RQmovie, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_IceMelt__RQintro4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_IceMelt__RQintro4, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_IceMelt__RQintro3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_IceMelt__RQintro3, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_IceMelt__RQintro2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_IceMelt__RQintro2, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_IceMelt__RQintro1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_IceMelt__RQintro1, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_IceMelt__RQenumVars = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_IceMelt__RQenumVars, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_IceMelt__Movie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-300.15,-217.55,600.3,435.1);
	this.shape.setTransform(300.2,217.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_IceMelt__Movie, new cjs.Rectangle(0,0,600.4,435.1), null);


(lib.TL_GrHouse__Topic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-524.4,-354.05,1048.8,708.1);
	this.shape.setTransform(524.5,354.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_GrHouse__Topic, new cjs.Rectangle(0,0,1049,708.1), null);


(lib.TL_GrHouse__TEDQuest = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_GrHouse__TEDQuest, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_GrHouse__TEDExpt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_GrHouse__TEDExpt, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_GrHouse__RQmovie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_GrHouse__RQmovie, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_GrHouse__RQintro4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_GrHouse__RQintro4, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_GrHouse__RQintro3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_GrHouse__RQintro3, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_GrHouse__RQintro2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_GrHouse__RQintro2, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_GrHouse__RQintro1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_GrHouse__RQintro1, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_GrHouse__RQenumVars = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_GrHouse__RQenumVars, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_GrHouse__Movie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-300.15,-217.55,600.3,435.1);
	this.shape.setTransform(300.2,217.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_GrHouse__Movie, new cjs.Rectangle(0,0,600.4,435.1), null);


(lib.TL_Crystal__Topic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-182.25,-197.45,364.5,394.9);
	this.shape.setTransform(182.3,197.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Crystal__Topic, new cjs.Rectangle(0,0,364.5,394.9), null);


(lib.TL_Crystal__TEDQuest = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Crystal__TEDQuest, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Crystal__TEDExpt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Crystal__TEDExpt, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Crystal__RQmovie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Crystal__RQmovie, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Crystal__RQintro4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Crystal__RQintro4, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Crystal__RQintro3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Crystal__RQintro3, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Crystal__RQintro2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Crystal__RQintro2, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Crystal__RQintro1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Crystal__RQintro1, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Crystal__RQenumVars = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Crystal__RQenumVars, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Crystal__Movie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-300.15,-217.55,600.3,435.1);
	this.shape.setTransform(300.2,217.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Crystal__Movie, new cjs.Rectangle(0,0,600.4,435.1), null);


(lib.TL_Balloon__Topic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-258.45,-249.45,516.9,498.9);
	this.shape.setTransform(258.5,249.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Balloon__Topic, new cjs.Rectangle(0,0,517,498.9), null);


(lib.TL_Balloon__TEDQuest = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Balloon__TEDQuest, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Balloon__TEDExpt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Balloon__TEDExpt, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Balloon__RQmovie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Balloon__RQmovie, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Balloon__RQintro4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Balloon__RQintro4, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Balloon__RQintro3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Balloon__RQintro3, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Balloon__RQintro2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Balloon__RQintro2, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Balloon__RQintro1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Balloon__RQintro1, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Balloon__RQenumVars = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Balloon__RQenumVars, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Balloon__Movie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-300.15,-217.55,600.3,435.1);
	this.shape.setTransform(300.2,217.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Balloon__Movie, new cjs.Rectangle(0,0,600.4,435.1), null);


(lib.TL_Algae__Topic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-148.5,-130.5,297,261);
	this.shape.setTransform(148.5,130.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Algae__Topic, new cjs.Rectangle(0,0,297,261), null);


(lib.TL_Algae__TEDQuest = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Algae__TEDQuest, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Algae__TEDExpt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Algae__TEDExpt, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Algae__RQmovie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Algae__RQmovie, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Algae__RQintro4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Algae__RQintro4, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Algae__RQintro3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Algae__RQintro3, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Algae__RQintro2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Algae__RQintro2, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Algae__RQintro1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Algae__RQintro1, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Algae__RQenumVars = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-959.85,-600,1919.7,1200);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Algae__RQenumVars, new cjs.Rectangle(0,0,1920,1200), null);


(lib.TL_Algae__Movie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0000FF").s().dr(-300.15,-217.55,600.3,435.1);
	this.shape.setTransform(300.2,217.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TL_Algae__Movie, new cjs.Rectangle(0,0,600.4,435.1), null);


(lib.TC_TText__Area4Title = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Stitle = new cjs.Text("Plant Reproduction", "bold 32px 'PT Sans'", "#333333");
	this.Stitle.name = "Stitle";
	this.Stitle.textAlign = "center";
	this.Stitle.lineHeight = 43;
	this.Stitle.lineWidth = 425;
	this.Stitle.parent = this;
	this.Stitle.setTransform(214.4,2);

	this.timeline.addTween(cjs.Tween.get(this.Stitle).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TText__Area4Title, new cjs.Rectangle(0,0,428.8,52.7), null);


(lib.TC_TText__Area4st2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.SsubTitle2 = new cjs.Text("Algae Reproduction", "bold 24px 'PT Sans'", "#333333");
	this.SsubTitle2.name = "SsubTitle2";
	this.SsubTitle2.textAlign = "center";
	this.SsubTitle2.lineHeight = 33;
	this.SsubTitle2.lineWidth = 303;
	this.SsubTitle2.parent = this;
	this.SsubTitle2.setTransform(153.5,2);

	this.timeline.addTween(cjs.Tween.get(this.SsubTitle2).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TText__Area4st2, new cjs.Rectangle(0,0,307.1,45.5), null);


(lib.TC_TText__Area4st1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.SsubTitle1 = new cjs.Text("Flower Reproduction", "bold 24px 'PT Sans'", "#333333");
	this.SsubTitle1.name = "SsubTitle1";
	this.SsubTitle1.textAlign = "center";
	this.SsubTitle1.lineHeight = 33;
	this.SsubTitle1.lineWidth = 237;
	this.SsubTitle1.parent = this;
	this.SsubTitle1.setTransform(101.5,2);

	this.timeline.addTween(cjs.Tween.get(this.SsubTitle1).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TText__Area4st1, new cjs.Rectangle(-19,0,241,49.1), null);


(lib.TC_TText__Area4Or = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Sor = new cjs.Text("OR", "bold 32px 'PT Sans'", "#333333");
	this.Sor.name = "Sor";
	this.Sor.textAlign = "center";
	this.Sor.lineHeight = 43;
	this.Sor.lineWidth = 52;
	this.Sor.parent = this;
	this.Sor.setTransform(28.2,2);

	this.timeline.addTween(cjs.Tween.get(this.Sor).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TText__Area4Or, new cjs.Rectangle(0,0,56.4,52.7), null);


(lib.TC_TText__Area3Title = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Stitle = new cjs.Text("Forces & Motion", "bold 32px 'PT Sans'", "#333333");
	this.Stitle.name = "Stitle";
	this.Stitle.textAlign = "center";
	this.Stitle.lineHeight = 43;
	this.Stitle.lineWidth = 425;
	this.Stitle.parent = this;
	this.Stitle.setTransform(214.4,2);

	this.timeline.addTween(cjs.Tween.get(this.Stitle).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TText__Area3Title, new cjs.Rectangle(0,0,428.8,52.7), null);


(lib.TC_TText__Area3st2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.SsubTitle2 = new cjs.Text("Time for objects to sink", "bold 24px 'PT Sans'", "#333333");
	this.SsubTitle2.name = "SsubTitle2";
	this.SsubTitle2.textAlign = "center";
	this.SsubTitle2.lineHeight = 33;
	this.SsubTitle2.lineWidth = 178;
	this.SsubTitle2.parent = this;
	this.SsubTitle2.setTransform(91.2,2);

	this.timeline.addTween(cjs.Tween.get(this.SsubTitle2).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TText__Area3st2, new cjs.Rectangle(0,0,182.4,68.1), null);


(lib.TC_TText__Area3st1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.SsubTitle1 = new cjs.Text("Speed of balls at the bottom of ramps", "bold 24px 'PT Sans'", "#333333");
	this.SsubTitle1.name = "SsubTitle1";
	this.SsubTitle1.textAlign = "center";
	this.SsubTitle1.lineHeight = 33;
	this.SsubTitle1.lineWidth = 227;
	this.SsubTitle1.parent = this;
	this.SsubTitle1.setTransform(115.7,2);

	this.timeline.addTween(cjs.Tween.get(this.SsubTitle1).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TText__Area3st1, new cjs.Rectangle(0,0,231.5,68.1), null);


(lib.TC_TText__Area3Or = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Sor = new cjs.Text("OR", "bold 32px 'PT Sans'", "#333333");
	this.Sor.name = "Sor";
	this.Sor.textAlign = "center";
	this.Sor.lineHeight = 43;
	this.Sor.lineWidth = 52;
	this.Sor.parent = this;
	this.Sor.setTransform(28.2,2);

	this.timeline.addTween(cjs.Tween.get(this.Sor).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TText__Area3Or, new cjs.Rectangle(0,0,56.4,52.7), null);


(lib.TC_TText__Area2Title = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Stitle = new cjs.Text("Heat & Temperature", "bold 32px 'PT Sans'", "#333333");
	this.Stitle.name = "Stitle";
	this.Stitle.textAlign = "center";
	this.Stitle.lineHeight = 43;
	this.Stitle.lineWidth = 425;
	this.Stitle.parent = this;
	this.Stitle.setTransform(214.4,2);

	this.timeline.addTween(cjs.Tween.get(this.Stitle).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TText__Area2Title, new cjs.Rectangle(0,0,428.8,52.7), null);


(lib.TC_TText__Area2st2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.SsubTitle2 = new cjs.Text("Temperature of a Gas", "bold 24px 'PT Sans'", "#333333");
	this.SsubTitle2.name = "SsubTitle2";
	this.SsubTitle2.textAlign = "center";
	this.SsubTitle2.lineHeight = 33;
	this.SsubTitle2.lineWidth = 303;
	this.SsubTitle2.parent = this;
	this.SsubTitle2.setTransform(153.5,2);

	this.timeline.addTween(cjs.Tween.get(this.SsubTitle2).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TText__Area2st2, new cjs.Rectangle(0,0,307.1,45.5), null);


(lib.TC_TText__Area2st1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.SsubTitle1 = new cjs.Text("Ice Melting Time", "bold 24px 'PT Sans'", "#333333");
	this.SsubTitle1.name = "SsubTitle1";
	this.SsubTitle1.textAlign = "center";
	this.SsubTitle1.lineHeight = 33;
	this.SsubTitle1.lineWidth = 227;
	this.SsubTitle1.parent = this;
	this.SsubTitle1.setTransform(115.7,2);

	this.timeline.addTween(cjs.Tween.get(this.SsubTitle1).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TText__Area2st1, new cjs.Rectangle(0,0,231.5,45.5), null);


(lib.TC_TText__Area2Or = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Sor = new cjs.Text("OR", "bold 32px 'PT Sans'", "#333333");
	this.Sor.name = "Sor";
	this.Sor.textAlign = "center";
	this.Sor.lineHeight = 43;
	this.Sor.lineWidth = 52;
	this.Sor.parent = this;
	this.Sor.setTransform(28.2,2);

	this.timeline.addTween(cjs.Tween.get(this.Sor).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TText__Area2Or, new cjs.Rectangle(0,0,56.4,52.7), null);


(lib.TC_TText__Area1Title = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Stitle = new cjs.Text("Physical & Chemical Changes", "bold 32px 'PT Sans'", "#333333");
	this.Stitle.name = "Stitle";
	this.Stitle.textAlign = "center";
	this.Stitle.lineHeight = 43;
	this.Stitle.lineWidth = 425;
	this.Stitle.parent = this;
	this.Stitle.setTransform(214.4,2);

	this.timeline.addTween(cjs.Tween.get(this.Stitle).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TText__Area1Title, new cjs.Rectangle(0,0,428.8,52.7), null);


(lib.TC_TText__Area1st2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.SsubTitle2 = new cjs.Text("Soda/Mint Reactions", "bold 24px 'PT Sans'", "#333333");
	this.SsubTitle2.name = "SsubTitle2";
	this.SsubTitle2.textAlign = "center";
	this.SsubTitle2.lineHeight = 33;
	this.SsubTitle2.lineWidth = 303;
	this.SsubTitle2.parent = this;
	this.SsubTitle2.setTransform(153.5,2);

	this.timeline.addTween(cjs.Tween.get(this.SsubTitle2).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TText__Area1st2, new cjs.Rectangle(0,0,307.1,45.5), null);


(lib.TC_TText__Area1st1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.SsubTitle1 = new cjs.Text("Crystal Growth", "bold 24px 'PT Sans'", "#333333");
	this.SsubTitle1.name = "SsubTitle1";
	this.SsubTitle1.textAlign = "center";
	this.SsubTitle1.lineHeight = 33;
	this.SsubTitle1.lineWidth = 227;
	this.SsubTitle1.parent = this;
	this.SsubTitle1.setTransform(115.7,2);

	this.timeline.addTween(cjs.Tween.get(this.SsubTitle1).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TText__Area1st1, new cjs.Rectangle(0,0,231.5,45.5), null);


(lib.TC_TText__Area1Or = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.Sor = new cjs.Text("OR", "bold 32px 'PT Sans'", "#333333");
	this.Sor.name = "Sor";
	this.Sor.textAlign = "center";
	this.Sor.lineHeight = 43;
	this.Sor.lineWidth = 52;
	this.Sor.parent = this;
	this.Sor.setTransform(28.2,2);

	this.timeline.addTween(cjs.Tween.get(this.Sor).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TText__Area1Or, new cjs.Rectangle(0,0,56.4,52.7), null);


(lib.TC_TObject__arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").ss(2,1,1).p("AINgFIlUE2IgBi+IrEAAIABjlILEAAIgBi+g");
	this.shape.setTransform(52.5,30.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0098FF").s().p("AC5BzIrFAAIABjlILEAAIAAi+IFUErIlUE2g");
	this.shape_1.setTransform(52.5,30.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__arrow, new cjs.Rectangle(-1,-1,107,63), null);


(lib.ForceSpriteSheetKludge = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tshirtstickfigures();
	this.instance.parent = this;
	this.instance.setTransform(-376,192);

	this.instance_1 = new lib.Arrows();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-563,-343);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ForceSpriteSheetKludge, new cjs.Rectangle(-563,-343,737,935), null);


(lib.TC_TObject__RedShirtGraphic = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tshirtstickfigures();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__RedShirtGraphic, new cjs.Rectangle(0,0,550,400), null);


(lib.ButtonShadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().rr(-298.5,-101,597,202,22.8);
	this.shape.setTransform(265.5,68.2,0.889,0.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ButtonShadow, new cjs.Rectangle(0,0,531,136.4), null);


(lib.ButtonSelected = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#707F88").s("#FFFF99").ss(12.2,1,1).rr(-298.5,-101,597,202,22.8);
	this.shape.setTransform(265.5,68.2,0.889,0.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ButtonSelected, new cjs.Rectangle(-6,-6,543.1,148.5), null);


(lib.ButtonNormal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4273F8").s("#999999").ss(9,1,1).rr(-298.5,-101,597,202,22.8);
	this.shape.setTransform(265.5,68.2,0.889,0.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ButtonNormal, new cjs.Rectangle(-4.5,-4.5,540,145.4), null);


(lib.BubbleShadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().de(-151,-97.5,302,195);
	this.shape.setTransform(151,97.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.BubbleShadow, new cjs.Rectangle(0,0,302,195), null);


(lib.BubbleSelected = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#707F88").s("#FFFF99").ss(10.1,1,1).de(-151,-97.5,302,195);
	this.shape.setTransform(151,97.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.BubbleSelected, new cjs.Rectangle(-5,-5,312.1,205.1), null);


(lib.BubbleNormal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4273F8").s("#999999").ss(10.1,1,1).de(-151,-97.5,302,195);
	this.shape.setTransform(151,97.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.BubbleNormal, new cjs.Rectangle(-5,-5,312.1,205.1), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AnenqIAAERIBAgDQBNABBAAQQDNA2AAC/IjuAAIGXHCIF6nWIj4AAQgCgfgMgxQgahgg5hQQi3kBmtABg");
	this.shape.setTransform(47.9,42.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#000000","#363636","#FFFFFF"],[0,0,1],-47.9,0,47.9,0).s().p("AkxApIDtAAQABi+jOg2QhAgQhNgBIhAACIAAkQQGtgBC3EAQA5BQAaBhQANAxABAfID4AAIl6HVg");
	this.shape_1.setTransform(47.9,42.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(-1,-7.3,97.8,100.3), null);


(lib.TC_TObject__SubmitBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0066FF").s("#0000CC").ss(3,1,1).rr(-277.85,-85.35,555.7,170.7,15);
	this.shape.setTransform(277.8,85.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__SubmitBG, new cjs.Rectangle(-1.5,-1.5,558.7,173.7), null);


(lib.TC_TObject__AreaSelected = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,204,255,0.086)").s("#00CCFF").ss(7.1,1,1).rr(-343.25,-187.65,686.5,375.3,19.5);
	this.shape.setTransform(343.3,187.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__AreaSelected, new cjs.Rectangle(-3.5,-3.5,693.5,382.3), null);


(lib.TC_TObject__AreaNormal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EEEEEE").s("#000066").ss(7.1,1,1).rr(-343.25,-187.65,686.5,375.3,19.5);
	this.shape.setTransform(343.3,187.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__AreaNormal, new cjs.Rectangle(-3.5,-3.5,693.5,382.3), null);


(lib.TC_TObject__AreaButtonUp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,0,0.008)").s("#000000").ss(7.1,1,1).rr(-343.25,-187.65,686.5,375.3,19.5);
	this.shape.setTransform(343.3,187.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__AreaButtonUp, new cjs.Rectangle(-3.5,-3.5,693.5,382.3), null);


(lib.TC_TObject__AreaButtonOver = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,0,0.008)").s("#0000FF").ss(7.1,1,1).rr(-343.25,-187.65,686.5,375.3,19.5);
	this.shape.setTransform(343.3,187.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__AreaButtonOver, new cjs.Rectangle(-3.5,-3.5,693.5,382.3), null);


(lib.TC_TObject__AreaButtonDn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,0,0.086)").s("#FFFF00").ss(7.1,1,1).rr(-343.25,-187.65,686.5,375.3,19.5);
	this.shape.setTransform(343.3,187.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__AreaButtonDn, new cjs.Rectangle(-3.5,-3.5,693.5,382.3), null);


(lib.ef_TutorModule = function(options) {
	this._element = new $.ef.TutorModule(options);
	this._el = this._element.create();
	var $this = this;
	this.addEventListener('added', function() {
		$this._lastAddedFrame = $this.parent.currentFrame;
		$this._element.attach($('#dom_overlay_container'));
	});
}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,100,100);

p._tick = _tick;
p._handleDrawEnd = _handleDrawEnd;
p._updateVisibility = _updateVisibility;



(lib.TC_TVirtual__SceneRgn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#FF00FF").ss(1,1,1).rc(-866.5,-523.4,1733,1046.8,11.4,11.4,-110,-110);
	this.shape.setTransform(960,587.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(210,210,210,0.047)").s("#99FFFF").ss(0.1,1,1).dr(-960,-600,1920,1200);
	this.shape_1.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TVirtual__SceneRgn, new cjs.Rectangle(-1,-1,1922,1202), null);


(lib.TC_TObject__NavBackground = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D5E9FD").s("#AAAAAA").ss(2.5,1,1).rr(-960,-600,1920,1200,10);
	this.shape.setTransform(960,600);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__NavBackground, new cjs.Rectangle(-1.2,-1.2,1922.5,1202.5), null);


(lib.TC_TObject__contentFrame3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#FFFFFF").ss(1,1,1).rc(-866.5,-523.4,1733,1046.8,11.4,11.4,-113,-113);
	this.shape.setTransform(866.5,523.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__contentFrame3, new cjs.Rectangle(-1,-1,1735,1048.8), null);


(lib.TC_TObject__contentFrame2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#FFFFFF").ss(1,1,1).rc(-866.5,-523.4,1733,1046.8,11.4,11.4,-113,11.4);
	this.shape.setTransform(866.5,523.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__contentFrame2, new cjs.Rectangle(-1,-1,1735,1048.8), null);


(lib.TC_TObject__contentFrame1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#FFFFFF").ss(1,1,1).rc(-866.5,-523.4,1733,1046.8,11.4,11.4,11.4,-113);
	this.shape.setTransform(866.5,523.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__contentFrame1, new cjs.Rectangle(-1,-1,1735,1048.8), null);


(lib.TC_TObject__contentFrame0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#FFFFFF").ss(1,1,1).rr(-866.5,-523.4,1733,1046.8,11.4);
	this.shape.setTransform(866.5,523.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__contentFrame0, new cjs.Rectangle(-1,-1,1735,1048.8), null);


(lib.NextOutline = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(35.8,1,1).p("AmHjRIMPAAImIGjg");
	this.shape.setTransform(39.2,21);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AmHjRIMPAAImIGjg");
	this.shape_1.setTransform(39.2,21);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.NextOutline, new cjs.Rectangle(-17.8,-17.8,114.2,77.6), null);


(lib.NextButtonFocus = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#EEEEEE").ss(30,1,1).p("AmHjRIMPAAImIGjg");
	this.shape.setTransform(39.2,21);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EEEEEE").s().p("AmHjRIMPAAImIGjg");
	this.shape_1.setTransform(39.2,21);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.NextButtonFocus, new cjs.Rectangle(-15,-15,108.5,71.9), null);


(lib.NextButtonDisabled = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#EEEEEE").ss(30,1,1).p("AmHjRIMPAAImIGjg");
	this.shape.setTransform(39.2,21);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s().p("AmHjRIMPAAImIGjg");
	this.shape_1.setTransform(39.2,21);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#EEEEEE").ss(10.6,1,1).de(-86,-86,172,172);
	this.shape_2.setTransform(39,11);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer 2
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().dr(-49,-16.6,98,33.2);
	this.shape_3.setTransform(39,-77,1,1,90);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib.NextButtonDisabled, new cjs.Rectangle(-52.3,-126,182.6,228.3), null);


(lib.SpinOutline = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(35.8,1,1).p("AmHjRIMPAAImIGjg");
	this.shape.setTransform(39.2,21);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AmHjRIMPAAImIGjg");
	this.shape_1.setTransform(39.2,21);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.SpinOutline, new cjs.Rectangle(-17.8,-17.8,114.2,77.6), null);


(lib.TextArea = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s("#CCCCCC").ss(1,1,1).dr(-50,-50,100,100);
	this.shape.setTransform(50,50);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.TextArea, new cjs.Rectangle(-1,-1,102,102), null);


(lib.TC_TButton__StartButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.Slabel = new cjs.Text("Start", "bold 85px 'PT Sans'", "#FFFFFF");
	this.Slabel.name = "Slabel";
	this.Slabel.textAlign = "center";
	this.Slabel.lineHeight = 112;
	this.Slabel.lineWidth = 262;
	this.Slabel.parent = this;
	this.Slabel.setTransform(277.8,30.4);

	this.timeline.addTween(cjs.Tween.get(this.Slabel).wait(4));

	// Layer_1
	this.shape = new lib.TC_TObject__SubmitBG();
	this.shape.name = "shape";
	this.shape.parent = this;
	this.shape.setTransform(277.8,85.4,1,1,0,0,0,277.8,85.4);
	new cjs.ButtonHelper(this.shape, 0, 1, 1);

	this.shape_1 = new lib.TC_TObject__SubmitBG();
	this.shape_1.name = "shape_1";
	this.shape_1.parent = this;
	this.shape_1.setTransform(277.8,85.4,1,1,0,0,0,277.8,85.4);
	new cjs.ButtonHelper(this.shape_1, 0, 1, 1);

	this.shape_2 = new lib.TC_TObject__SubmitBG();
	this.shape_2.name = "shape_2";
	this.shape_2.parent = this;
	this.shape_2.setTransform(277.8,85.4,1,1,0,0,0,277.8,85.4);
	new cjs.ButtonHelper(this.shape_2, 0, 1, 1);

	this.shape_3 = new lib.TC_TObject__SubmitBG();
	this.shape_3.name = "shape_3";
	this.shape_3.parent = this;
	this.shape_3.setTransform(277.8,85.4,1,1,0,0,0,277.8,85.4);
	new cjs.ButtonHelper(this.shape_3, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,-1.5,558.7,173.7);


(lib.TC_TObject__TopicSelector = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Sarea1topic2
	this.Sarea4title2 = new lib.TC_TText__Area4st2();
	this.Sarea4title2.name = "Sarea4title2";
	this.Sarea4title2.parent = this;
	this.Sarea4title2.setTransform(293.2,74.8,1.697,1.697,0,0,0,153.5,22.7);

	this.Sarea4title1 = new lib.TC_TText__Area4st1();
	this.Sarea4title1.name = "Sarea4title1";
	this.Sarea4title1.parent = this;
	this.Sarea4title1.setTransform(293.3,74.8,1.697,1.697,0,0,0,115.7,22.7);

	this.Sarea3title2 = new lib.TC_TText__Area3st2();
	this.Sarea3title2.name = "Sarea3title2";
	this.Sarea3title2.parent = this;
	this.Sarea3title2.setTransform(293.3,74.8,1.697,1.697,0,0,0,91.2,34);

	this.Sarea3title1 = new lib.TC_TText__Area3st1();
	this.Sarea3title1.name = "Sarea3title1";
	this.Sarea3title1.parent = this;
	this.Sarea3title1.setTransform(293.3,74.8,1.697,1.697,0,0,0,115.7,34);

	this.Sarea2title2 = new lib.TC_TText__Area2st2();
	this.Sarea2title2.name = "Sarea2title2";
	this.Sarea2title2.parent = this;
	this.Sarea2title2.setTransform(293.2,74.8,1.697,1.697,0,0,0,153.5,22.7);

	this.Sarea2title1 = new lib.TC_TText__Area2st1();
	this.Sarea2title1.name = "Sarea2title1";
	this.Sarea2title1.parent = this;
	this.Sarea2title1.setTransform(293.3,74.8,1.697,1.697,0,0,0,115.7,22.7);

	this.Sarea1title2 = new lib.TC_TText__Area1st2();
	this.Sarea1title2.name = "Sarea1title2";
	this.Sarea1title2.parent = this;
	this.Sarea1title2.setTransform(293.2,74.8,1.697,1.697,0,0,0,153.5,22.7);

	this.Sarea1title1 = new lib.TC_TText__Area1st1();
	this.Sarea1title1.name = "Sarea1title1";
	this.Sarea1title1.parent = this;
	this.Sarea1title1.setTransform(293.3,74.8,1.697,1.697,0,0,0,115.7,22.7);

	this.Sarea1topic2 = new lib.TL_Soda__Topic();
	this.Sarea1topic2.name = "Sarea1topic2";
	this.Sarea1topic2.parent = this;
	this.Sarea1topic2.setTransform(284.8,263,0.252,0.252,0,0,0,125.9,451.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Sarea1topic2},{t:this.Sarea1title1},{t:this.Sarea1title2},{t:this.Sarea2title1},{t:this.Sarea2title2},{t:this.Sarea3title1},{t:this.Sarea3title2},{t:this.Sarea4title1},{t:this.Sarea4title2}]}).wait(1));

	// Sarea1topic1
	this.Sarea1topic1 = new lib.TL_Crystal__Topic();
	this.Sarea1topic1.name = "Sarea1topic1";
	this.Sarea1topic1.parent = this;
	this.Sarea1topic1.setTransform(284.8,263,0.577,0.577,0,0,0,182.3,197.6);

	this.timeline.addTween(cjs.Tween.get(this.Sarea1topic1).wait(1));

	// Sarea2topic2
	this.Sarea2topic2 = new lib.TL_Balloon__Topic();
	this.Sarea2topic2.name = "Sarea2topic2";
	this.Sarea2topic2.parent = this;
	this.Sarea2topic2.setTransform(284.8,263.1,0.457,0.457,0,0,0,258.6,249.7);

	this.timeline.addTween(cjs.Tween.get(this.Sarea2topic2).wait(1));

	// Sarea2topic1
	this.Sarea2topic1 = new lib.TL_IceMelt__Topic();
	this.Sarea2topic1.name = "Sarea2topic1";
	this.Sarea2topic1.parent = this;
	this.Sarea2topic1.setTransform(284.8,263,0.502,0.502,0,0,0,275,148);

	this.timeline.addTween(cjs.Tween.get(this.Sarea2topic1).wait(1));

	// Sarea3topic2
	this.Sarea3topic2 = new lib.TL_Sinking__Topic();
	this.Sarea3topic2.name = "Sarea3topic2";
	this.Sarea3topic2.parent = this;
	this.Sarea3topic2.setTransform(284.8,263,0.273,0.273,0,0,0,147,377.6);

	this.timeline.addTween(cjs.Tween.get(this.Sarea3topic2).wait(1));

	// Sarea3topic1
	this.Sarea3topic1 = new lib.TL_Ramps__Topic();
	this.Sarea3topic1.name = "Sarea3topic1";
	this.Sarea3topic1.parent = this;
	this.Sarea3topic1.setTransform(284.8,263,0.599,0.599,0,0,0,246.2,172.1);

	this.timeline.addTween(cjs.Tween.get(this.Sarea3topic1).wait(1));

	// Sarea4topic2
	this.Sarea4topic2 = new lib.TL_Algae__Topic();
	this.Sarea4topic2.name = "Sarea4topic2";
	this.Sarea4topic2.parent = this;
	this.Sarea4topic2.setTransform(284.8,263,0.844,0.844,0,0,0,148.5,130.6);

	this.timeline.addTween(cjs.Tween.get(this.Sarea4topic2).wait(1));

	// Sarea4topic1
	this.Sarea4topic1 = new lib.TL_GrHouse__Topic();
	this.Sarea4topic1.name = "Sarea4topic1";
	this.Sarea4topic1.parent = this;
	this.Sarea4topic1.setTransform(284.7,262.9,0.311,0.311,0,0,0,524.5,354.1);

	this.timeline.addTween(cjs.Tween.get(this.Sarea4topic1).wait(1));

	// TC_TObject__AreaSelected
	this.Sselected = new lib.TC_TObject__AreaSelected();
	this.Sselected.name = "Sselected";
	this.Sselected.parent = this;
	this.Sselected.setTransform(287.2,204,0.836,1.087,0,0,0,343.4,187.7);

	this.timeline.addTween(cjs.Tween.get(this.Sselected).wait(1));

	// TC_TObject__AreaNormal
	this.Snormal = new lib.TC_TObject__AreaNormal();
	this.Snormal.name = "Snormal";
	this.Snormal.parent = this;
	this.Snormal.setTransform(287.2,204,0.836,1.087,0,0,0,343.4,187.7);

	this.timeline.addTween(cjs.Tween.get(this.Snormal).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__TopicSelector, new cjs.Rectangle(-2.9,-3.8,580,415.5), null);


(lib.TC_TButton__AreaButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TC_TObject__AreaButtonUp();
	this.instance.name = "instance";
	this.instance.parent = this;
	this.instance.setTransform(343.3,187.7,1,1,0,0,0,343.3,187.7);

	this.instance_1 = new lib.TC_TObject__AreaButtonOver();
	this.instance_1.name = "instance_1";
	this.instance_1.parent = this;
	this.instance_1.setTransform(343.3,187.7,1,1,0,0,0,343.3,187.7);

	this.instance_2 = new lib.TC_TObject__AreaButtonDn();
	this.instance_2.name = "instance_2";
	this.instance_2.parent = this;
	this.instance_2.setTransform(342.3,187.7,1,1,0,0,0,343.3,187.7);

	this.instance_3 = new lib.TC_TObject__AreaButtonDn();
	this.instance_3.name = "instance_3";
	this.instance_3.parent = this;
	this.instance_3.setTransform(342.3,187.7,1,1,0,0,0,343.3,187.7);

	this.instance_4 = new lib.TC_TObject__AreaButtonDn();
	this.instance_4.name = "instance_4";
	this.instance_4.parent = this;
	this.instance_4.setTransform(342.3,187.7,1,1,0,0,0,343.3,187.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.5,-3.5,693.5,382.3);


(lib.TC_TObject__Area4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// SsubTitle2
	this.SsubTitle2 = new lib.TC_TText__Area4st2();
	this.SsubTitle2.name = "SsubTitle2";
	this.SsubTitle2.parent = this;
	this.SsubTitle2.setTransform(513.3,337.3,1,1,0,0,0,153.5,22.7);

	this.timeline.addTween(cjs.Tween.get(this.SsubTitle2).wait(1));

	// SsubTitle1
	this.SsubTitle1 = new lib.TC_TText__Area4st1();
	this.SsubTitle1.name = "SsubTitle1";
	this.SsubTitle1.parent = this;
	this.SsubTitle1.setTransform(202.1,337.3,1,1,0,0,0,115.7,22.7);

	this.timeline.addTween(cjs.Tween.get(this.SsubTitle1).wait(1));

	// Sor
	this.Sor = new lib.TC_TText__Area4Or();
	this.Sor.name = "Sor";
	this.Sor.parent = this;
	this.Sor.setTransform(381.6,195.7,1,1,0,0,0,28.2,26.3);

	this.timeline.addTween(cjs.Tween.get(this.Sor).wait(1));

	// Svar2
	this.Svar2 = new lib.TL_Algae__Topic();
	this.Svar2.name = "Svar2";
	this.Svar2.parent = this;
	this.Svar2.setTransform(541.5,197.1,0.844,0.844,0,0,0,148.5,130.6);
	this.Svar2.cache(-2,-2,301,265);

	this.timeline.addTween(cjs.Tween.get(this.Svar2).wait(1));

	// Svar1
	this.Svar1 = new lib.TL_GrHouse__Topic();
	this.Svar1.name = "Svar1";
	this.Svar1.parent = this;
	this.Svar1.setTransform(184.2,197,0.311,0.311,0,0,0,524.5,354.1);

	this.timeline.addTween(cjs.Tween.get(this.Svar1).wait(1));

	// Stitle
	this.Stitle = new lib.TC_TText__Area4Title();
	this.Stitle.name = "Stitle";
	this.Stitle.parent = this;
	this.Stitle.setTransform(343.3,48.1,1,1,0,0,0,214.4,26.3);

	this.timeline.addTween(cjs.Tween.get(this.Stitle).wait(1));

	// TC_TObject__AreaSelected
	this.Sselected = new lib.TC_TObject__AreaSelected();
	this.Sselected.name = "Sselected";
	this.Sselected.parent = this;
	this.Sselected.setTransform(343.3,187.7,1,1,0,0,0,343.3,187.7);

	this.timeline.addTween(cjs.Tween.get(this.Sselected).wait(1));

	// TC_TObject__AreaNormal
	this.instance = new lib.TC_TObject__AreaNormal();
	this.instance.parent = this;
	this.instance.setTransform(343.3,187.7,1,1,0,0,0,343.3,187.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Area4, new cjs.Rectangle(-3.5,-3.5,693.5,382.3), null);


(lib.TC_TObject__Area3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// SsubTitle2
	this.SsubTitle2 = new lib.TC_TText__Area3st2();
	this.SsubTitle2.name = "SsubTitle2";
	this.SsubTitle2.parent = this;
	this.SsubTitle2.setTransform(536.9,326.5,1,1,0,0,0,91.2,34);

	this.timeline.addTween(cjs.Tween.get(this.SsubTitle2).wait(1));

	// SsubTitle1
	this.SsubTitle1 = new lib.TC_TText__Area3st1();
	this.SsubTitle1.name = "SsubTitle1";
	this.SsubTitle1.parent = this;
	this.SsubTitle1.setTransform(210.9,326.5,1,1,0,0,0,115.7,34);

	this.timeline.addTween(cjs.Tween.get(this.SsubTitle1).wait(1));

	// Sor
	this.Sor = new lib.TC_TText__Area3Or();
	this.Sor.name = "Sor";
	this.Sor.parent = this;
	this.Sor.setTransform(417.5,195.7,1,1,0,0,0,28.2,26.3);

	this.timeline.addTween(cjs.Tween.get(this.Sor).wait(1));

	// Svar2
	this.Svar2 = new lib.TL_Sinking__Topic();
	this.Svar2.name = "Svar2";
	this.Svar2.parent = this;
	this.Svar2.setTransform(539,189.7,0.273,0.273,0,0,0,147,377.6);
	this.Svar2.cache(-2,-2,298,759);

	this.timeline.addTween(cjs.Tween.get(this.Svar2).wait(1));

	// Svar1
	this.Svar1 = new lib.TL_Ramps__Topic();
	this.Svar1.name = "Svar1";
	this.Svar1.parent = this;
	this.Svar1.setTransform(212.5,189.7,0.599,0.599,0,0,0,246.2,172.1);
	this.Svar1.cache(-2,-2,496,348);

	this.timeline.addTween(cjs.Tween.get(this.Svar1).wait(1));

	// Stitle
	this.Stitle = new lib.TC_TText__Area3Title();
	this.Stitle.name = "Stitle";
	this.Stitle.parent = this;
	this.Stitle.setTransform(343.3,48.1,1,1,0,0,0,214.4,26.3);

	this.timeline.addTween(cjs.Tween.get(this.Stitle).wait(1));

	// TC_TObject__AreaSelected
	this.Sselected = new lib.TC_TObject__AreaSelected();
	this.Sselected.name = "Sselected";
	this.Sselected.parent = this;
	this.Sselected.setTransform(343.3,187.7,1,1,0,0,0,343.3,187.7);

	this.timeline.addTween(cjs.Tween.get(this.Sselected).wait(1));

	// TC_TObject__AreaNormal
	this.instance = new lib.TC_TObject__AreaNormal();
	this.instance.parent = this;
	this.instance.setTransform(343.3,187.7,1,1,0,0,0,343.3,187.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Area3, new cjs.Rectangle(-3.5,-3.5,693.5,382.3), null);


(lib.TC_TObject__Area2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// SsubTitle2
	this.SsubTitle2 = new lib.TC_TText__Area2st2();
	this.SsubTitle2.name = "SsubTitle2";
	this.SsubTitle2.parent = this;
	this.SsubTitle2.setTransform(513.3,333.6,1,1,0,0,0,153.5,22.7);

	this.timeline.addTween(cjs.Tween.get(this.SsubTitle2).wait(1));

	// SsubTitle1
	this.SsubTitle1 = new lib.TC_TText__Area2st1();
	this.SsubTitle1.name = "SsubTitle1";
	this.SsubTitle1.parent = this;
	this.SsubTitle1.setTransform(182.6,301.5,1,1,0,0,0,115.7,22.7);

	this.timeline.addTween(cjs.Tween.get(this.SsubTitle1).wait(1));

	// Sor
	this.Sor = new lib.TC_TText__Area2Or();
	this.Sor.name = "Sor";
	this.Sor.parent = this;
	this.Sor.setTransform(359.9,207.2,1,1,0,0,0,28.2,26.3);

	this.timeline.addTween(cjs.Tween.get(this.Sor).wait(1));

	// Svar2
	this.Svar2 = new lib.TL_Balloon__Topic();
	this.Svar2.name = "Svar2";
	this.Svar2.parent = this;
	this.Svar2.setTransform(523,197.1,0.457,0.457,0,0,0,258.6,249.7);
	this.Svar2.cache(-2,-2,521,503);

	this.timeline.addTween(cjs.Tween.get(this.Svar2).wait(1));

	// Svar1
	this.Svar1 = new lib.TL_IceMelt__Topic();
	this.Svar1.name = "Svar1";
	this.Svar1.parent = this;
	this.Svar1.setTransform(181.5,197.9,0.502,0.502,0,0,0,275,148);
	this.Svar1.cache(-2,-2,554,300);

	this.timeline.addTween(cjs.Tween.get(this.Svar1).wait(1));

	// Stitle
	this.Stitle = new lib.TC_TText__Area2Title();
	this.Stitle.name = "Stitle";
	this.Stitle.parent = this;
	this.Stitle.setTransform(343.3,44.7,1,1,0,0,0,214.4,26.3);

	this.timeline.addTween(cjs.Tween.get(this.Stitle).wait(1));

	// TC_TObject__AreaSelected
	this.Sselected = new lib.TC_TObject__AreaSelected();
	this.Sselected.name = "Sselected";
	this.Sselected.parent = this;
	this.Sselected.setTransform(343.3,187.7,1,1,0,0,0,343.3,187.7);

	this.timeline.addTween(cjs.Tween.get(this.Sselected).wait(1));

	// TC_TObject__AreaNormal
	this.instance = new lib.TC_TObject__AreaNormal();
	this.instance.parent = this;
	this.instance.setTransform(343.3,187.7,1,1,0,0,0,343.3,187.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Area2, new cjs.Rectangle(-3.5,-3.5,693.5,382.3), null);


(lib.TC_TObject__Area1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Sor
	this.Sor = new lib.TC_TText__Area1Or();
	this.Sor.name = "Sor";
	this.Sor.parent = this;
	this.Sor.setTransform(370.2,207.2,1,1,0,0,0,28.2,26.3);

	this.timeline.addTween(cjs.Tween.get(this.Sor).wait(1));

	// SsubTitle2
	this.SsubTitle2 = new lib.TC_TText__Area1st2();
	this.SsubTitle2.name = "SsubTitle2";
	this.SsubTitle2.parent = this;
	this.SsubTitle2.setTransform(503.1,333.6,1,1,0,0,0,153.5,22.7);

	this.timeline.addTween(cjs.Tween.get(this.SsubTitle2).wait(1));

	// SsubTitle1
	this.SsubTitle1 = new lib.TC_TText__Area1st1();
	this.SsubTitle1.name = "SsubTitle1";
	this.SsubTitle1.parent = this;
	this.SsubTitle1.setTransform(191.9,333.6,1,1,0,0,0,115.7,22.7);

	this.timeline.addTween(cjs.Tween.get(this.SsubTitle1).wait(1));

	// Stitle
	this.Stitle = new lib.TC_TText__Area1Title();
	this.Stitle.name = "Stitle";
	this.Stitle.parent = this;
	this.Stitle.setTransform(343.3,44.7,1,1,0,0,0,214.4,26.3);

	this.timeline.addTween(cjs.Tween.get(this.Stitle).wait(1));

	// Svar2
	this.Svar2 = new lib.TL_Soda__Topic();
	this.Svar2.name = "Svar2";
	this.Svar2.parent = this;
	this.Svar2.setTransform(500.5,197,0.252,0.252,0,0,0,125.9,451.8);

	this.timeline.addTween(cjs.Tween.get(this.Svar2).wait(1));

	// Svar1
	this.Svar1 = new lib.TL_Crystal__Topic();
	this.Svar1.name = "Svar1";
	this.Svar1.parent = this;
	this.Svar1.setTransform(193.3,197.1,0.577,0.577,0,0,0,182.3,197.6);
	this.Svar1.cache(-2,-2,369,399);

	this.timeline.addTween(cjs.Tween.get(this.Svar1).wait(1));

	// TC_TObject__AreaSelected
	this.Sselected = new lib.TC_TObject__AreaSelected();
	this.Sselected.name = "Sselected";
	this.Sselected.parent = this;
	this.Sselected.setTransform(343.3,187.7,1,1,0,0,0,343.3,187.7);

	this.timeline.addTween(cjs.Tween.get(this.Sselected).wait(1));

	// TC_TObject__AreaNormal
	this.instance = new lib.TC_TObject__AreaNormal();
	this.instance.parent = this;
	this.instance.setTransform(343.3,187.7,1,1,0,0,0,343.3,187.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__Area1, new cjs.Rectangle(-3.5,-3.5,693.5,382.3), null);


(lib.TC_TObject__navnexthit = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NextButtonFocus();
	this.instance.parent = this;
	this.instance.setTransform(150,86,1,1,-90,0,0,39.2,20.9);

	this.text = new cjs.Text("NEXT", "bold 20px 'Arial Black'", "#D6D6D6");
	this.text.textAlign = "center";
	this.text.lineHeight = 30;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(52,71.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().dr(-49,-16.6,98,33.2);
	this.shape.setTransform(49,86.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#EEEEEE").ss(10.6,1,1).de(-86,-86,172,172);
	this.shape_1.setTransform(140,86,1,1,-90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__navnexthit, new cjs.Rectangle(0,-5.3,231.3,182.6), null);


(lib.TC_TObject__navnextdisabled = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// NextButtonDisabled
	this.instance = new lib.NextButtonDisabled();
	this.instance.parent = this;
	this.instance.setTransform(150,86,1,1,-90,0,0,39.2,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// NEXT
	this.text = new cjs.Text("NEXT", "bold 20px 'Arial Black'", "#D6D6D6");
	this.text.textAlign = "center";
	this.text.lineHeight = 30;
	this.text.lineWidth = 100;
	this.text.alpha = 0.00000000;
	this.text.parent = this;
	this.text.setTransform(52,71.9);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0)").s().dr(-49,-16.6,98,33.2);
	this.shape.setTransform(49,86.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#EEEEEE").ss(10.6,1,1).de(-86,-86,172,172);
	this.shape_1.setTransform(140,86,1,1,-90);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__navnextdisabled, new cjs.Rectangle(0,-5.3,231.3,182.8), null);


(lib.TC_TObject__navbackhit = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("BACK", "bold 20px 'Arial Black'", "#D6D6D6");
	this.text.textAlign = "center";
	this.text.lineHeight = 30;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(171,71.9);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	// NextButtonFocus
	this.instance = new lib.NextButtonFocus();
	this.instance.parent = this;
	this.instance.setTransform(76.1,86,1,1,0,90,-90,39.2,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().dr(-49,-16.6,98,33.2);
	this.shape.setTransform(168,86.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#EEEEEE").ss(10.6,1,1).de(-86,-86,172,172);
	this.shape_1.setTransform(86,86,1,1,0,90,-90);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__navbackhit, new cjs.Rectangle(-5.3,-5.3,228.3,182.6), null);


(lib.TC_TObject__navbackdisabled = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NextButtonDisabled();
	this.instance.parent = this;
	this.instance.setTransform(76.1,86,1,1,0,90,-90,39.2,20.9);

	this.text = new cjs.Text("BACK", "bold 20px 'Arial Black'", "#D6D6D6");
	this.text.textAlign = "center";
	this.text.lineHeight = 30;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(171,71.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().dr(-49,-16.6,98,33.2);
	this.shape.setTransform(168,86.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#EEEEEE").ss(10.6,1,1).de(-86,-86,172,172);
	this.shape_1.setTransform(86,86,1,1,0,90,-90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__navbackdisabled, new cjs.Rectangle(-5.3,-5.3,228.3,182.8), null);


(lib.NextButtonUp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF8000").ss(30,1,1).p("AmHjRIMPAAImIGjg");
	this.shape.setTransform(39.2,21);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF8000").s().p("AmHjRIMPAAImIGjg");
	this.shape_1.setTransform(39.2,21);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Outline
	this.instance = new lib.NextOutline();
	this.instance.parent = this;
	this.instance.setTransform(39.2,20.9,1,1,0,0,0,39.2,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.NextButtonUp, new cjs.Rectangle(-17.8,-17.8,114.2,77.6), null);


(lib.NextButtonOver = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFF00").ss(30,1,1).p("AmHjRIMPAAImIGjg");
	this.shape.setTransform(39.2,21);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF00").s().p("AmHjRIMPAAImIGjg");
	this.shape_1.setTransform(39.2,21);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Outline
	this.instance = new lib.SpinOutline();
	this.instance.parent = this;
	this.instance.setTransform(39.2,20.9,1,1,0,0,0,39.2,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.NextButtonOver, new cjs.Rectangle(-17.8,-17.8,114.2,77.6), null);


(lib.NextButtonDown = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").ss(30,1,1).p("AmHjRIMPAAImIGjg");
	this.shape.setTransform(39.2,21);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s().p("AmHjRIMPAAImIGjg");
	this.shape_1.setTransform(39.2,21);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Outline
	this.instance = new lib.SpinOutline();
	this.instance.parent = this;
	this.instance.setTransform(39.2,20.9,1,1,0,0,0,39.2,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.NextButtonDown, new cjs.Rectangle(-17.8,-17.8,114.2,77.6), null);


(lib.TC_THtmlText__Text1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.SControlContainer = new lib.TextArea();
	this.SControlContainer.name = "SControlContainer";
	this.SControlContainer.parent = this;
	this.SControlContainer.setTransform(45.6,63.5,1.09,1.208,0,0,0,50,50.1);

	this.timeline.addTween(cjs.Tween.get(this.SControlContainer).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_THtmlText__Text1, new cjs.Rectangle(-9.5,2.4,110.1,122), null);


(lib.TC_TScene__SceneStart = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.Sstart = new lib.TC_TButton__StartButton();
	this.Sstart.name = "Sstart";
	this.Sstart.parent = this;
	this.Sstart.setTransform(682.2,492.2);
	new cjs.ButtonHelper(this.Sstart, 0, 1, 2, false, new lib.TC_TButton__StartButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Sstart).wait(1));

	// Layer_1
	this.instance = new lib.TC_TVirtual__SceneRgn();
	this.instance.parent = this;
	this.instance.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__SceneStart, new cjs.Rectangle(0,0,1920.1,1200.1), null);


(lib.TC_TScene__Scene11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.Stitle = new lib.TC_THtmlText__Text1();
	this.Stitle.name = "Stitle";
	this.Stitle.parent = this;
	this.Stitle.setTransform(1020.1,445.8,14.364,5.217,0,0,0,49.4,50.3);

	this.timeline.addTween(cjs.Tween.get(this.Stitle).wait(1));

	// SceneRegion
	this.instance = new lib.TC_TVirtual__SceneRgn();
	this.instance.parent = this;
	this.instance.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__Scene11, new cjs.Rectangle(0,0,1920.1,1200.1), null);


(lib.TC_TScene__Scene4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Stitle
	this.Sarrow1 = new lib.TC_TObject__arrow();
	this.Sarrow1.name = "Sarrow1";
	this.Sarrow1.parent = this;
	this.Sarrow1.setTransform(482.8,601.1,1,1,0,0,0,52.5,30.4);

	this.Svar1 = new lib.TC_THtmlText__Text1();
	this.Svar1.name = "Svar1";
	this.Svar1.parent = this;
	this.Svar1.setTransform(1205.5,600.1,10.742,0.453,0,0,0,50,50.1);

	this.Sarrow2 = new lib.TC_TObject__arrow();
	this.Sarrow2.name = "Sarrow2";
	this.Sarrow2.parent = this;
	this.Sarrow2.setTransform(482.8,689.3,1,1,0,0,0,52.5,30.4);

	this.Svar2 = new lib.TC_THtmlText__Text1();
	this.Svar2.name = "Svar2";
	this.Svar2.parent = this;
	this.Svar2.setTransform(1205.5,683.7,10.742,0.453,0,0,0,50,50.1);

	this.Sarrow3 = new lib.TC_TObject__arrow();
	this.Sarrow3.name = "Sarrow3";
	this.Sarrow3.parent = this;
	this.Sarrow3.setTransform(482.8,777.5,1,1,0,0,0,52.5,30.4);

	this.Svar3 = new lib.TC_THtmlText__Text1();
	this.Svar3.name = "Svar3";
	this.Svar3.parent = this;
	this.Svar3.setTransform(1205.5,767.4,10.742,0.453,0,0,0,50,50.1);

	this.Sarrow4 = new lib.TC_TObject__arrow();
	this.Sarrow4.name = "Sarrow4";
	this.Sarrow4.parent = this;
	this.Sarrow4.setTransform(482.8,865.8,1,1,0,0,0,52.5,30.4);

	this.Svar4 = new lib.TC_THtmlText__Text1();
	this.Svar4.name = "Svar4";
	this.Svar4.parent = this;
	this.Svar4.setTransform(1205.5,851.1,10.742,0.453,0,0,0,50,50.1);

	this.Stitle = new lib.TC_THtmlText__Text1();
	this.Stitle.name = "Stitle";
	this.Stitle.parent = this;
	this.Stitle.setTransform(1018,281.6,14.49,3.11,0,0,0,50,50.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Stitle},{t:this.Svar4},{t:this.Sarrow4},{t:this.Svar3},{t:this.Sarrow3},{t:this.Svar2},{t:this.Sarrow2},{t:this.Svar1},{t:this.Sarrow1}]}).wait(1));

	// SceneRegion
	this.instance = new lib.TC_TVirtual__SceneRgn();
	this.instance.parent = this;
	this.instance.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__Scene4, new cjs.Rectangle(0,0,1920.1,1200.1), null);


(lib.TC_TScene__Scene3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.Sbutton2 = new lib.TC_TButton__AreaButton();
	this.Sbutton2.name = "Sbutton2";
	this.Sbutton2.parent = this;
	this.Sbutton2.setTransform(1027.5,498.6,0.836,1.087);
	new cjs.ButtonHelper(this.Sbutton2, 0, 1, 2, false, new lib.TC_TButton__AreaButton(), 3);

	this.Sbutton1 = new lib.TC_TButton__AreaButton();
	this.Sbutton1.name = "Sbutton1";
	this.Sbutton1.parent = this;
	this.Sbutton1.setTransform(318.5,498.6,0.836,1.087);
	new cjs.ButtonHelper(this.Sbutton1, 0, 1, 2, false, new lib.TC_TButton__AreaButton(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Sbutton1},{t:this.Sbutton2}]}).wait(1));

	// Stopic2
	this.Stopic2 = new lib.TC_TObject__TopicSelector();
	this.Stopic2.name = "Stopic2";
	this.Stopic2.parent = this;
	this.Stopic2.setTransform(1314.5,702.5,1,1,0,0,0,287,203.9);

	this.timeline.addTween(cjs.Tween.get(this.Stopic2).wait(1));

	// Stopic1
	this.Stopic1 = new lib.TC_TObject__TopicSelector();
	this.Stopic1.name = "Stopic1";
	this.Stopic1.parent = this;
	this.Stopic1.setTransform(605.5,702.5,1,1,0,0,0,287,203.9);

	this.timeline.addTween(cjs.Tween.get(this.Stopic1).wait(1));

	// Stitle
	this.Stitle = new lib.TC_THtmlText__Text1();
	this.Stitle.name = "Stitle";
	this.Stitle.parent = this;
	this.Stitle.setTransform(1017.2,246.1,14.538,2.406,0,0,0,50.1,50.1);

	this.timeline.addTween(cjs.Tween.get(this.Stitle).wait(1));

	// TC_TVirtual__SceneRgn
	this.instance = new lib.TC_TVirtual__SceneRgn();
	this.instance.parent = this;
	this.instance.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__Scene3, new cjs.Rectangle(0,0,1920.1,1200.1), null);


(lib.TC_TScene__Scene2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Sbutton4
	this.Sbutton4 = new lib.TC_TButton__AreaButton();
	this.Sbutton4.name = "Sbutton4";
	this.Sbutton4.parent = this;
	this.Sbutton4.setTransform(981.8,627);
	new cjs.ButtonHelper(this.Sbutton4, 0, 1, 2, false, new lib.TC_TButton__AreaButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Sbutton4).wait(1));

	// Sbutton3
	this.Sbutton3 = new lib.TC_TButton__AreaButton();
	this.Sbutton3.name = "Sbutton3";
	this.Sbutton3.parent = this;
	this.Sbutton3.setTransform(251.8,627);
	new cjs.ButtonHelper(this.Sbutton3, 0, 1, 2, false, new lib.TC_TButton__AreaButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Sbutton3).wait(1));

	// Sbutton2
	this.Sbutton2 = new lib.TC_TButton__AreaButton();
	this.Sbutton2.name = "Sbutton2";
	this.Sbutton2.parent = this;
	this.Sbutton2.setTransform(981.8,220.8);
	new cjs.ButtonHelper(this.Sbutton2, 0, 1, 2, false, new lib.TC_TButton__AreaButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Sbutton2).wait(1));

	// Sbutton1
	this.Sbutton1 = new lib.TC_TButton__AreaButton();
	this.Sbutton1.name = "Sbutton1";
	this.Sbutton1.parent = this;
	this.Sbutton1.setTransform(251.8,220.8);
	new cjs.ButtonHelper(this.Sbutton1, 0, 1, 2, false, new lib.TC_TButton__AreaButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Sbutton1).wait(1));

	// Stitle
	this.Stitle = new cjs.Text("Areas of Science", "bold 84px 'PT Sans'", "#333333");
	this.Stitle.name = "Stitle";
	this.Stitle.textAlign = "center";
	this.Stitle.lineHeight = 111;
	this.Stitle.lineWidth = 1267;
	this.Stitle.parent = this;
	this.Stitle.setTransform(969.2,78.8);

	this.timeline.addTween(cjs.Tween.get(this.Stitle).wait(1));

	// Sarea4
	this.Sarea4 = new lib.TC_TObject__Area4();
	this.Sarea4.name = "Sarea4";
	this.Sarea4.parent = this;
	this.Sarea4.setTransform(1325.1,814.7,1,1,0,0,0,343.3,187.7);

	this.timeline.addTween(cjs.Tween.get(this.Sarea4).wait(1));

	// Sarea3
	this.Sarea3 = new lib.TC_TObject__Area3();
	this.Sarea3.name = "Sarea3";
	this.Sarea3.parent = this;
	this.Sarea3.setTransform(595.1,814.7,1,1,0,0,0,343.3,187.7);

	this.timeline.addTween(cjs.Tween.get(this.Sarea3).wait(1));

	// Sarea2
	this.Sarea2 = new lib.TC_TObject__Area2();
	this.Sarea2.name = "Sarea2";
	this.Sarea2.parent = this;
	this.Sarea2.setTransform(1325.1,408.5,1,1,0,0,0,343.3,187.7);

	this.timeline.addTween(cjs.Tween.get(this.Sarea2).wait(1));

	// Sarea1
	this.Sarea1 = new lib.TC_TObject__Area1();
	this.Sarea1.name = "Sarea1";
	this.Sarea1.parent = this;
	this.Sarea1.setTransform(595.1,408.5,1,1,0,0,0,343.3,187.7);

	this.timeline.addTween(cjs.Tween.get(this.Sarea1).wait(1));

	// SceneRegion
	this.instance = new lib.TC_TVirtual__SceneRgn();
	this.instance.parent = this;
	this.instance.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__Scene2, new cjs.Rectangle(0,0,1920.1,1200.1), null);


(lib.TC_THtmlButton__VarSelector = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.Stext = new lib.TC_THtmlText__Text1();
	this.Stext.name = "Stext";
	this.Stext.parent = this;
	this.Stext.setTransform(587.4,70.3,9.871,1.547,0,0,0,49.9,50.1);

	this.timeline.addTween(cjs.Tween.get(this.Stext).wait(5));

	// up
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s("#000000").ss(4,1,1).rr(-543.45,-90.5,1086.9,181,10);
	this.shape.setTransform(543.5,90.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(4));

	// over
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0066FF").s("#000000").ss(4,1,1).rr(-543.45,-90.5,1086.9,181,10);
	this.shape_1.setTransform(543.5,90.5);
	this.shape_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).to({_off:true},1).wait(3));

	// down
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000099").s("#000000").ss(4,1,1).rr(-543.45,-90.5,1086.9,181,10);
	this.shape_2.setTransform(543.5,90.5);
	this.shape_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(2).to({_off:false},0).to({_off:true},1).wait(2));

	// disabled
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(204,204,204,0.408)").s("#999999").ss(4,1,1).rr(-543.45,-90.5,1086.9,181,10);
	this.shape_3.setTransform(543.5,90.5);
	this.shape_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(3).to({_off:false},0).to({_off:true},1).wait(1));

	// focus
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(204,204,204,0.408)").s("#999999").ss(4,1,1).rr(-543.45,-90.5,1086.9,181,10);
	this.shape_4.setTransform(543.5,90.5);
	this.shape_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(4).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2,-3.5,1090.9,188.7);


(lib.TC_TIntroControl__RQIntro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Arrow
	this.Sarrow = new lib.arrow();
	this.Sarrow.name = "Sarrow";
	this.Sarrow.parent = this;
	this.Sarrow.setTransform(560,134.2,1,1,0,0,0,47.9,42.9);

	this.timeline.addTween(cjs.Tween.get(this.Sarrow).wait(1));

	// Bubble Text
	this.STextBox2 = new lib.TC_THtmlText__Text1();
	this.STextBox2.name = "STextBox2";
	this.STextBox2.parent = this;
	this.STextBox2.setTransform(646.1,-29.1,2.465,1.421,0,0,0,50.1,49.9);

	this.timeline.addTween(cjs.Tween.get(this.STextBox2).wait(1));

	// BubbleSelect
	this.SbubbleSelect = new lib.BubbleSelected();
	this.SbubbleSelect.name = "SbubbleSelect";
	this.SbubbleSelect.parent = this;
	this.SbubbleSelect.setTransform(632,-18.5,1,1,0,0,0,151,97.5);

	this.timeline.addTween(cjs.Tween.get(this.SbubbleSelect).wait(1));

	// BubbleNormal
	this.SbubbleNormal = new lib.BubbleNormal();
	this.SbubbleNormal.name = "SbubbleNormal";
	this.SbubbleNormal.parent = this;
	this.SbubbleNormal.setTransform(632,-18.5,1,1,0,0,0,151,97.5);

	this.timeline.addTween(cjs.Tween.get(this.SbubbleNormal).wait(1));

	// BubbleShadow
	this.SbubbleShadow = new lib.BubbleShadow();
	this.SbubbleShadow.name = "SbubbleShadow";
	this.SbubbleShadow.parent = this;
	this.SbubbleShadow.setTransform(632,-18.5,1,1,0,0,0,151,97.5);
	this.SbubbleShadow.shadow = new cjs.Shadow("rgba(153,153,153,1)",21,21,30);

	this.timeline.addTween(cjs.Tween.get(this.SbubbleShadow).wait(1));

	// Box Text
	this.STextBox1 = new lib.TC_THtmlText__Text1();
	this.STextBox1.name = "STextBox1";
	this.STextBox1.parent = this;
	this.STextBox1.setTransform(287.3,54,4.64,1.027,0,0,0,50.1,50.1);

	this.timeline.addTween(cjs.Tween.get(this.STextBox1).wait(1));

	// BoxSelect
	this.SboxSelect = new lib.ButtonSelected();
	this.SboxSelect.name = "SboxSelect";
	this.SboxSelect.parent = this;
	this.SboxSelect.setTransform(265.5,68.2,1,1,0,0,0,265.5,68.2);

	this.timeline.addTween(cjs.Tween.get(this.SboxSelect).wait(1));

	// BoxNormal
	this.SboxNormal = new lib.ButtonNormal();
	this.SboxNormal.name = "SboxNormal";
	this.SboxNormal.parent = this;
	this.SboxNormal.setTransform(265.5,68.2,1,1,0,0,0,265.5,68.2);

	this.timeline.addTween(cjs.Tween.get(this.SboxNormal).wait(1));

	// Box1Float
	this.SboxShadow = new lib.ButtonShadow();
	this.SboxShadow.name = "SboxShadow";
	this.SboxShadow.parent = this;
	this.SboxShadow.setTransform(265.5,68.2,1,1,0,0,0,265.5,68.2);
	this.SboxShadow.shadow = new cjs.Shadow("rgba(153,153,153,1)",11,11,15);

	this.timeline.addTween(cjs.Tween.get(this.SboxShadow).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TIntroControl__RQIntro, new cjs.Rectangle(-6,-127,846.1,310.8), null);


(lib.TC_TObject__navnextup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NextButtonUp();
	this.instance.parent = this;
	this.instance.setTransform(150,86,1,1,-90,0,0,39.2,20.9);

	this.text = new cjs.Text("NEXT", "bold 20px 'Arial Black'", "#D6D6D6");
	this.text.textAlign = "center";
	this.text.lineHeight = 30;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(52,71.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().dr(-49,-16.6,98,33.2);
	this.shape.setTransform(49,86.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#EEEEEE").ss(10.6,1,1).de(-86,-86,172,172);
	this.shape_1.setTransform(140,86,1,1,-90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__navnextup, new cjs.Rectangle(0,-5.3,231.3,182.6), null);


(lib.TC_TObject__navnextover = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NextButtonOver();
	this.instance.parent = this;
	this.instance.setTransform(150,86,1,1,-90,0,0,39.2,20.9);

	this.text = new cjs.Text("NEXT", "bold 20px 'Arial Black'", "#D6D6D6");
	this.text.textAlign = "center";
	this.text.lineHeight = 30;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(52,71.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().dr(-49,-16.6,98,33.2);
	this.shape.setTransform(49,86.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#EEEEEE").ss(10.6,1,1).de(-86,-86,172,172);
	this.shape_1.setTransform(140,86,1,1,-90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__navnextover, new cjs.Rectangle(0,-5.3,231.3,182.6), null);


(lib.TC_TObject__navnextdown = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NextButtonDown();
	this.instance.parent = this;
	this.instance.setTransform(150,86,1,1,-90,0,0,39.2,20.9);

	this.text = new cjs.Text("NEXT", "bold 20px 'Arial Black'", "#D6D6D6");
	this.text.textAlign = "center";
	this.text.lineHeight = 30;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(52,71.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().dr(-49,-16.6,98,33.2);
	this.shape.setTransform(49,86.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#EEEEEE").ss(10.6,1,1).de(-86,-86,172,172);
	this.shape_1.setTransform(140,86,1,1,-90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__navnextdown, new cjs.Rectangle(0,-5.3,231.3,182.6), null);


(lib.TC_TObject__navbackup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NextButtonUp();
	this.instance.parent = this;
	this.instance.setTransform(76.1,86,1,1,0,90,-90,39.2,20.9);

	this.text = new cjs.Text("BACK", "bold 20px 'Arial Black'", "#D6D6D6");
	this.text.textAlign = "center";
	this.text.lineHeight = 30;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(171,71.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().dr(-49,-16.6,98,33.2);
	this.shape.setTransform(168,86.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#EEEEEE").ss(10.6,1,1).de(-86,-86,172,172);
	this.shape_1.setTransform(86,86,1,1,0,90,-90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__navbackup, new cjs.Rectangle(-5.3,-5.3,228.3,182.6), null);


(lib.TC_TObject__navbackover = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NextButtonOver();
	this.instance.parent = this;
	this.instance.setTransform(76.1,86,1,1,0,90,-90,39.2,20.9);

	this.text = new cjs.Text("BACK", "bold 20px 'Arial Black'", "#D6D6D6");
	this.text.textAlign = "center";
	this.text.lineHeight = 30;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(171,71.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().dr(-49,-16.6,98,33.2);
	this.shape.setTransform(168,86.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#EEEEEE").ss(10.6,1,1).de(-86,-86,172,172);
	this.shape_1.setTransform(86,86,1,1,0,90,-90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__navbackover, new cjs.Rectangle(-5.3,-5.3,228.3,182.6), null);


(lib.TC_TObject__navbackdown = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.NextButtonDown();
	this.instance.parent = this;
	this.instance.setTransform(76.1,86,1,1,0,90,-90,39.2,20.9);

	this.text = new cjs.Text("BACK", "bold 20px 'Arial Black'", "#D6D6D6");
	this.text.textAlign = "center";
	this.text.lineHeight = 30;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(171,71.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().dr(-49,-16.6,98,33.2);
	this.shape.setTransform(168,86.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#EEEEEE").ss(10.6,1,1).de(-86,-86,172,172);
	this.shape_1.setTransform(86,86,1,1,0,90,-90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TObject__navbackdown, new cjs.Rectangle(-5.3,-5.3,228.3,182.6), null);


(lib.TC_TScene__Scene10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.Sbutton4 = new lib.TC_THtmlButton__VarSelector();
	this.Sbutton4.name = "Sbutton4";
	this.Sbutton4.parent = this;
	this.Sbutton4.setTransform(375.1,875.4,1.118,0.497);
	new cjs.ButtonHelper(this.Sbutton4, 0, 1, 2, false, new lib.TC_THtmlButton__VarSelector(), 3);

	this.Sbutton3 = new lib.TC_THtmlButton__VarSelector();
	this.Sbutton3.name = "Sbutton3";
	this.Sbutton3.parent = this;
	this.Sbutton3.setTransform(375.1,741,1.118,0.497);
	new cjs.ButtonHelper(this.Sbutton3, 0, 1, 2, false, new lib.TC_THtmlButton__VarSelector(), 3);

	this.Sbutton2 = new lib.TC_THtmlButton__VarSelector();
	this.Sbutton2.name = "Sbutton2";
	this.Sbutton2.parent = this;
	this.Sbutton2.setTransform(375.1,606.6,1.118,0.497);
	new cjs.ButtonHelper(this.Sbutton2, 0, 1, 2, false, new lib.TC_THtmlButton__VarSelector(), 3);

	this.Sbutton1 = new lib.TC_THtmlButton__VarSelector();
	this.Sbutton1.name = "Sbutton1";
	this.Sbutton1.parent = this;
	this.Sbutton1.setTransform(375.1,472.2,1.118,0.497);
	new cjs.ButtonHelper(this.Sbutton1, 0, 1, 2, false, new lib.TC_THtmlButton__VarSelector(), 3);

	this.Stitle = new lib.TC_THtmlText__Text1();
	this.Stitle.name = "Stitle";
	this.Stitle.parent = this;
	this.Stitle.setTransform(1011.9,242.6,14.529,2.293,0,0,0,49.4,50.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Stitle},{t:this.Sbutton1},{t:this.Sbutton2},{t:this.Sbutton3},{t:this.Sbutton4}]}).wait(1));

	// SceneRegion
	this.instance = new lib.TC_TVirtual__SceneRgn();
	this.instance.parent = this;
	this.instance.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__Scene10, new cjs.Rectangle(0,0,1920.1,1200.1), null);


(lib.TC_TScene__Scene9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.Sbutton4 = new lib.TC_THtmlButton__VarSelector();
	this.Sbutton4.name = "Sbutton4";
	this.Sbutton4.parent = this;
	this.Sbutton4.setTransform(423.3,899.5,1.03,0.574);
	new cjs.ButtonHelper(this.Sbutton4, 0, 1, 2, false, new lib.TC_THtmlButton__VarSelector(), 3);

	this.Sbutton3 = new lib.TC_THtmlButton__VarSelector();
	this.Sbutton3.name = "Sbutton3";
	this.Sbutton3.parent = this;
	this.Sbutton3.setTransform(423.3,744.5,1.03,0.574);
	new cjs.ButtonHelper(this.Sbutton3, 0, 1, 2, false, new lib.TC_THtmlButton__VarSelector(), 3);

	this.Sbutton2 = new lib.TC_THtmlButton__VarSelector();
	this.Sbutton2.name = "Sbutton2";
	this.Sbutton2.parent = this;
	this.Sbutton2.setTransform(423.3,589.4,1.03,0.574);
	new cjs.ButtonHelper(this.Sbutton2, 0, 1, 2, false, new lib.TC_THtmlButton__VarSelector(), 3);

	this.Sbutton1 = new lib.TC_THtmlButton__VarSelector();
	this.Sbutton1.name = "Sbutton1";
	this.Sbutton1.parent = this;
	this.Sbutton1.setTransform(423.3,434.3,1.03,0.574);
	new cjs.ButtonHelper(this.Sbutton1, 0, 1, 2, false, new lib.TC_THtmlButton__VarSelector(), 3);

	this.Stitle = new lib.TC_THtmlText__Text1();
	this.Stitle.name = "Stitle";
	this.Stitle.parent = this;
	this.Stitle.setTransform(1006.9,243,14.601,2.304,0,0,0,49.3,50.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Stitle},{t:this.Sbutton1},{t:this.Sbutton2},{t:this.Sbutton3},{t:this.Sbutton4}]}).wait(1));

	// SceneRegion
	this.instance = new lib.TC_TVirtual__SceneRgn();
	this.instance.parent = this;
	this.instance.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__Scene9, new cjs.Rectangle(0,0,1920.1,1200.1), null);


(lib.TC_TScene__Scene1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// SIntro1
	this.Sintro1 = new lib.TC_TIntroControl__RQIntro();
	this.Sintro1.name = "Sintro1";
	this.Sintro1.parent = this;
	this.Sintro1.setTransform(413.5,230.3,1.064,1.064,0,0,0,265.5,68.2);

	this.timeline.addTween(cjs.Tween.get(this.Sintro1).wait(1));

	// SIntro2
	this.Sintro2 = new lib.TC_TIntroControl__RQIntro();
	this.Sintro2.name = "Sintro2";
	this.Sintro2.parent = this;
	this.Sintro2.setTransform(718.5,456,1.064,1.064,0,0,0,265.5,68.2);

	this.timeline.addTween(cjs.Tween.get(this.Sintro2).wait(1));

	// SIntro3
	this.Sintro3 = new lib.TC_TIntroControl__RQIntro();
	this.Sintro3.name = "Sintro3";
	this.Sintro3.parent = this;
	this.Sintro3.setTransform(1023.5,681.6,1.064,1.064,0,0,0,265.5,68.2);

	this.timeline.addTween(cjs.Tween.get(this.Sintro3).wait(1));

	// SIntro4
	this.Sintro4 = new lib.TC_TIntroControl__RQIntro();
	this.Sintro4.name = "Sintro4";
	this.Sintro4.parent = this;
	this.Sintro4.setTransform(1328.5,907.3,1.064,1.064,0,0,0,265.5,68.2);

	this.timeline.addTween(cjs.Tween.get(this.Sintro4).wait(1));

	// Sample
	this.Ssample = new lib.TC_TObject__RedShirtGraphic();
	this.Ssample.name = "Ssample";
	this.Ssample.parent = this;
	this.Ssample.setTransform(423.9,791.5,1.065,1.065,0,0,0,275.1,200.1);

	this.timeline.addTween(cjs.Tween.get(this.Ssample).wait(1));

	// SceneRegion
	this.instance = new lib.TC_TVirtual__SceneRgn();
	this.instance.parent = this;
	this.instance.setTransform(960,600,1,1,0,0,0,960,600);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TScene__Scene1, new cjs.Rectangle(0,0,1935.8,1200.1), null);


(lib.TC_TButton__PrevButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// SpinButtonUp
	this.instance = new lib.TC_TObject__navbackup();
	this.instance.parent = this;
	this.instance.setTransform(61.9,11,1,1,0,0,0,108.9,86);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(4));

	// SpinButtonOver
	this.instance_1 = new lib.TC_TObject__navbackover();
	this.instance_1.parent = this;
	this.instance_1.setTransform(61.9,11,1,1,0,0,0,108.9,86);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({_off:true},1).wait(3));

	// SpinButtonDown
	this.instance_2 = new lib.TC_TObject__navbackdown();
	this.instance_2.parent = this;
	this.instance_2.setTransform(61.9,11,1,1,0,0,0,108.9,86);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({_off:false},0).to({_off:true},1).wait(2));

	// SpinButtonFocus
	this.instance_3 = new lib.TC_TObject__navbackhit();
	this.instance_3.parent = this;
	this.instance_3.setTransform(61.9,11,1,1,0,0,0,108.9,86);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(3).to({_off:false},0).to({_off:true},1).wait(1));

	// SpinButtonDisabled
	this.instance_4 = new lib.TC_TObject__navbackdisabled();
	this.instance_4.parent = this;
	this.instance_4.setTransform(61.9,11.1,1,1,0,0,0,108.9,86.1);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(4).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-52.3,-80.3,228.3,182.6);


(lib.TC_TButton__NextButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// SpinButtonUp
	this.instance = new lib.TC_TObject__navnextup();
	this.instance.parent = this;
	this.instance.setTransform(14.7,11,1,1,0,0,0,115.7,86);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(4));

	// SpinButtonOver
	this.instance_1 = new lib.TC_TObject__navnextover();
	this.instance_1.parent = this;
	this.instance_1.setTransform(14.7,11,1,1,0,0,0,115.7,86);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({_off:true},1).wait(3));

	// SpinButtonDown
	this.instance_2 = new lib.TC_TObject__navnextdown();
	this.instance_2.parent = this;
	this.instance_2.setTransform(14.7,11,1,1,0,0,0,115.7,86);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({_off:false},0).to({_off:true},1).wait(2));

	// SpinButtonDisabled
	this.instance_3 = new lib.TC_TObject__navnextdisabled();
	this.instance_3.parent = this;
	this.instance_3.setTransform(14.7,11.1,1,1,0,0,0,115.7,86.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(3).to({_off:false},0).to({_off:true},1).wait(1));

	// SpinButtonFocus
	this.instance_4 = new lib.TC_TObject__navnexthit();
	this.instance_4.parent = this;
	this.instance_4.setTransform(14.7,11,1,1,0,0,0,115.7,86);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(4).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-101,-80.3,231.3,182.6);


(lib.TC_TNavPanel__Navigator = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// SbreadCrumbs
	this.SbreadCrumbs = new lib.TC_THtmlText__Text1();
	this.SbreadCrumbs.name = "SbreadCrumbs";
	this.SbreadCrumbs.parent = this;
	this.SbreadCrumbs.setTransform(520.2,27.9,8.569,0.38,0,0,0,49.8,50.2);

	this.timeline.addTween(cjs.Tween.get(this.SbreadCrumbs).wait(1));

	// Snext
	this.Snext = new lib.TC_TButton__NextButton();
	this.Snext.name = "Snext";
	this.Snext.parent = this;
	this.Snext.setTransform(1782.9,1092.1);
	new cjs.ButtonHelper(this.Snext, 0, 1, 2, false, new lib.TC_TButton__NextButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Snext).wait(1));

	// Sback
	this.Sback = new lib.TC_TButton__PrevButton();
	this.Sback.name = "Sback";
	this.Sback.parent = this;
	this.Sback.setTransform(59.5,1092.1);
	new cjs.ButtonHelper(this.Sback, 0, 1, 2, false, new lib.TC_TButton__PrevButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Sback).wait(1));

	// Smask3
	this.Smask3 = new lib.TC_TObject__contentFrame3();
	this.Smask3.name = "Smask3";
	this.Smask3.parent = this;
	this.Smask3.setTransform(960,587.5,1,1,0,0,0,866.5,523.4);

	this.timeline.addTween(cjs.Tween.get(this.Smask3).wait(1));

	// Smask2
	this.Smask2 = new lib.TC_TObject__contentFrame2();
	this.Smask2.name = "Smask2";
	this.Smask2.parent = this;
	this.Smask2.setTransform(960,587.5,1,1,0,0,0,866.5,523.4);

	this.timeline.addTween(cjs.Tween.get(this.Smask2).wait(1));

	// Smask1
	this.Smask1 = new lib.TC_TObject__contentFrame1();
	this.Smask1.name = "Smask1";
	this.Smask1.parent = this;
	this.Smask1.setTransform(960,587.5,1,1,0,0,0,866.5,523.4);

	this.timeline.addTween(cjs.Tween.get(this.Smask1).wait(1));

	// Smask0
	this.Smask0 = new lib.TC_TObject__contentFrame0();
	this.Smask0.name = "Smask0";
	this.Smask0.parent = this;
	this.Smask0.setTransform(960,587.5,1,1,0,0,0,866.5,523.4);

	this.timeline.addTween(cjs.Tween.get(this.Smask0).wait(1));

	// Sbackground
	this.Sbackground = new lib.TC_TObject__NavBackground();
	this.Sbackground.name = "Sbackground";
	this.Sbackground.parent = this;
	this.Sbackground.setTransform(275,200,1,1,0,0,0,275,200);

	this.timeline.addTween(cjs.Tween.get(this.Sbackground).wait(1));

}).prototype = getMCSymbolPrototype(lib.TC_TNavPanel__Navigator, new cjs.Rectangle(-1.2,-1.2,1922.5,1202.5), null);


// stage content:
(lib.EFMod_RQSelect = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Module Component
	this.instance = new lib.ef_TutorModule({'id': '', 'compositionID':'F2AAB060E6A643B152F88DFFCB60C58D'});

	this.instance.setTransform(960,600,1,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1869.5,1149.5,101,101);
// library properties:
lib.properties = {
	id: 'F2AAB060E6A643B152F88DFFCB60C58D',
	width: 1920,
	height: 1200,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/EFMod_RQSelect_atlas_.png", id:"EFMod_RQSelect_atlas_"},
		{src:"components/EFComponents/src/ef_loadManager.js", id:"EFComponents/src/ef_loadManager.js"},
		{src:"components/EFComponents/src/ef_module.js", id:"ef.TutorModule"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['F2AAB060E6A643B152F88DFFCB60C58D'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}

function _updateVisibility(evt) {
	if((this.getStage() == null || this._off || this._lastAddedFrame != this.parent.currentFrame) && this._element) {
		this._element.detach();
		stage.removeEventListener('drawstart', this._updateVisibilityCbk);
		this._updateVisibilityCbk = false;
	}
}
function _handleDrawEnd(evt) {
	var props = this.getConcatenatedDisplayProps(this._props), mat = props.matrix;
	var tx1 = mat.decompose(); var sx = tx1.scaleX; var sy = tx1.scaleY;
	var dp = window.devicePixelRatio || 1; var w = this.nominalBounds.width * sx; var h = this.nominalBounds.height * sy;
	mat.tx/=dp;mat.ty/=dp; mat.a/=(dp*sx);mat.b/=(dp*sx);mat.c/=(dp*sy);mat.d/=(dp*sy);
	this._element.setProperty('transform-origin', this.regX + 'px ' + this.regY + 'px');
	var x = (mat.tx + this.regX*mat.a + this.regY*mat.c - this.regX);
	var y = (mat.ty + this.regX*mat.b + this.regY*mat.d - this.regY);
	var tx = 'matrix(' + mat.a + ',' + mat.b + ',' + mat.c + ',' + mat.d + ',' + x + ',' + y + ')';
	this._element.setProperty('transform', tx);
	this._element.setProperty('width', w);
	this._element.setProperty('height', h);
	this._element.update();
}

function _tick(evt) {
	var stage = this.getStage();
	stage&&stage.on('drawend', this._handleDrawEnd, this, true);
	if(!this._updateVisibilityCbk) {
		this._updateVisibilityCbk = stage.on('drawstart', this._updateVisibility, this, false);
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;